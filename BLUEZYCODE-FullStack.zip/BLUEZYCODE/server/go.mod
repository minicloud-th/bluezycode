module bluezycode

go 1.24
