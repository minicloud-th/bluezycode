package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"mime"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"slices"
	"strings"
	"time"
	"unicode/utf8"
)

const maxFileBytes = 64 * 1024

type App struct {
	store        Storage
	engine       string
	provider     Provider
	secureCookie bool
}

type Model struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type SendRequest struct {
	ChatID string `json:"chatId"`
	Prompt string `json:"prompt"`
	Model  string `json:"model"`
	Files  []File `json:"files"`
}

func env(name, fallback string) string {
	if value := os.Getenv(name); value != "" {
		return value
	}
	return fallback
}

func main() {
	provider, err := providerFromEnv()
	if err != nil {
		log.Fatal(err)
	}
	app := &App{
		store:  Storage{dir: env("BLUEZY_DATA_DIR", "data")},
		engine: env("BLUEZY_ENGINE", "bluezy-engine"), provider: provider,
		secureCookie: os.Getenv("BLUEZY_SECURE_COOKIE") == "1",
	}
	if err := os.MkdirAll(app.store.dir, 0700); err != nil {
		log.Fatal(err)
	}
	web := env("BLUEZY_WEB_DIR", "web/dist")
	if _, err := os.Stat(filepath.Join(web, "index.html")); err != nil {
		log.Fatalf("web build unavailable: %v", err)
	}
	server := http.Server{
		Addr: env("BLUEZY_ADDR", "127.0.0.1:8080"), Handler: app.routes(web),
		ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second,
		WriteTimeout: 65 * time.Second, IdleTimeout: 60 * time.Second,
	}
	log.Printf("BLUEZYCODE listening on %s", server.Addr)
	log.Fatal(server.ListenAndServe())
}

func (a *App) routes(web string) http.Handler {
	api := http.NewServeMux()
	api.HandleFunc("GET /api/workspace", a.workspace)
	api.HandleFunc("GET /api/chats/{id}", a.chat)
	api.HandleFunc("POST /api/turns", a.send)
	api.HandleFunc("POST /api/chats/{id}/{action}", a.chatAction)
	api.HandleFunc("POST /api/profile", a.profile)
	api.HandleFunc("/api/", func(w http.ResponseWriter, _ *http.Request) {
		problem(w, http.StatusNotFound, "ไม่พบ API")
	})
	files := http.FileServer(http.Dir(web))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "same-origin")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
		if strings.HasPrefix(r.URL.Path, "/api/") {
			w.Header().Set("Cache-Control", "no-store")
			if r.Method != http.MethodGet && r.Method != http.MethodHead {
				origin := r.Header.Get("Origin")
				if origin != "" {
					u, err := url.Parse(origin)
					if err != nil || (u.Scheme != "https" && u.Scheme != "http") || !strings.EqualFold(u.Host, r.Host) {
						problem(w, http.StatusForbidden, "อนุญาตคำขอจากหน้า BLUEZYCODE เท่านั้น")
						return
					}
				}
				if r.Header.Get("Sec-Fetch-Site") == "cross-site" {
					problem(w, http.StatusForbidden, "อนุญาตคำขอจากหน้า BLUEZYCODE เท่านั้น")
					return
				}
			}
			api.ServeHTTP(w, r)
			return
		}
		files.ServeHTTP(w, r)
	})
}

func sendJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(body); err != nil {
		log.Printf("response write failed: %v", err)
	}
}

func problem(w http.ResponseWriter, status int, message string) {
	sendJSON(w, status, map[string]string{"error": message})
}

func decode(w http.ResponseWriter, r *http.Request, target any) bool {
	media, _, _ := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if media != "application/json" {
		problem(w, http.StatusUnsupportedMediaType, "รองรับข้อมูล JSON เท่านั้น")
		return false
	}
	// JSON escaping can expand attachment contents to six times the raw bytes.
	r.Body = http.MaxBytesReader(w, r.Body, 1280*1024)
	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(target)
	if err == nil && decoder.Decode(new(any)) != io.EOF {
		err = errors.New("trailing JSON input")
	}
	if err != nil {
		var tooLarge *http.MaxBytesError
		if errors.As(err, &tooLarge) {
			problem(w, http.StatusRequestEntityTooLarge, "ข้อมูลมีขนาดใหญ่เกินไป")
		} else {
			problem(w, http.StatusBadRequest, "รูปแบบข้อมูลไม่ถูกต้อง")
		}
	}
	return err == nil
}

func (a *App) models() []Model {
	models := []Model{{ID: "workspace", Name: "Workspace"}}
	if a.provider.endpoint != "" {
		models = append(models, Model{ID: "ai", Name: a.provider.model})
	}
	return models
}

func (a *App) workspace(w http.ResponseWriter, r *http.Request) {
	id := workspaceID(r)
	if id == "" {
		var err error
		id, err = newID()
		if err != nil {
			a.storageError(w, err)
			return
		}
		http.SetCookie(w, &http.Cookie{
			Name: "bluezy_workspace", Value: id, Path: "/", MaxAge: 31536000,
			HttpOnly: true, SameSite: http.SameSiteLaxMode, Secure: a.secureCookie || r.TLS != nil,
		})
	}
	unlock := a.store.lock(id)
	defer unlock()
	ws, err := a.store.load(id)
	if err != nil {
		a.storageError(w, err)
		return
	}
	_, engineErr := exec.LookPath(a.engine)
	sendJSON(w, http.StatusOK, map[string]any{
		"name": ws.Name, "chats": ws.summaries(), "models": a.models(),
		"engineAvailable": engineErr == nil,
	})
}

func (a *App) openWorkspace(w http.ResponseWriter, r *http.Request, action func(string, Workspace)) {
	id := workspaceID(r)
	if id == "" {
		problem(w, http.StatusUnauthorized, "โหลดหน้าใหม่เพื่อเปิดพื้นที่ทำงาน")
		return
	}
	unlock := a.store.lock(id)
	defer unlock()
	ws, err := a.store.load(id)
	if err != nil {
		a.storageError(w, err)
		return
	}
	action(id, ws)
}

func (a *App) storageError(w http.ResponseWriter, err error) {
	if errors.Is(err, errWorkspaceFull) {
		problem(w, http.StatusInsufficientStorage, err.Error())
		return
	}
	log.Printf("workspace failure: %v", err)
	problem(w, http.StatusInternalServerError, "อ่านหรือบันทึกข้อมูลไม่สำเร็จ ลองอีกครั้ง")
}

func (a *App) chat(w http.ResponseWriter, r *http.Request) {
	a.openWorkspace(w, r, func(_ string, ws Workspace) {
		index := ws.find(r.PathValue("id"))
		if index < 0 {
			problem(w, http.StatusNotFound, "ไม่พบแชตนี้")
			return
		}
		sendJSON(w, http.StatusOK, publicChat(ws.Chats[index]))
	})
}

func (a *App) profile(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Name string `json:"name"`
	}
	if !decode(w, r, &input) {
		return
	}
	name := strings.TrimSpace(input.Name)
	if utf8.RuneCountInString(name) > 40 || strings.ContainsAny(name, "\x00\r\n") {
		problem(w, http.StatusBadRequest, "ชื่อโปรไฟล์ต้องยาวไม่เกิน 40 ตัวอักษร")
		return
	}
	a.openWorkspace(w, r, func(id string, ws Workspace) {
		ws.Name = name
		if err := a.store.save(id, ws); err != nil {
			a.storageError(w, err)
			return
		}
		sendJSON(w, http.StatusOK, map[string]string{"name": name})
	})
}

func validRequest(input SendRequest) bool {
	if len(input.Prompt) > 12000 || len(input.Files) > 4 ||
		(input.Prompt == "" && len(input.Files) == 0) {
		return false
	}
	total := 0
	for _, file := range input.Files {
		if strings.TrimSpace(file.Name) == "" || len(file.Name) > 255 ||
			strings.ContainsAny(file.Name, "/\\\x00\r\n") ||
			strings.ContainsRune(file.Content, '\x00') || len(file.Content) > maxFileBytes {
			return false
		}
		total += len(file.Content)
	}
	return total <= 192*1024
}

func titleFor(input SendRequest) string {
	title := strings.Join(strings.Fields(input.Prompt), " ")
	if title == "" {
		title = input.Files[0].Name
	}
	return excerpt(title, 66)
}

func excerpt(value string, limit int) string {
	chars := []rune(value)
	if len(chars) <= limit {
		return value
	}
	return string(chars[:limit]) + "…"
}

func (a *App) send(w http.ResponseWriter, r *http.Request) {
	var input SendRequest
	if !decode(w, r, &input) {
		return
	}
	input.Prompt = strings.TrimSpace(input.Prompt)
	if !validRequest(input) {
		problem(w, http.StatusBadRequest, "ใช้ข้อความไม่เกิน 12 KB และแนบไฟล์ข้อความได้สูงสุด 4 ไฟล์ ไฟล์ละ 64 KiB รวม 192 KiB")
		return
	}
	models := a.models()
	modelIndex := slices.IndexFunc(models, func(model Model) bool { return model.ID == input.Model })
	if modelIndex < 0 {
		problem(w, http.StatusBadRequest, "โมเดลนี้ยังไม่ได้ตั้งค่า")
		return
	}
	a.openWorkspace(w, r, func(id string, ws Workspace) {
		index := ws.find(input.ChatID)
		var chat Chat
		if input.ChatID != "" {
			if index < 0 {
				problem(w, http.StatusNotFound, "ไม่พบแชตนี้")
				return
			}
			chat = ws.Chats[index]
			if len(chat.Turns) >= 40 {
				problem(w, http.StatusConflict, "แชตนี้ครบ 40 ข้อความแล้ว เปิดแชตใหม่เพื่อคุยต่อ")
				return
			}
		} else {
			if len(ws.Chats) >= 40 {
				problem(w, http.StatusConflict, "ถึงขีดจำกัด 40 แชต ลบแชตเก่าก่อนเปิดแชตใหม่")
				return
			}
			chatID, err := newID()
			if err != nil {
				a.storageError(w, err)
				return
			}
			chat = Chat{ID: chatID, Title: titleFor(input)}
		}

		reply, err := a.reply(r.Context(), input, chat)
		if err != nil {
			if errors.Is(err, errProviderContext) {
				problem(w, http.StatusRequestEntityTooLarge, "ไฟล์แนบกับข้อความยาวเกินขีดจำกัดโหมด AI ลองเอาไฟล์บางส่วนออกหรือย่อข้อความ")
				return
			}
			log.Printf("reply failed (%s): %v", input.Model, err)
			message := "เอนจิน Rust ยังไม่พร้อม ตรวจสอบการตั้งค่าแล้วส่งอีกครั้ง"
			if input.Model == "ai" {
				message = "เรียกโมเดล AI ไม่สำเร็จ ตรวจสอบการตั้งค่าแล้วส่งอีกครั้ง"
			}
			problem(w, http.StatusBadGateway, message)
			return
		}
		chat.Turns = append(chat.Turns, Turn{input.Prompt, reply, models[modelIndex].Name, input.Files})
		chat.Redo = nil
		chat.Updated = time.Now().UTC()
		if index >= 0 {
			ws.Chats = slices.Delete(ws.Chats, index, index+1)
		}
		ws.Chats = append([]Chat{chat}, ws.Chats...)
		if err := a.store.save(id, ws); err != nil {
			a.storageError(w, err)
			return
		}
		sendJSON(w, http.StatusOK, map[string]any{"chat": publicChat(chat), "chats": ws.summaries()})
	})
}

func (a *App) chatAction(w http.ResponseWriter, r *http.Request) {
	if !decode(w, r, &struct{}{}) {
		return
	}
	a.openWorkspace(w, r, func(id string, ws Workspace) {
		index := ws.find(r.PathValue("id"))
		if index < 0 {
			problem(w, http.StatusNotFound, "ไม่พบแชตนี้")
			return
		}
		chat := &ws.Chats[index]
		switch r.PathValue("action") {
		case "summary":
			sendJSON(w, http.StatusOK, map[string]string{"summary": summarize(*chat)})
			return
		case "undo":
			if len(chat.Turns) > 0 {
				last := len(chat.Turns) - 1
				chat.Redo = append(chat.Redo, chat.Turns[last])
				chat.Turns = slices.Delete(chat.Turns, last, last+1)
			}
		case "redo":
			if len(chat.Redo) > 0 {
				last := len(chat.Redo) - 1
				chat.Turns = append(chat.Turns, chat.Redo[last])
				chat.Redo = slices.Delete(chat.Redo, last, last+1)
			}
		case "delete":
			ws.Chats = slices.Delete(ws.Chats, index, index+1)
			chat = nil
		default:
			problem(w, http.StatusNotFound, "ไม่พบคำสั่งนี้")
			return
		}
		var view any
		if chat != nil {
			chat.Updated = time.Now().UTC()
			view = publicChat(*chat)
			changed := *chat
			ws.Chats = slices.Delete(ws.Chats, index, index+1)
			ws.Chats = append([]Chat{changed}, ws.Chats...)
		}
		if err := a.store.save(id, ws); err != nil {
			a.storageError(w, err)
			return
		}
		sendJSON(w, http.StatusOK, map[string]any{"chat": view, "chats": ws.summaries()})
	})
}

func summarize(chat Chat) string {
	if len(chat.Turns) == 0 {
		return "แชตนี้ยังไม่มีข้อความให้สรุป"
	}
	var summary strings.Builder
	fmt.Fprintf(&summary, "สรุปแชต · %d รอบ\n", len(chat.Turns))
	first := max(0, len(chat.Turns)-5)
	if first > 0 {
		summary.WriteString("แสดง 5 รอบล่าสุด\n")
	}
	for _, turn := range chat.Turns[first:] {
		topic := strings.Join(strings.Fields(turn.Prompt), " ")
		if topic == "" && len(turn.Files) > 0 {
			topic = turn.Files[0].Name
		}
		fmt.Fprintf(&summary, "\n• %s\n  %s\n", excerpt(topic, 120), excerpt(strings.Join(strings.Fields(turn.Reply), " "), 160))
	}
	return strings.TrimSpace(summary.String())
}

func (a *App) reply(ctx context.Context, input SendRequest, chat Chat) (string, error) {
	if input.Model == "ai" {
		return a.provider.complete(ctx, input, chat)
	}
	if len(input.Files) == 0 {
		return "Workspace พร้อมวิเคราะห์ไฟล์โค้ด กด + แล้วแนบไฟล์เพื่อดูจำนวนบรรทัด ขนาดไฟล์ และตำแหน่ง TODO/FIXME\n\nถ้าต้องการถามเรื่องโค้ด ให้เลือกโมเดล AI ในเมนูโมเดลหลังจากตั้งค่าผู้ให้บริการ", nil
	}
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	var answer strings.Builder
	answer.WriteString("ผลวิเคราะห์ไฟล์\n")
	for _, file := range input.Files {
		command := exec.CommandContext(ctx, a.engine)
		command.Stdin = strings.NewReader(file.Content)
		data, err := command.Output()
		if err != nil {
			return "", err
		}
		var report struct {
			Bytes    int `json:"bytes"`
			Lines    int `json:"lines"`
			NonBlank int `json:"non_blank"`
			Longest  int `json:"longest"`
			Notes    []struct {
				Line int    `json:"line"`
				Text string `json:"text"`
			} `json:"notes"`
		}
		if err := json.Unmarshal(data, &report); err != nil {
			return "", err
		}
		fmt.Fprintf(&answer, "\n%s\n%d ไบต์ · %d บรรทัด · %d บรรทัดที่มีข้อความ\nบรรทัดยาวที่สุด %d ตัวอักษร\n", file.Name, report.Bytes, report.Lines, report.NonBlank, report.Longest)
		if len(report.Notes) == 0 {
			answer.WriteString("ไม่พบ TODO หรือ FIXME\n")
		}
		for _, note := range report.Notes {
			fmt.Fprintf(&answer, "บรรทัด %d  %s\n", note.Line, note.Text)
		}
	}
	return strings.TrimSpace(answer.String()), nil
}
