use serde::Serialize;
use std::io::{self, Read, Write};
use std::process::ExitCode;

const MAX_BYTES: usize = 64 * 1024;

#[derive(Debug, Serialize)]
struct Note {
    line: usize,
    text: String,
}

#[derive(Debug, Serialize)]
struct Analysis {
    bytes: usize,
    lines: usize,
    non_blank: usize,
    longest: usize,
    notes: Vec<Note>,
}

fn analyze(text: &str) -> Analysis {
    let mut result = Analysis {
        bytes: text.len(),
        lines: 0,
        non_blank: 0,
        longest: 0,
        notes: Vec::new(),
    };
    for (index, line) in text.lines().enumerate() {
        result.lines = index + 1;
        result.longest = result.longest.max(line.chars().count());
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        result.non_blank += 1;
        if result.notes.len() < 8
            && ["TODO", "FIXME"].iter().any(|tag| {
                trimmed
                    .split(|ch: char| !ch.is_alphanumeric() && ch != '_')
                    .any(|word| word == *tag)
            })
        {
            result.notes.push(Note {
                line: index + 1,
                text: trimmed.chars().take(180).collect(),
            });
        }
    }
    result
}

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let mut text = String::new();
    io::stdin()
        .take((MAX_BYTES + 1) as u64)
        .read_to_string(&mut text)?;
    if text.len() > MAX_BYTES {
        return Err("input is larger than 64 KiB".into());
    }
    if text.chars().any(|ch| ch == '\0') {
        return Err("input must be a text file".into());
    }
    let mut output = io::stdout().lock();
    serde_json::to_writer(&mut output, &analyze(&text))?;
    output.write_all(b"\n")?;
    Ok(())
}

fn main() -> ExitCode {
    if let Err(error) = run() {
        eprintln!("{error}");
        return ExitCode::FAILURE;
    }
    ExitCode::SUCCESS
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reports_unicode_lines_and_note_positions() {
        let metrics = analyze("กข\r\n\r\n// TODO: test\nTODOS\n");
        assert_eq!(metrics.lines, 4);
        assert_eq!(metrics.non_blank, 3);
        assert_eq!(metrics.longest, 13);
        assert_eq!(metrics.notes.len(), 1);
        assert_eq!(metrics.notes[0].line, 3);
        assert_eq!(analyze("").lines, 0);
    }
}
