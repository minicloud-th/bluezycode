import { cp, mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import path from 'node:path'

const root = path.resolve(import.meta.dirname, '..')
const server = path.join(root, 'dist/server')
const web = path.join(root, 'web')
const engine = path.join(root, 'engine')
const go = process.env.BLUEZY_GO || 'go'
const cargo = process.env.BLUEZY_CARGO || 'cargo'
const run = (command, args, cwd, env = process.env) =>
  execFileSync(command, args, { cwd, env, stdio: 'inherit' })

await rm(path.join(root, 'dist'), { force: true, recursive: true })
await mkdir(server, { recursive: true })
run('npm', ['run', 'build'], web)
run(go, ['build', '-buildvcs=false', '-trimpath', '-ldflags=-s -w', '-o', path.join(server, 'go-api.wasm'), '.'],
  path.join(root, 'server'), { ...process.env, GOOS: 'js', GOARCH: 'wasm', CGO_ENABLED: '0' })
run(cargo, ['build', '--locked', '--release', '--lib', '--target', 'wasm32-unknown-unknown'], engine,
  { ...process.env, CARGO_PROFILE_RELEASE_OPT_LEVEL: 's', CARGO_PROFILE_RELEASE_STRIP: 'true' })
await cp(path.join(engine, 'target/wasm32-unknown-unknown/release/bluezy_engine.wasm'), path.join(server, 'rust-engine.wasm'))
const goRoot = execFileSync(go, ['env', 'GOROOT'], { encoding: 'utf8' }).trim()
await cp(path.join(goRoot, 'lib/wasm/wasm_exec.js'), path.join(server, 'wasm_exec.js'))
await cp(path.join(root, 'worker/index.js'), path.join(server, 'index.js'))

const types = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.mjs': 'application/javascript; charset=utf-8',
  '.wasm': 'application/wasm', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8',
}
const staticRoot = path.join(web, 'dist')
const assets = {}
for (const entry of await readdir(staticRoot, { recursive: true, withFileTypes: true })) {
  const type = types[path.extname(entry.name)]
  if (!entry.isFile() || !type) continue
  const filename = path.join(entry.parentPath, entry.name)
  assets['/' + path.relative(staticRoot, filename).split(path.sep).join('/')] = {
    type, data: (await readFile(filename)).toString('base64'),
  }
}
if (!assets['/index.html']) throw new Error('Missing BLUEZYCODE HTML entry point')
await writeFile(path.join(server, 'assets.js'), 'export default ' + JSON.stringify(assets) + '\n')
await mkdir(path.join(root, 'dist/.openai'), { recursive: true })
await cp(path.join(root, '.openai/hosting.json'), path.join(root, 'dist/.openai/hosting.json'))
