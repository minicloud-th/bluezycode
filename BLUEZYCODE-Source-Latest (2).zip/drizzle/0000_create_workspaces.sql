CREATE TABLE bluezy_workspaces (
  workspace_id TEXT PRIMARY KEY NOT NULL,
  revision TEXT NOT NULL,
  payload BLOB NOT NULL
);
