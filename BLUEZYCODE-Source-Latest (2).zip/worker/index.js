import './wasm_exec.js'
import goModule from './go-api.wasm'
import rustModule from './rust-engine.wasm'
import assets from './assets.js'

const encoder = new TextEncoder()
const decoder = new TextDecoder('utf-8', { fatal: true })
const maxRequestBytes = 1280 * 1024
const noStore = { 'Cache-Control': 'no-store' }
const securityHeaders = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self' 'wasm-unsafe-eval' https://apis.google.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: https://lh3.googleusercontent.com https://lh4.googleusercontent.com https://lh5.googleusercontent.com https://lh6.googleusercontent.com",
    "connect-src 'self' https://huggingface.co https://*.hf.co https://*.huggingface.co https://identitytoolkit.googleapis.com https://securetoken.googleapis.com https://www.googleapis.com",
    "worker-src 'self' blob:",
    "frame-src https://bluezycode.firebaseapp.com",
    "frame-ancestors 'self' https://chatgpt.com https://*.chatgpt.com",
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'self'",
  ].join('; '),
}

let goRuntime
let rustRuntime
function startGo() {
  if (!goRuntime) {
    goRuntime = (async () => {
      const go = new globalThis.Go()
      rustRuntime ??= (await WebAssembly.instantiate(rustModule)).exports
      const instance = await WebAssembly.instantiate(goModule, go.importObject)
      go.run(instance).catch(() => {
        goRuntime = undefined
        console.error('BLUEZYCODE Go runtime stopped')
      })
      return globalThis.bluezyHandle
    })().catch(error => {
      goRuntime = undefined
      throw error
    })
  }
  return goRuntime
}

function analyze(text) {
  try {
    const bytes = encoder.encode(text)
    if (bytes.length > 64 * 1024) return null
    new Uint8Array(rustRuntime.memory.buffer, rustRuntime.input_pointer(), bytes.length).set(bytes)
    const length = rustRuntime.analyze_text(bytes.length)
    return length ? decoder.decode(new Uint8Array(rustRuntime.memory.buffer, rustRuntime.output_pointer(), length)) : null
  } catch (error) {
    console.error('BLUEZYCODE Rust analyzer stopped', error instanceof Error ? error.message : '')
    return null
  }
}

function hostBindings(env) {
  const database = env.DB
  const useGemini = !env.BLUEZY_AI_ENDPOINT && Boolean(env.GEMINI_API_KEY)
  return {
    async load(id) {
      const row = await database
        .prepare('SELECT revision, payload FROM bluezy_workspaces WHERE workspace_id = ?')
        .bind(id).first()
      return row ? { revision: row.revision, payload: Uint8Array.from(row.payload) } : null
    },
    async save(id, expected, revision, payload) {
      const data = payload.buffer
      const statement = expected
        ? database.prepare('UPDATE bluezy_workspaces SET revision = ?, payload = ? WHERE workspace_id = ? AND revision = ?')
            .bind(revision, data, id, expected)
        : database.prepare('INSERT INTO bluezy_workspaces (workspace_id, revision, payload) VALUES (?, ?, ?) ON CONFLICT(workspace_id) DO NOTHING')
            .bind(id, revision, data)
      return (await statement.run()).meta.changes === 1
    },
    analyze,
    async complete(endpoint, key, body) {
      const headers = { 'Content-Type': 'application/json' }
      if (key) headers.Authorization = 'Bearer ' + key
      const response = await fetch(endpoint, {
        method: 'POST', headers, body, redirect: 'manual', signal: AbortSignal.timeout(45_000),
      })
      if (response.status !== 200) throw new Error('AI provider request failed')
      const result = await readBody(response, 1024 * 1024)
      if (!result) throw new Error('AI provider response too large')
      return result
    },
    provider: {
      endpoint: env.BLUEZY_AI_ENDPOINT || (useGemini ? 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions' : ''),
      model: env.BLUEZY_AI_MODEL || (useGemini ? 'gemini-2.5-flash' : ''),
      key: env.BLUEZY_AI_KEY || (useGemini ? env.GEMINI_API_KEY : ''),
    },
  }
}

async function readBody(request, limit = maxRequestBytes) {
  if (!request.body) return new Uint8Array()
  const reader = request.body.getReader()
  const chunks = []
  let size = 0
  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      size += value.byteLength
      if (size > limit) {
        void reader.cancel().catch(() => {})
        return null
      }
      chunks.push(value)
    }
  } finally {
    reader.releaseLock()
  }
  const body = new Uint8Array(size)
  let offset = 0
  for (const chunk of chunks) {
    body.set(chunk, offset)
    offset += chunk.byteLength
  }
  return body
}

async function handleAPI(request, env) {
  const body = await readBody(request)
  if (!body) return Response.json({ error: 'ข้อมูลมีขนาดใหญ่เกินไป' }, { status: 413, headers: noStore })
  try {
    const handler = await startGo()
    const result = await handler({
      method: request.method,
      url: request.url,
      headers: [...request.headers],
      body,
    }, hostBindings(env))
    const responseBody = request.method === 'HEAD' || result.status === 204 ? null : result.body
    return new Response(responseBody, {
      status: result.status,
      headers: result.headers,
    })
  } catch (error) {
    console.error('BLUEZYCODE could not process an API request', error instanceof Error ? error.name : '')
    return Response.json({ error: 'ระบบยังไม่พร้อม ลองใหม่อีกครั้ง' }, { status: 503, headers: noStore })
  }
}

function decodeAsset(base64) {
  if (typeof Uint8Array.fromBase64 === 'function') return Uint8Array.fromBase64(base64)
  const decoded = atob(base64)
  const bytes = new Uint8Array(decoded.length)
  for (let index = 0; index < bytes.length; index++) {
    bytes[index] = decoded.charCodeAt(index)
  }
  return bytes
}

export default {
  async fetch(request, env) {
    const { pathname } = new URL(request.url)
    if (pathname.startsWith('/api/')) {
      if (!request.headers.get('oai-authenticated-user-id')) {
        return Response.json({ error: 'กรุณาลงชื่อเข้าใช้ก่อนเปิด Workspace' }, { status: 401, headers: noStore })
      }
      return handleAPI(request, env)
    }
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      return new Response(null, { status: 405, headers: { Allow: 'GET, HEAD' } })
    }
    const assetPath = Object.hasOwn(assets, pathname) ? pathname : pathname.replace(/\/$/, '') + '/index.html'
    const asset = Object.hasOwn(assets, assetPath) ? assets[assetPath] : undefined
    if (!asset) return new Response('ไม่พบหน้านี้', { status: 404, headers: securityHeaders })
    const data = request.method === 'HEAD' ? null : decodeAsset(asset.data)
    return new Response(data, {
      headers: {
        ...securityHeaders,
        'Content-Type': asset.type,
        'Cache-Control': assetPath.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache',
      },
    })
  },
}
