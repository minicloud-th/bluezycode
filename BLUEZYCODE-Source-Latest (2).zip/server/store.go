package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"time"
)

const maxWorkspaceBytes = 8 * 1024 * 1024

var errWorkspaceFull = errors.New("พื้นที่จัดเก็บเต็ม ลบแชตเก่าแล้วลองอีกครั้ง")

type File struct {
	Name    string `json:"name"`
	Content string `json:"content,omitempty"`
}

type Turn struct {
	Prompt string `json:"prompt"`
	Reply  string `json:"reply"`
	Model  string `json:"model"`
	Files  []File `json:"files"`
}

type Chat struct {
	ID      string    `json:"id"`
	Title   string    `json:"title"`
	Updated time.Time `json:"updated"`
	Turns   []Turn    `json:"turns"`
	Redo    []Turn    `json:"redo,omitempty"`
}

type ChatSummary struct {
	ID      string    `json:"id"`
	Title   string    `json:"title"`
	Updated time.Time `json:"updated"`
}

type Workspace struct {
	Name     string `json:"name"`
	Chats    []Chat `json:"chats"`
	revision time.Time
	version  string
}

type WorkspaceStorage interface {
	load(context.Context, string) (Workspace, error)
	save(context.Context, string, Workspace) error
}

type Storage struct {
	dir string
}

type WorkspaceLocks [64]sync.Mutex

func newID() (string, error) {
	var bytes [24]byte
	if _, err := rand.Read(bytes[:]); err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes[:]), nil
}

func (a *App) workspaceID(r *http.Request) string {
	cookie, err := r.Cookie(a.cookieName)
	if err != nil || len(cookie.Value) != 48 {
		return ""
	}
	if _, err := hex.DecodeString(cookie.Value); err != nil {
		return ""
	}
	return cookie.Value
}

func (locks *WorkspaceLocks) lock(id string) func() {
	index, _ := strconv.ParseUint(id[:2], 16, 8)
	mutex := &locks[index%uint64(len(locks))]
	mutex.Lock()
	return mutex.Unlock
}

func (s *Storage) load(_ context.Context, id string) (Workspace, error) {
	workspace := Workspace{Chats: []Chat{}}
	data, err := os.ReadFile(filepath.Join(s.dir, id+".json"))
	if errors.Is(err, fs.ErrNotExist) {
		return workspace, nil
	}
	if err != nil {
		return Workspace{}, err
	}
	err = json.Unmarshal(data, &workspace)
	return workspace, err
}

func (s *Storage) save(_ context.Context, id string, workspace Workspace) error {
	data, err := json.Marshal(workspace)
	if err != nil {
		return err
	}
	if len(data) > maxWorkspaceBytes {
		return errWorkspaceFull
	}
	file, err := os.CreateTemp(s.dir, ".workspace-*.tmp")
	if err != nil {
		return err
	}
	defer os.Remove(file.Name())
	_, writeErr := file.Write(data)
	if writeErr == nil {
		writeErr = file.Sync()
	}
	if err := errors.Join(writeErr, file.Close()); err != nil {
		return fmt.Errorf("write workspace: %w", err)
	}
	return os.Rename(file.Name(), filepath.Join(s.dir, id+".json"))
}

func (w Workspace) find(id string) int {
	for index, chat := range w.Chats {
		if chat.ID == id {
			return index
		}
	}
	return -1
}

func (w Workspace) summaries() []ChatSummary {
	summaries := make([]ChatSummary, 0, len(w.Chats))
	for _, chat := range w.Chats {
		summaries = append(summaries, ChatSummary{chat.ID, chat.Title, chat.Updated})
	}
	return summaries
}

func publicChat(chat Chat) map[string]any {
	turns := make([]Turn, 0, len(chat.Turns))
	for _, turn := range chat.Turns {
		files := make([]File, 0, len(turn.Files))
		for _, file := range turn.Files {
			files = append(files, File{Name: file.Name})
		}
		turn.Files = files
		turns = append(turns, turn)
	}
	return map[string]any{
		"id": chat.ID, "title": chat.Title, "updated": chat.Updated,
		"turns": turns, "canRedo": len(chat.Redo) > 0,
	}
}
