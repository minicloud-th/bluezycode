//go:build js && wasm

package main

import (
	"bytes"
	"context"
	"errors"
	"log"
	"net/http"
	"net/http/httptest"
	"syscall/js"
)

type edgeStore struct {
	host js.Value
}

func (s edgeStore) load(_ context.Context, id string) (Workspace, error) {
	row, err := await(s.host.Call("load", id))
	if err != nil {
		return Workspace{}, err
	}
	if row.IsNull() {
		return Workspace{Chats: []Chat{}}, nil
	}
	payload := row.Get("payload")
	data := make([]byte, payload.Get("length").Int())
	js.CopyBytesToGo(data, payload)
	ws, err := decodeWorkspace(data)
	ws.version = row.Get("revision").String()
	return ws, err
}

func (s edgeStore) save(_ context.Context, id string, ws Workspace) error {
	data, err := encodeWorkspace(ws)
	if err != nil {
		return err
	}
	revision, err := newID()
	if err != nil {
		return err
	}
	payload := asBytes(data)
	updated, err := await(s.host.Call("save", id, ws.version, revision, payload))
	if err == nil && !updated.Bool() {
		return errWorkspaceChanged
	}
	return err
}

type hostResult struct {
	value js.Value
	err   error
}

func await(promise js.Value) (js.Value, error) {
	ch := make(chan hostResult, 1)
	ok := js.FuncOf(func(_ js.Value, args []js.Value) any {
		ch <- hostResult{value: args[0]}
		return nil
	})
	fail := js.FuncOf(func(_ js.Value, _ []js.Value) any {
		ch <- hostResult{err: errors.New("Sites runtime operation failed")}
		return nil
	})
	defer ok.Release()
	defer fail.Release()
	promise.Call("then", ok, fail)
	result := <-ch
	return result.value, result.err
}

func asBytes(data []byte) js.Value {
	value := js.Global().Get("Uint8Array").New(len(data))
	js.CopyBytesToJS(value, data)
	return value
}

func handle(input, host js.Value) map[string]any {
	body := input.Get("body")
	data := make([]byte, body.Get("length").Int())
	js.CopyBytesToGo(data, body)
	req, err := http.NewRequest(input.Get("method").String(), input.Get("url").String(), bytes.NewReader(data))
	if err != nil {
		return map[string]any{"status": 400, "headers": []any{}, "body": asBytes(nil)}
	}
	headers := input.Get("headers")
	for i := 0; i < headers.Length(); i++ {
		header := headers.Index(i)
		req.Header.Add(header.Index(0).String(), header.Index(1).String())
	}
	config := host.Get("provider")
	provider, err := newProvider(config.Get("endpoint").String(), config.Get("model").String(), config.Get("key").String(),
		func(_ context.Context, endpoint, key string, body []byte) ([]byte, error) {
			result, err := await(host.Call("complete", endpoint, key, asBytes(body)))
			if err != nil {
				return nil, err
			}
			data := make([]byte, result.Get("length").Int())
			js.CopyBytesToGo(data, result)
			return data, nil
		},
	)
	if err != nil {
		log.Print("BLUEZYCODE provider config is incomplete")
	}
	app := &App{
		store: edgeStore{host: host}, cookieName: "bluezy_sites_workspace", secureCookie: req.URL.Scheme == "https",
		provider: provider,
		analyze: func(_ context.Context, text string) ([]byte, error) {
			result := host.Call("analyze", text)
			if result.IsNull() {
				return nil, errors.New("Rust analysis failed")
			}
			return []byte(result.String()), nil
		},
	}
	w := httptest.NewRecorder()
	app.apiRoutes().ServeHTTP(w, req)
	outHeaders := []any{}
	for name, values := range w.Result().Header {
		for _, value := range values {
			outHeaders = append(outHeaders, []any{name, value})
		}
	}
	return map[string]any{"status": w.Code, "headers": outHeaders, "body": asBytes(w.Body.Bytes())}
}

func main() {
	js.Global().Set("bluezyHandle", js.FuncOf(func(_ js.Value, args []js.Value) any {
		input, host := args[0], args[1]
		executor := js.FuncOf(func(_ js.Value, callbacks []js.Value) any {
			resolve, reject := callbacks[0], callbacks[1]
			go func() {
				defer func() {
					if failure := recover(); failure != nil {
						log.Print("BLUEZYCODE Worker request failed")
						reject.Invoke("BLUEZYCODE Worker request failed")
					}
				}()
				resolve.Invoke(handle(input, host))
			}()
			return nil
		})
		defer executor.Release()
		return js.Global().Get("Promise").New(executor)
	}))
	select {}
}
