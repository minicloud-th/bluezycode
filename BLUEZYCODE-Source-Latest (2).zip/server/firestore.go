//go:build !js

package main

import (
	"context"
	"time"

	"cloud.google.com/go/firestore"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

type FirestoreStorage struct {
	collection *firestore.CollectionRef
}

func (s *FirestoreStorage) load(ctx context.Context, id string) (Workspace, error) {
	document, err := s.collection.Doc(id).Get(ctx)
	if status.Code(err) == codes.NotFound {
		return Workspace{Chats: []Chat{}}, nil
	}
	if err != nil {
		return Workspace{}, err
	}
	var record struct {
		Payload []byte `firestore:"payload"`
	}
	if err := document.DataTo(&record); err != nil {
		return Workspace{}, err
	}
	workspace, err := decodeWorkspace(record.Payload)
	workspace.revision = document.UpdateTime
	return workspace, err
}

func (s *FirestoreStorage) save(ctx context.Context, id string, workspace Workspace) error {
	payload, err := encodeWorkspace(workspace)
	if err != nil {
		return err
	}
	document := s.collection.Doc(id)
	if workspace.revision.Equal(time.Time{}) {
		_, err = document.Create(ctx, map[string]any{"payload": payload})
	} else {
		_, err = document.Update(ctx, []firestore.Update{{Path: "payload", Value: payload}}, firestore.LastUpdateTime(workspace.revision))
	}
	switch status.Code(err) {
	case codes.AlreadyExists, codes.FailedPrecondition, codes.Aborted:
		return errWorkspaceChanged
	}
	return err
}
