//go:build !js

package main

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"
)

func providerFromEnv() (Provider, error) {
	return newProvider(os.Getenv("BLUEZY_AI_ENDPOINT"), os.Getenv("BLUEZY_AI_MODEL"), os.Getenv("BLUEZY_AI_KEY"), nativeProviderRequest)
}

var providerHTTPClient = &http.Client{
	Timeout: 45 * time.Second,
	CheckRedirect: func(_ *http.Request, _ []*http.Request) error {
		return http.ErrUseLastResponse
	},
}

func nativeProviderRequest(ctx context.Context, endpoint, key string, body []byte) ([]byte, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(body))
	if err != nil {
		return nil, errors.New("invalid provider request")
	}
	request.Header.Set("Content-Type", "application/json")
	if key != "" {
		request.Header.Set("Authorization", "Bearer "+key)
	}
	response, err := providerHTTPClient.Do(request)
	if err != nil {
		return nil, errors.New("provider request failed")
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("provider returned HTTP %d", response.StatusCode)
	}

	data, err := io.ReadAll(io.LimitReader(response.Body, 1024*1024+1))
	if err != nil || len(data) > 1024*1024 {
		return nil, errors.New("invalid provider response")
	}
	return data, nil
}
