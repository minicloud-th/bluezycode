package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"errors"
	"fmt"
	"io"
)

const maxWorkspacePayload = 950 * 1024

var errWorkspaceChanged = errors.New("มีการแก้ไขแชตพร้อมกัน โหลดล่าสุดแล้วลองอีกครั้ง")

func decodeWorkspace(payload []byte) (Workspace, error) {
	reader, err := gzip.NewReader(bytes.NewReader(payload))
	if err != nil {
		return Workspace{}, err
	}
	defer reader.Close()
	data, err := io.ReadAll(io.LimitReader(reader, maxWorkspaceBytes+1))
	if err != nil {
		return Workspace{}, err
	}
	if len(data) > maxWorkspaceBytes {
		return Workspace{}, errWorkspaceFull
	}
	var workspace Workspace
	err = json.Unmarshal(data, &workspace)
	return workspace, err
}

func encodeWorkspace(workspace Workspace) ([]byte, error) {
	data, err := json.Marshal(workspace)
	if err != nil {
		return nil, err
	}
	if len(data) > maxWorkspaceBytes {
		return nil, errWorkspaceFull
	}
	var output bytes.Buffer
	writer := gzip.NewWriter(&output)
	_, writeErr := writer.Write(data)
	if err := errors.Join(writeErr, writer.Close()); err != nil {
		return nil, fmt.Errorf("compress workspace: %w", err)
	}
	if output.Len() > maxWorkspacePayload {
		return nil, errWorkspaceFull
	}
	return output.Bytes(), nil
}
