//go:build !js

package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"cloud.google.com/go/firestore"
)

func main() {
	provider, err := providerFromEnv()
	if err != nil {
		log.Fatal(err)
	}
	app := &App{
		locks: &WorkspaceLocks{}, provider: provider,
		secureCookie: os.Getenv("BLUEZY_SECURE_COOKIE") == "1",
		cookieName:   "bluezy_workspace",
	}
	engine, err := exec.LookPath(env("BLUEZY_ENGINE", "bluezy-engine"))
	if err == nil {
		app.analyze = func(ctx context.Context, text string) ([]byte, error) {
			command := exec.CommandContext(ctx, engine)
			command.Stdin = strings.NewReader(text)
			return command.Output()
		}
	}
	if project := os.Getenv("BLUEZY_FIRESTORE_PROJECT"); project != "" {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		client, err := firestore.NewClientWithDatabase(ctx, project, env("BLUEZY_FIRESTORE_DATABASE", "(default)"))
		cancel()
		if err != nil {
			log.Fatal(err)
		}
		defer client.Close()
		app.store = &FirestoreStorage{collection: client.Collection("bluezycodeWorkspaces")}
		app.cookieName = "__session"
		app.secureCookie = true
		app.hostingOrigins = []string{"https://" + project + ".web.app", "https://" + project + ".firebaseapp.com"}
	} else {
		dir := env("BLUEZY_DATA_DIR", "data")
		if err := os.MkdirAll(dir, 0700); err != nil {
			log.Fatal(err)
		}
		app.store = &Storage{dir: dir}
	}
	web := env("BLUEZY_WEB_DIR", "web/dist")
	if _, err := os.Stat(filepath.Join(web, "index.html")); err != nil {
		log.Fatalf("web build unavailable: %v", err)
	}
	address := "127.0.0.1:8080"
	if port := os.Getenv("PORT"); port != "" {
		address = "0.0.0.0:" + port
	}
	server := http.Server{
		Addr: env("BLUEZY_ADDR", address), Handler: app.routes(web),
		ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 15 * time.Second,
		WriteTimeout: 65 * time.Second, IdleTimeout: 60 * time.Second,
	}
	log.Printf("BLUEZYCODE listening on %s", server.Addr)
	log.Fatal(server.ListenAndServe())
}

func (a *App) routes(web string) http.Handler {
	mux := http.NewServeMux()
	mux.Handle("/api/", a.apiRoutes())
	files := http.FileServer(http.Dir(web))
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "same-origin")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
		files.ServeHTTP(w, r)
	})
	return mux
}
