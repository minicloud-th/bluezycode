use bluezy_engine::{analyze, MAX_BYTES};
use std::io::{self, Read, Write};
use std::process::ExitCode;

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let mut text = String::new();
    io::stdin()
        .take((MAX_BYTES + 1) as u64)
        .read_to_string(&mut text)?;
    if text.len() > MAX_BYTES {
        return Err("input is larger than 64 KiB".into());
    }
    if text.chars().any(|ch| ch == '\0') {
        return Err("input must be a text file".into());
    }
    let mut output = io::stdout().lock();
    serde_json::to_writer(&mut output, &analyze(&text))?;
    output.write_all(b"\n")?;
    Ok(())
}

fn main() -> ExitCode {
    if let Err(error) = run() {
        eprintln!("{error}");
        return ExitCode::FAILURE;
    }
    ExitCode::SUCCESS
}
