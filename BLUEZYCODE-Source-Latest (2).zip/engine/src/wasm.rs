use super::{analyze, MAX_BYTES};
use std::{ptr, slice, str};

const OUTPUT_BYTES: usize = 16 * 1024;

// The Worker copies input, calls the analyzer, and copies its result synchronously.
static mut INPUT: [u8; MAX_BYTES] = [0; MAX_BYTES];
static mut OUTPUT: [u8; OUTPUT_BYTES] = [0; OUTPUT_BYTES];

#[no_mangle]
pub extern "C" fn input_pointer() -> *mut u8 {
    ptr::addr_of_mut!(INPUT).cast()
}

#[no_mangle]
pub extern "C" fn output_pointer() -> *const u8 {
    ptr::addr_of!(OUTPUT).cast()
}

#[no_mangle]
pub extern "C" fn analyze_text(length: usize) -> usize {
    if length > MAX_BYTES {
        return 0;
    }
    let input = unsafe { slice::from_raw_parts(input_pointer(), length) };
    let Ok(text) = str::from_utf8(input) else {
        return 0;
    };
    if text.contains('\0') {
        return 0;
    }
    let mut output =
        unsafe { slice::from_raw_parts_mut(ptr::addr_of_mut!(OUTPUT).cast(), OUTPUT_BYTES) };
    if serde_json::to_writer(&mut output, &analyze(text)).is_err() {
        return 0;
    }
    OUTPUT_BYTES - output.len()
}
