# BLUEZYCODE

BLUEZYCODE ใช้งานบน Cloudflare Pages ได้โดยไม่ต้องสร้างไฟล์ `.env` หรือตั้ง Environment Variables ในแดชบอร์ด

## รันจากซอร์ส

ใช้ Node.js 22.12 ขึ้นไป

```sh
npm ci
npm run dev
npm run lint
npm test
npm run build
```

## เผยแพร่บน Cloudflare Pages

สร้างโปรเจกต์ **Pages → Direct Upload** ใน Cloudflare Dashboard แล้วอัปโหลด ZIP ที่มี `index.html` และ `assets/` ที่ระดับบนสุด หรืออัปโหลดโฟลเดอร์ `dist` จาก `npm run build` ตั้งชื่อโปรเจกต์ `bluezycode` หากชื่อว่าง แล้วเปิด URL `pages.dev` ที่ Cloudflare แสดง

## การใช้งาน

- เปิดหน้าเว็บแล้วเริ่มใช้งานได้ทันที ประวัติแชต โปรไฟล์ และการตั้งค่าจะเก็บใน IndexedDB ของเบราว์เซอร์ที่เปิดเว็บ
- Qwen3 0.6B รันใน Web Worker ด้วย WebAssembly ครั้งแรกต้องใช้อินเทอร์เน็ตเพื่อดาวน์โหลดโมเดลประมาณ 400 MB ข้อความและไฟล์สำหรับโมเดลจะประมวลผลในเบราว์เซอร์
- โหมด Workspace ใช้วิเคราะห์ไฟล์ UTF-8 และค้นหา TODO/FIXME โดยไม่ต้องดาวน์โหลดโมเดล
- Firebase Authentication เป็นทางเลือก การลงชื่อเข้าใช้จะเปิด Workspace ของบัญชีนั้นบนเบราว์เซอร์เดิม ประวัติไม่ซิงก์ข้ามเครื่อง ข้อมูลจาก Express รุ่นเดิมจะไม่ถูกนำเข้าโดยอัตโนมัติ
- สำหรับ Google Sign-in ให้เพิ่มโดเมนจริงของโปรเจกต์ใน Firebase Authentication → Settings → Authorized domains ของโปรเจกต์ `bluezycode` ผู้ดูแล Firebase ต้องเปิดผู้ให้บริการ Google และ Email/Password ตามที่ต้องการ
