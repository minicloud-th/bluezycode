import type { ReactNode } from 'react'
import { motion } from 'motion/react'
import {
  Cloud,
  Gauge,
  Home,
  Lightbulb,
  MessageSquare,
  Search,
} from './icons'
import { IOS_SNAPPY_SPRING } from './motion'

export type RailSection = 'home' | 'chats' | 'search' | 'ideas' | 'cloud' | 'dashboard'

const MID_ITEMS: {
  id: RailSection
  title: string
  icon: typeof Home
}[] = [
  { id: 'home', title: 'หน้าหลัก', icon: Home },
  { id: 'chats', title: 'แชตทั้งหมด', icon: MessageSquare },
  { id: 'search', title: 'ค้นหา', icon: Search },
  { id: 'ideas', title: 'คำสั่งด่วน', icon: Lightbulb },
  { id: 'cloud', title: 'สถานะระบบ', icon: Cloud },
  { id: 'dashboard', title: 'แดชบอร์ด', icon: Gauge },
]

type RailProps = {
  section: RailSection
  chatCount: number
  busy: boolean
  ready: boolean
  onSelectSection(section: RailSection): void
  accountMenu: ReactNode
}

export function Rail({
  section,
  chatCount,
  busy,
  ready,
  onSelectSection,
  accountMenu,
}: RailProps) {
  return (
    <nav className="oc-rail" aria-label="แถบนำทางหลัก">
      <div className="oc-rail-top" title="BLUEZYCODE">
        <span className="bluezy-mark bluezy-mark-rail" role="img" aria-label="BLUEZYCODE" />
      </div>

      <div className="oc-rail-mid">
        {MID_ITEMS.map(item => {
          const ItemIcon = item.icon
          const active = section === item.id
          return (
            <motion.button
              key={item.id}
              type="button"
              className={'oc-rb' + (active ? ' on' : '')}
              title={item.title}
              aria-label={item.title}
              aria-current={active ? 'page' : undefined}
              disabled={!ready || busy}
              whileTap={!ready || busy ? undefined : { scale: 0.88 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={() => onSelectSection(item.id)}
            >
              {active && (
                <motion.span
                  layoutId="rail-active-pill"
                  className="oc-rb-bg"
                  transition={IOS_SNAPPY_SPRING}
                  aria-hidden="true"
                />
              )}
              <ItemIcon size={20} className="relative z-1" />
              {item.id === 'chats' && chatCount > 0 && (
                <span className="oc-bd tabular-nums">{chatCount}</span>
              )}
            </motion.button>
          )
        })}
      </div>

      <div className="oc-rail-bot">{accountMenu}</div>
    </nav>
  )
}
