import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import {
  Check,
  Copy,
  CreditCard,
  Database,
  Download,
  FileText,
  Gauge,
  HelpCircle,
  LogOut,
  Monitor,
  Moon,
  Plug,
  RefreshCw,
  Settings,
  Sun,
  User,
  X,
} from './icons'
import type {
  AccentColor,
  AuthUser,
  BillingCycle,
  ConnectorSettings,
  LanguagePreference,
  PlanId,
  SettingsTab,
  ThemePreference,
  Workspace,
  WorkspaceSettings,
} from './api'
import { errorMessage } from './api'
import { commands } from './Composer'
import { ProfileAvatar } from './ProfileAvatar'
import { prepareProfileImage } from './profileImage'
import { IOS_EASE, IOS_SHEET_SPRING, IOS_SNAPPY_SPRING, IOS_SOFT_SPRING } from './motion'

export const ACCENT_SWATCHES: AccentColor[] = [
  '#4a8dff',
  '#2f6df0',
  '#1fa3e8',
  '#a855f7',
  '#ec4899',
  '#f59e0b',
  '#84cc16',
  '#8b8b92',
]

export const PLAN_LABELS: Record<PlanId, string> = {
  free: 'BLUEZY Free',
  lite: 'BLUEZY Lite',
  pro: 'BLUEZY Pro',
  max: 'BLUEZY Max',
}

export type SettingsTabMeta = {
  id: SettingsTab
  label: string
  icon: typeof Settings
}

export const SETTINGS_TABS: SettingsTabMeta[] = [
  { id: 'general', label: 'ทั่วไป', icon: Settings },
  { id: 'account', label: 'โปรไฟล์', icon: User },
  { id: 'plan', label: 'BLUEZY Plan', icon: CreditCard },
  { id: 'dashboard', label: 'แดชบอร์ด', icon: Gauge },
  { id: 'connectors', label: 'การเชื่อมต่อภายนอก', icon: Plug },
  { id: 'privacy', label: 'ข้อมูลและความเป็นส่วนตัว', icon: Database },
  { id: 'about', label: 'เกี่ยวกับ BLUEZYCODE', icon: FileText },
]

type PlanCardDef = {
  id: Exclude<PlanId, 'free'>
  name: string
  popular?: boolean
  monthlyThb: number
  tagline: string
  credits: string
  features: string[]
}

const PLAN_CARDS: PlanCardDef[] = [
  {
    id: 'lite',
    name: 'Lite',
    monthlyThb: 590,
    tagline: 'สำหรับงานโค้ดประจำวัน',
    credits: '10,000 เครดิตวิเคราะห์ / สัปดาห์',
    features: [
      'ปลดล็อกคำสั่งวิเคราะห์ไฟล์ทั้งหมด',
      'โควต้าแชตต่อเนื่อง 40 ห้อง',
      'แนบไฟล์ข้อความ UTF-8 สูงสุด 4 ไฟล์/ครั้ง',
      'ส่งออกบทสนทนา Markdown & JSON',
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    popular: true,
    monthlyThb: 2490,
    tagline: 'สำหรับพัฒนาโปรเจกต์เต็มรูปแบบ',
    credits: '60,000 เครดิตวิเคราะห์ / สัปดาห์',
    features: [
      'ทุกฟีเจอร์ในแพ็กเกจ Lite',
      'เชื่อมต่อ AI Provider ภายนอกความเร็วสูง',
      'สรุปบริบทแชตอัตโนมัติ (/compact)',
      'พื้นที่จัดเก็บ Workspace 8 MB เต็มพิกัด',
    ],
  },
  {
    id: 'max',
    name: 'Max',
    monthlyThb: 4990,
    tagline: 'สำหรับทีมและงานระบบขนาดใหญ่',
    credits: '140,000 เครดิตวิเคราะห์ / สัปดาห์',
    features: [
      'ทุกฟีเจอร์ในแพ็กเกจ Pro',
      'คิวประมวลผลความสำคัญสูงสุดตลอดวัน',
      'รองรับ Connectors แจ้งเตือนแบบเรียลไทม์',
      'สิทธิ์เข้าถึงเอนจิน BLUEZYCODE รุ่นใหม่ก่อนใคร',
    ],
  },
]

const CONNECTORS_LIST: {
  key: keyof ConnectorSettings
  name: string
  desc: string
}[] = [
  { key: 'telegram', name: 'Telegram Bot', desc: 'รับสรุปโค้ดและแจ้งเตือนงานวิเคราะห์ผ่าน Telegram' },
  { key: 'discord', name: 'Discord Webhook', desc: 'ส่งรายงานผลการตรวจไฟล์เข้าสู่แชนเนลทีมของคุณ' },
  { key: 'line', name: 'LINE Notify / OA', desc: 'แจ้งเตือนสรุปแชตและสถานะ Workspace ทาง LINE' },
  { key: 'github', name: 'GitHub Sync', desc: 'เชื่อมโยงบริบท Repository สำหรับรีวิวโค้ด BLUEZYCODE' },
]

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}

function discountedPrice(monthly: number, cycle: BillingCycle): number {
  if (cycle === 'quarterly') return Math.round(monthly * 0.8)
  if (cycle === 'annually') return Math.round(monthly * 0.7)
  return monthly
}

export function SettingsModal({
  tab,
  showAppearance,
  workspace,
  authUser,
  busy,
  error,
  onSelectTab,
  onSaveSettings,
  onRefresh,
  onBulkAction,
  onExportAll,
  onOpenShortcuts,
  onLogout,
  onClose,
}: {
  tab: SettingsTab
  showAppearance: boolean
  workspace: Workspace
  authUser: AuthUser | null
  busy: boolean
  error: string
  onSelectTab(next: SettingsTab): void
  onSaveSettings(patch: Partial<WorkspaceSettings> & { name?: string }): Promise<boolean>
  onRefresh(): Promise<void>
  onBulkAction(action: 'archive-all' | 'restore-archived' | 'delete-all' | 'reset-account'): Promise<boolean>
  onExportAll(): void
  onOpenShortcuts(): void
  onLogout(): void
  onClose(): void
}) {
  const { settings, stats, archivedChats } = workspace
  const [accountName, setAccountName] = useState(workspace.name)
  const [accountEmail, setAccountEmail] = useState(settings.email)
  const [avatarError, setAvatarError] = useState('')
  const [preparingAvatar, setPreparingAvatar] = useState(false)
  const avatarInput = useRef<HTMLInputElement>(null)
  const [copiedId, setCopiedId] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [feedback, setFeedback] = useState('')
  const [confirmDanger, setConfirmDanger] = useState<'delete-all' | 'reset-account' | null>(null)
  const dialogRef = useRef<HTMLDivElement>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const appearanceRef = useRef<HTMLHeadingElement>(null)

  useEffect(() => {
    setAccountName(workspace.name)
    setAccountEmail(workspace.settings.email)
  }, [workspace.name, workspace.settings.email])

  useEffect(() => {
    setFeedback('')
    setConfirmDanger(null)
    setAvatarError('')
    if (bodyRef.current) {
      bodyRef.current.scrollTop = 0
    }
    const frame = requestAnimationFrame(() => {
      if (tab === 'general' && showAppearance) {
        appearanceRef.current?.focus({ preventScroll: true })
        appearanceRef.current?.scrollIntoView({ block: 'start' })
      } else if (!dialogRef.current?.contains(document.activeElement)) {
        dialogRef.current?.focus({ preventScroll: true })
      }
    })
    return () => cancelAnimationFrame(frame)
  }, [tab, showAppearance])

  useEffect(() => {
    if (!feedback) return
    const timer = setTimeout(() => setFeedback(''), 2600)
    return () => clearTimeout(timer)
  }, [feedback])

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape' && !busy) {
        event.preventDefault()
        onClose()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [busy, onClose])

  const displayName = workspace.name || 'ผู้ใช้'
  const photoURL = settings.avatar || authUser?.photoURL
  const aiModelName = workspace.models.find(item => item.id === 'ai')?.name
  const currentTabMeta = SETTINGS_TABS.find(item => item.id === tab) ?? SETTINGS_TABS[0]

  const chatUsagePct = Math.min(100, Math.round((stats.totalChats / stats.chatLimit) * 100))
  const storagePct = Math.min(
    100,
    Math.max(stats.storageBytes > 0 ? 1 : 0, Math.round((stats.storageBytes / stats.maxStorageBytes) * 100)),
  )

  async function savePatch(
    patch: Partial<WorkspaceSettings> & { name?: string },
    successText: string,
  ) {
    setFeedback('')
    const ok = await onSaveSettings(patch)
    if (ok) {
      setFeedback(successText)
    }
  }

  async function changeAvatar(file: File) {
    setAvatarError('')
    setPreparingAvatar(true)
    try {
      const avatar = await prepareProfileImage(file)
      await savePatch({ avatar }, 'เปลี่ยนรูปโปรไฟล์แล้ว')
    } catch (failure) {
      setAvatarError(errorMessage(failure))
    } finally {
      setPreparingAvatar(false)
    }
  }

  async function handleRefresh() {
    setRefreshing(true)
    try {
      await onRefresh()
    } finally {
      setRefreshing(false)
    }
  }

  async function copyPublicId() {
    let copied = false
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(workspace.publicId)
        copied = true
      }
    } catch {
      // Fallback below
    }
    if (!copied) {
      try {
        const el = document.createElement('textarea')
        el.value = workspace.publicId
        el.setAttribute('readonly', '')
        el.style.position = 'fixed'
        el.style.opacity = '0'
        document.body.appendChild(el)
        el.select()
        copied = document.execCommand('copy')
        document.body.removeChild(el)
      } catch {
        copied = false
      }
    }
    if (copied) {
      setCopiedId(true)
      setTimeout(() => setCopiedId(false), 1800)
    } else {
      setFeedback('ไม่สามารถคัดลอกอัตโนมัติได้')
    }
  }

  return (
    <motion.div
      className="oc-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.18, ease: IOS_EASE }}
      onMouseDown={event => {
        if (event.target === event.currentTarget && !busy) {
          onClose()
        }
      }}
    >
      <motion.div
        ref={dialogRef}
        className="oc-modal oc-settings"
        role="dialog"
        tabIndex={-1}
        aria-modal="true"
        aria-labelledby="sTitle"
        initial={{ opacity: 0, scale: 0.965, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.97, y: 6 }}
        transition={IOS_SHEET_SPRING}
      >
        <aside className="oc-snav" aria-label="หมวดหมู่การตั้งค่า">
          <h2>การตั้งค่า</h2>
          <div id="snavList">
            {SETTINGS_TABS.map(item => {
              const TabIcon = item.icon
              const isActive = item.id === tab
              return (
                <motion.button
                  key={item.id}
                  type="button"
                  className={'oc-nb' + (isActive ? ' on' : '')}
                  aria-current={isActive ? 'page' : undefined}
                  disabled={busy}
                  whileTap={busy ? undefined : { scale: 0.98 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => onSelectTab(item.id)}
                >
                  {isActive && (
                    <motion.span
                      layoutId="settings-tab-pill"
                      className="oc-nb-bg"
                      transition={IOS_SNAPPY_SPRING}
                      aria-hidden="true"
                    />
                  )}
                  <TabIcon size={17} className="relative z-1" />
                  <span className="relative z-1">{item.label}</span>
                </motion.button>
              )
            })}
          </div>
          <div className="oc-logout flex flex-col gap-0.5">
            <motion.button
              type="button"
              className="oc-nb"
              whileTap={{ scale: 0.98 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onOpenShortcuts}
            >
              <HelpCircle size={17} />
              <span>คีย์ลัดแป้นพิมพ์</span>
            </motion.button>
            <motion.button
              type="button"
              className="oc-nb oc-nb-danger"
              disabled={busy}
              whileTap={busy ? undefined : { scale: 0.98 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onLogout}
            >
              <LogOut size={17} />
              <span>ออกจากระบบ</span>
            </motion.button>
          </div>
        </aside>

        <section className="oc-spane">
          <header className="oc-ph oc-spane-head">
            <h2 id="sTitle">{currentTabMeta.label}</h2>
            <motion.button
              type="button"
              className="oc-x"
              aria-label="ปิดการตั้งค่า"
              disabled={busy}
              whileTap={busy ? undefined : { scale: 0.88 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onClose}
            >
              <X size={16} />
            </motion.button>
          </header>

          <div className="oc-spane-body" ref={bodyRef}>
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={tab}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -3 }}
                transition={{ duration: 0.16, ease: IOS_EASE }}
              >
            {tab === 'general' && (
              <>
                <button
                  type="button"
                  className="oc-card oc-row"
                  style={{ marginTop: 20 }}
                  onClick={() => onSelectTab('account')}
                >
                  <ProfileAvatar name={displayName} src={photoURL} size={34} />
                  <span>
                    <b>บัญชี BLUEZYCODE ({displayName})</b>
                    <small>{settings.email || 'จัดการชื่อ อีเมล และรหัส Workspace'}</small>
                  </span>
                  <span className="oc-sp">{PLAN_LABELS[settings.plan]}</span>
                </button>

                <div className="oc-lbl">การใช้งานพื้นที่ทำงาน</div>
                <div className="oc-card">
                  <div className="oc-row">
                    <span>
                      <b>{PLAN_LABELS[settings.plan]}</b>
                      <small>แชตที่ใช้งานอยู่</small>
                    </span>
                    <span className="oc-sp tabular-nums">
                      {stats.totalChats} / {stats.chatLimit} แชต
                    </span>
                  </div>
                  <div className="oc-bar">
                    <i style={{ width: `${chatUsagePct}%` }} />
                  </div>
                  <div className="oc-row">
                    <span>
                      <b>พื้นที่จัดเก็บ JSON Workspace</b>
                      <small>อัปเดตล่าสุดแบบเรียลไทม์</small>
                    </span>
                    <span className="oc-sp tabular-nums">
                      {formatBytes(stats.storageBytes)} / {formatBytes(stats.maxStorageBytes)}
                    </span>
                  </div>
                  <div className="oc-bar">
                    <i style={{ width: `${storagePct}%` }} />
                  </div>
                  <button
                    type="button"
                    className="oc-link"
                    style={{ fontSize: 14, fontWeight: 500 }}
                    onClick={() => onSelectTab('plan')}
                  >
                    อัปเกรดแพ็กเกจ
                  </button>
                </div>

                <div className="oc-card oc-row">
                  <label htmlFor="setting-language" style={{ flex: 1 }}>
                    <b>ภาษาเริ่มต้น</b>
                  </label>
                  <select
                    id="setting-language"
                    className="oc-select"
                    disabled={busy}
                    value={settings.language}
                    onChange={event => {
                      const language = event.target.value as LanguagePreference
                      void savePatch({ language }, 'บันทึกการตั้งค่าภาษาแล้ว')
                    }}
                  >
                    <option value="th">ไทย (TH)</option>
                    <option value="en">English (US)</option>
                    <option value="ja">日本語 (JA)</option>
                  </select>
                </div>

                <div className="oc-card oc-row">
                  <label htmlFor="setting-timezone" style={{ flex: 1 }}>
                    <b>เขตเวลา (Time zone)</b>
                  </label>
                  <select
                    id="setting-timezone"
                    className="oc-select"
                    disabled={busy}
                    value={settings.timezone}
                    onChange={event => {
                      void savePatch({ timezone: event.target.value }, 'บันทึกเขตเวลาแล้ว')
                    }}
                  >
                    <option value="Asia/Bangkok">อัตโนมัติ (Asia/Bangkok)</option>
                    <option value="UTC">UTC</option>
                    <option value="America/New_York">America/New_York</option>
                    <option value="Asia/Tokyo">Asia/Tokyo</option>
                  </select>
                </div>

                <h3 className="oc-lbl" ref={appearanceRef} tabIndex={-1}>รูปลักษณ์</h3>
                <div className="oc-card">
                  <div className="oc-row">
                    <b>โหมดหน้าจอ</b>
                    <div className="oc-seg" role="group" aria-label="โหมดการแสดงผล">
                      {(
                        [
                          ['light', 'โหมดสว่าง', Sun],
                          ['dark', 'โหมดมืด', Moon],
                          ['system', 'ตามระบบ', Monitor],
                        ] as const
                      ).map(([modeId, modeLabel, ModeIcon]) => {
                        const isSelected = settings.theme === modeId
                        return (
                          <button
                            key={modeId}
                            type="button"
                            aria-label={modeLabel}
                            title={modeLabel}
                            aria-pressed={isSelected}
                            className={isSelected ? 'on' : ''}
                            disabled={busy}
                            onClick={() => {
                              void savePatch({ theme: modeId as ThemePreference }, `เปลี่ยนเป็น${modeLabel}แล้ว`)
                            }}
                          >
                            {isSelected && (
                              <motion.span
                                layoutId="theme-seg-pill"
                                className="oc-seg-bg"
                                transition={IOS_SNAPPY_SPRING}
                                aria-hidden="true"
                              />
                            )}
                            <ModeIcon size={15} className="relative z-1" />
                          </button>
                        )
                      })}
                    </div>
                  </div>
                  <div className="oc-row" style={{ marginTop: 14 }}>
                    <b>สีเน้นธีม (Theme color)</b>
                  </div>
                  <div className="oc-sw" role="group" aria-label="สีธีม">
                    {ACCENT_SWATCHES.map((swatch, index) => {
                      const isSelected = settings.accentColor === swatch
                      return (
                        <motion.button
                          key={swatch}
                          type="button"
                          style={{ background: swatch }}
                          aria-label={`สีธีม ${index + 1}`}
                          aria-pressed={isSelected}
                          className={isSelected ? 'on' : ''}
                          disabled={busy}
                          whileTap={busy ? undefined : { scale: 0.85 }}
                          transition={IOS_SNAPPY_SPRING}
                          onClick={() => {
                            void savePatch({ accentColor: swatch }, 'บันทึกสีเน้นธีมแล้ว')
                          }}
                        >
                          {isSelected && (
                            <motion.span
                              layoutId="accent-swatch-ring"
                              className="oc-sw-ring"
                              transition={IOS_SNAPPY_SPRING}
                              aria-hidden="true"
                            />
                          )}
                        </motion.button>
                      )
                    })}
                  </div>
                </div>
              </>
            )}

            {tab === 'account' && (
              <>
                <form
                  onSubmit={event => {
                    event.preventDefault()
                    void savePatch(
                      { name: accountName.trim(), email: accountEmail.trim() },
                      'บันทึกข้อมูลบัญชี BLUEZYCODE แล้ว',
                    )
                  }}
                >
                  <div className="oc-card" style={{ marginTop: 20 }}>
                    <div className="oc-profile-photo">
                      <ProfileAvatar name={displayName} src={photoURL} size={64} />
                      <div className="oc-profile-photo-info">
                        <b>{displayName}</b>
                        <small>
                          {PLAN_LABELS[settings.plan]}
                          {authUser && ` · เข้าสู่ระบบด้วย ${authUser.provider === 'google' ? 'Google (Firebase)' : 'Email (Firebase)'}`}
                        </small>
                        <div className="oc-profile-photo-actions">
                          <button type="button" className="oc-sm" disabled={busy || preparingAvatar} onClick={() => avatarInput.current?.click()}>
                            {preparingAvatar ? 'กำลังเตรียมรูป...' : 'เปลี่ยนรูป'}
                          </button>
                          {settings.avatar && (
                            <button type="button" className="oc-link" disabled={busy || preparingAvatar}
                              onClick={() => {
                                setAvatarError('')
                                void savePatch({ avatar: '' }, 'ใช้รูปเริ่มต้นแล้ว')
                              }}>
                              ใช้รูปเริ่มต้น
                            </button>
                          )}
                        </div>
                      </div>
                      <input
                        ref={avatarInput}
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        hidden
                        onChange={event => {
                          const file = event.currentTarget.files?.[0]
                          event.currentTarget.value = ''
                          if (file) void changeAvatar(file)
                        }}
                      />
                    </div>
                    {avatarError && <p className="error" role="alert">{avatarError}</p>}

                    <label htmlFor="account-name" className="oc-lbl" style={{ display: 'block', marginTop: 6 }}>ชื่อที่แสดง</label>
                    <input
                      id="account-name"
                      className="oc-field"
                      maxLength={40}
                      placeholder="ผู้ใช้"
                      disabled={busy}
                      value={accountName}
                      onChange={event => setAccountName(event.target.value)}
                    />

                    <label htmlFor="account-email" className="oc-lbl" style={{ display: 'block', marginTop: 14 }}>อีเมลติดต่อ</label>
                    <input
                      id="account-email"
                      type="email"
                      className="oc-field"
                      maxLength={120}
                      placeholder="you@bluezycode.dev"
                      disabled={busy}
                      value={accountEmail}
                      onChange={event => setAccountEmail(event.target.value)}
                    />

                    <div className="oc-lbl" style={{ marginTop: 14 }}>รหัส Workspace สาธารณะ</div>
                    <div className="oc-readonly">
                      <code className="text-xs">{workspace.publicId}</code>
                      <button
                        type="button"
                        className="oc-copy-btn"
                        aria-label={copiedId ? 'คัดลอกรหัส Workspace แล้ว' : 'คัดลอกรหัส Workspace'}
                        onClick={() => void copyPublicId()}
                      >
                        {copiedId ? <Check size={14} /> : <Copy size={14} />}
                        <span>{copiedId ? 'คัดลอกแล้ว' : 'คัดลอก'}</span>
                      </button>
                    </div>

                    <button
                      type="submit"
                      className="oc-primary"
                      style={{ marginTop: 18 }}
                      disabled={busy}
                    >
                      บันทึกข้อมูลบัญชี
                    </button>
                  </div>
                </form>

                <div className="oc-card oc-danger-card" style={{ marginTop: 14 }}>
                  <div className="oc-row">
                    <span>
                      <b>รีเซ็ตบัญชีและพื้นที่ทำงาน</b>
                      <small>ลบประวัติแชตทั้งหมดและรีเซ็ตการตั้งค่ากลับเป็นค่าเริ่มต้น</small>
                    </span>
                    {confirmDanger === 'reset-account' ? (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          className="oc-sm danger"
                          disabled={busy}
                          onClick={() => {
                            void onBulkAction('reset-account').then(ok => {
                              if (ok) {
                                setConfirmDanger(null)
                                setFeedback('รีเซ็ตพื้นที่ทำงานเรียบร้อยแล้ว')
                              }
                            })
                          }}
                        >
                          ยืนยันรีเซ็ต
                        </button>
                        <button
                          type="button"
                          className="oc-sm"
                          disabled={busy}
                          onClick={() => setConfirmDanger(null)}
                        >
                          ยกเลิก
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        className="oc-sm danger"
                        disabled={busy}
                        onClick={() => setConfirmDanger('reset-account')}
                      >
                        รีเซ็ตบัญชี
                      </button>
                    )}
                  </div>
                </div>
              </>
            )}

            {tab === 'plan' && (
              <>
                <div className="flex flex-wrap items-center justify-between gap-2" style={{ marginTop: 18 }}>
                  <span className="oc-sp" style={{ marginLeft: 0 }}>
                    แพ็กเกจปัจจุบัน: {PLAN_LABELS[settings.plan]}
                  </span>
                  <div className="flex items-center gap-2">
                    <div className="oc-pill-seg" role="group" aria-label="รอบการชำระเงิน">
                      {(
                        [
                          ['monthly', 'รายเดือน'],
                          ['quarterly', 'รายไตรมาส -20%'],
                          ['annually', 'รายปี -30%'],
                        ] as const
                      ).map(([cycleId, cycleLabel]) => {
                        const isSelected = settings.billingCycle === cycleId
                        return (
                          <button
                            key={cycleId}
                            type="button"
                            aria-pressed={isSelected}
                            className={isSelected ? 'on' : ''}
                            disabled={busy}
                            onClick={() => {
                              void savePatch({ billingCycle: cycleId }, `เปลี่ยนรอบบิลเป็น${cycleLabel}แล้ว`)
                            }}
                          >
                            {isSelected && (
                              <motion.span
                                layoutId="cycle-seg-pill"
                                className="oc-seg-bg"
                                transition={IOS_SNAPPY_SPRING}
                                aria-hidden="true"
                              />
                            )}
                            <span className="relative z-1">{cycleLabel}</span>
                          </button>
                        )
                      })}
                    </div>
                    <button
                      type="button"
                      className="oc-rb"
                      aria-label="รีเฟรชแพ็กเกจ"
                      disabled={busy || refreshing}
                      onClick={() => void handleRefresh()}
                    >
                      <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
                    </button>
                  </div>
                </div>

                <div className="oc-plan-grid">
                  {PLAN_CARDS.map(card => {
                    const isCurrent = settings.plan === card.id
                    const price = discountedPrice(card.monthlyThb, settings.billingCycle)
                    return (
                      <div key={card.id} className={'oc-plan-card' + (isCurrent ? ' active' : '')}>
                        <div className="oc-plan-head">
                          <span>{card.name}</span>
                          {card.popular && <span className="oc-plan-badge">ยอดนิยม</span>}
                        </div>
                        <div className="oc-plan-price">
                          ฿{price.toLocaleString()}
                          <small> / เดือน</small>
                        </div>
                        <div className="oc-plan-desc">{card.tagline}</div>
                        <motion.button
                          type="button"
                          className={'oc-plan-cta' + (isCurrent ? ' current' : '')}
                          disabled={busy || isCurrent}
                          whileTap={busy || isCurrent ? undefined : { scale: 0.97 }}
                          transition={IOS_SNAPPY_SPRING}
                          onClick={() => {
                            void savePatch(
                              { plan: card.id },
                              `เปลี่ยนแพ็กเกจเป็น BLUEZY ${card.name} แล้ว`,
                            )
                          }}
                        >
                          {isCurrent ? 'แพ็กเกจปัจจุบัน' : `เลือก ${card.name}`}
                        </motion.button>
                        <div className="oc-plan-credits">{card.credits}</div>
                        <ul className="oc-plan-features">
                          {card.features.map(feature => (
                            <li key={feature}>
                              <Check size={13} className="mt-0.5 shrink-0" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )
                  })}
                </div>

                {settings.plan !== 'free' && (
                  <div className="mt-3 flex justify-end">
                    <button
                      type="button"
                      className="oc-sm"
                      disabled={busy}
                      onClick={() =>
                        void savePatch({ plan: 'free' }, 'สลับกลับเป็นแพ็กเกจ BLUEZY Free แล้ว')
                      }
                    >
                      สลับกลับแพ็กเกจ Free
                    </button>
                  </div>
                )}
              </>
            )}

            {tab === 'dashboard' && (
              <>
                <div className="flex items-center justify-between" style={{ marginTop: 18, marginBottom: 10 }}>
                  <span className="oc-sp" style={{ marginLeft: 0 }}>
                    สถิติการวิเคราะห์และพื้นที่จัดเก็บในเบราว์เซอร์นี้
                  </span>
                  <button
                    type="button"
                    className="oc-rb"
                    aria-label="รีเฟรชข้อมูลสถิติ"
                    disabled={busy || refreshing}
                    onClick={() => void handleRefresh()}
                  >
                    <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
                  </button>
                </div>

                <div className="oc-stats-2col">
                  <div className="oc-card">
                    <small className="text-[var(--muted)]">ข้อความวันนี้</small>
                    <div className="mt-1 text-2xl font-bold tabular-nums">{stats.todayTurns.toLocaleString()}</div>
                    <small className="text-[var(--muted)]">
                      ทั้งหมด {stats.totalTurns.toLocaleString()} ข้อความ
                    </small>
                  </div>
                  <div className="oc-card">
                    <small className="text-[var(--muted)]">โทเคนประมวลผลโดยประมาณ</small>
                    <div className="mt-1 text-2xl font-bold tabular-nums">{stats.estimatedTokens.toLocaleString()}</div>
                    <small className="text-[var(--muted)]">คำนวณจากข้อความและไฟล์ที่บันทึก</small>
                  </div>
                  <div className="oc-card">
                    <small className="text-[var(--muted)]">ไฟล์โค้ดที่วิเคราะห์แล้ว</small>
                    <div className="mt-1 text-2xl font-bold tabular-nums">{stats.totalFiles.toLocaleString()}</div>
                    <small className="text-[var(--muted)]">ไฟล์ข้อความ UTF-8</small>
                  </div>
                  <div className="oc-card">
                    <small className="text-[var(--muted)]">แชตที่เก็บถาวร</small>
                    <div className="mt-1 text-2xl font-bold tabular-nums">{stats.archivedChats.toLocaleString()}</div>
                    <small className="text-[var(--muted)]">{PLAN_LABELS[settings.plan]}</small>
                  </div>
                </div>

                <div className="oc-card" style={{ marginTop: 14 }}>
                  <div className="oc-row">
                    <b>แชตที่ใช้งานอยู่</b>
                    <span className="oc-sp tabular-nums">
                      {stats.totalChats} / {stats.chatLimit} ({chatUsagePct}%)
                    </span>
                  </div>
                  <div className="oc-bar">
                    <i style={{ width: `${chatUsagePct}%` }} />
                  </div>
                  <div className="oc-row">
                    <b>พื้นที่จัดเก็บ JSON</b>
                    <span className="oc-sp tabular-nums">
                      {formatBytes(stats.storageBytes)} / {formatBytes(stats.maxStorageBytes)} ({storagePct}%)
                    </span>
                  </div>
                  <div className="oc-bar" style={{ marginBottom: 0 }}>
                    <i style={{ width: `${storagePct}%` }} />
                  </div>
                </div>
              </>
            )}

            {tab === 'connectors' && (
              <>
                <div className="oc-lbl">แอปส่งข้อความและเครื่องมือนักพัฒนา</div>
                {CONNECTORS_LIST.map(item => {
                  const enabled = settings.connectors[item.key]
                  return (
                    <div key={item.key} className="oc-card oc-row">
                      <span>
                        <b>{item.name}</b>
                        <small>{item.desc}</small>
                      </span>
                      <button
                        type="button"
                        className="oc-tg"
                        role="switch"
                        aria-checked={enabled}
                        aria-label={`สลับสถานะ ${item.name}`}
                        disabled={busy}
                        onClick={() => {
                          void savePatch(
                            {
                              connectors: {
                                ...settings.connectors,
                                [item.key]: !enabled,
                              },
                            },
                            `${!enabled ? 'เปิด' : 'ปิด'}การเชื่อมต่อ ${item.name} แล้ว`,
                          )
                        }}
                      >
                        <motion.span
                          className="oc-tg-knob"
                          animate={{ x: enabled ? 17 : 0 }}
                          transition={IOS_SNAPPY_SPRING}
                          aria-hidden="true"
                        />
                      </button>
                    </div>
                  )
                })}
              </>
            )}

            {tab === 'privacy' && (
              <>
                <div className="oc-lbl">ความเป็นส่วนตัวและการควบคุมข้อมูล</div>
                <div className="oc-card oc-row">
                  <span>
                    <b>ช่วยพัฒนาคุณภาพ BLUEZYCODE</b>
                    <small>ตัวเลือกนี้บันทึกในเบราว์เซอร์ เวอร์ชันนี้ยังไม่ส่งสถิติไปยัง BLUEZYCODE</small>
                  </span>
                  <button
                    type="button"
                    className="oc-tg"
                    role="switch"
                    aria-checked={settings.improveModel}
                    aria-label="ช่วยพัฒนาคุณภาพ BLUEZYCODE"
                    disabled={busy}
                    onClick={() => {
                      void savePatch(
                        { improveModel: !settings.improveModel },
                        'บันทึกตัวเลือกนี้แล้ว',
                      )
                    }}
                  >
                    <motion.span
                      className="oc-tg-knob"
                      animate={{ x: settings.improveModel ? 17 : 0 }}
                      transition={IOS_SNAPPY_SPRING}
                      aria-hidden="true"
                    />
                  </button>
                </div>

                <div className="oc-card oc-row">
                  <span>
                    <b>ส่งออกข้อมูลแชตทั้งหมด</b>
                    <small>ดาวน์โหลดประวัติแชตและไฟล์สรุปเป็น JSON</small>
                  </span>
                  <button
                    type="button"
                    className="oc-sm"
                    disabled={busy}
                    onClick={onExportAll}
                  >
                    <Download size={13} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 5 }} />
                    ส่งออก JSON
                  </button>
                </div>

                <div className="oc-card oc-row">
                  <span>
                    <b>เก็บถาวรแชตทั้งหมด</b>
                    <small>
                      ใช้งานอยู่ {workspace.chats.length} · เก็บถาวร {archivedChats.length} แชต
                    </small>
                  </span>
                  <div className="flex flex-wrap items-center gap-2">
                    {archivedChats.length > 0 && (
                      <button
                        type="button"
                        className="oc-sm"
                        disabled={busy}
                        onClick={() => {
                          void onBulkAction('restore-archived').then(ok => {
                            if (ok) setFeedback('กู้คืนแชตจากคลังเก็บถาวรแล้ว')
                          })
                        }}
                      >
                        กู้คืน ({archivedChats.length})
                      </button>
                    )}
                    <button
                      type="button"
                      className="oc-sm"
                      disabled={busy || workspace.chats.length === 0}
                      onClick={() => {
                        void onBulkAction('archive-all').then(ok => {
                          if (ok) setFeedback('เก็บถาวรแชตทั้งหมดแล้ว')
                        })
                      }}
                    >
                      เก็บถาวรทั้งหมด
                    </button>
                  </div>
                </div>

                <div className="oc-card oc-row oc-danger-card">
                  <span>
                    <b>ลบแชตทั้งหมด</b>
                    <small>ลบประวัติแชตที่ใช้งานและเก็บถาวรจากเบราว์เซอร์นี้</small>
                  </span>
                  {confirmDanger === 'delete-all' ? (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        className="oc-sm danger"
                        disabled={busy}
                        onClick={() => {
                          void onBulkAction('delete-all').then(ok => {
                            if (ok) {
                              setConfirmDanger(null)
                              setFeedback('ลบประวัติแชตทั้งหมดแล้ว')
                            }
                          })
                        }}
                      >
                        ยืนยันลบทั้งหมด
                      </button>
                      <button
                        type="button"
                        className="oc-sm"
                        disabled={busy}
                        onClick={() => setConfirmDanger(null)}
                      >
                        ยกเลิก
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      className="oc-sm danger"
                      disabled={busy || (workspace.chats.length === 0 && archivedChats.length === 0)}
                      onClick={() => setConfirmDanger('delete-all')}
                    >
                      ลบทั้งหมด
                    </button>
                  )}
                </div>
              </>
            )}

            {tab === 'about' && (
              <>
                <div className="oc-card" style={{ marginTop: 20 }}>
                  <div className="oc-row">
                    <b>แพลตฟอร์ม</b>
                    <span className="oc-sp">BLUEZYCODE Full-Stack Workspace</span>
                  </div>
                </div>
                <div className="oc-card">
                  <div className="oc-row">
                    <b>ระบบประมวลผล</b>
                    <span className="oc-sp">
                      {aiModelName ? `${aiModelName} + Local UTF-8` : 'Local UTF-8 Engine'}
                    </span>
                  </div>
                </div>
                <div className="oc-card">
                  <div className="oc-row">
                    <b>คำสั่ง Slash ในหน้าแชต</b>
                    <span className="oc-sp">{commands.length} คำสั่ง</span>
                  </div>
                </div>
                <div className="oc-card oc-row">
                  <b>ข้อกำหนดการใช้งาน</b>
                  <a className="oc-sm" href="/terms" target="_blank" rel="noopener noreferrer" aria-label="อ่านข้อกำหนดการใช้งาน">อ่าน</a>
                </div>
                <div className="oc-card oc-row">
                  <b>นโยบายความเป็นส่วนตัว</b>
                  <a className="oc-sm" href="/privacy" target="_blank" rel="noopener noreferrer" aria-label="อ่านนโยบายความเป็นส่วนตัว">อ่าน</a>
                </div>
              </>
            )}

            {error && (
              <p className="error" role="alert">
                {error}
              </p>
            )}
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="oc-toast-wrap" aria-live="polite">
            <AnimatePresence>
              {feedback && (
                <motion.div
                  key={feedback}
                  className="oc-toast"
                  role="status"
                  initial={{ opacity: 0, y: 10, scale: 0.94 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  transition={IOS_SNAPPY_SPRING}
                >
                  <Check size={14} />
                  <span>{feedback}</span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>
      </motion.div>
    </motion.div>
  )
}
