import { env, pipeline } from '@huggingface/transformers'
import type { TextGenerationPipeline } from '@huggingface/transformers'
import wasmUrl from 'onnxruntime-web/ort-wasm-simd-threaded.wasm?url'
import wasmModuleUrl from 'onnxruntime-web/ort-wasm-simd-threaded.mjs?url'
import type { ModelEvent, ModelMessage } from './localModel'

const modelId = 'onnx-community/Qwen3-0.6B-ONNX-OPT'
const revision = '4799e655597b49210adb5c1ebe5b9d3bd04005a0'

env.allowLocalModels = false
// ONNX Runtime can import the same-origin module directly. The built-in WASM
// cache converts the module to a blob URL, which the site's script policy blocks.
env.useWasmCache = false
if (env.backends.onnx.wasm) {
  env.backends.onnx.wasm.numThreads = 1
  env.backends.onnx.wasm.wasmPaths = { wasm: wasmUrl, mjs: wasmModuleUrl }
}

let generator: TextGenerationPipeline | undefined

self.addEventListener('message', async (event: MessageEvent<ModelMessage[]>) => {
  const port = event.ports[0]
  if (!port) return
  const emit = (kind: ModelEvent['kind'], text: string) => port.postMessage({ kind, text } satisfies ModelEvent)
  let stage: 'download' | 'initialize' | 'generate' = 'download'
  try {
    let lastProgress = -1
    generator ??= await pipeline('text-generation', modelId, {
      revision,
      device: 'wasm',
      dtype: 'q4',
      progress_callback: data => {
        if (data.status === 'progress' && data.file.includes('.onnx_data')) {
          const percent = Math.max(0, Math.min(100, Math.floor(data.progress)))
          if (percent !== lastProgress) {
            lastProgress = percent
            emit('progress', `กำลังดาวน์โหลด Qwen3 · ${percent}%`)
          }
        } else if (data.status === 'done' && data.file.endsWith('.onnx_data')) {
          stage = 'initialize'
          emit('progress', 'กำลังเริ่มตัวประมวลผล Qwen3')
        }
      },
    })
    stage = 'generate'
    const chatTemplateOptions = {
      tokenize: false,
      add_generation_prompt: true,
      enable_thinking: false,
    } as const
    const prompt = generator.tokenizer.apply_chat_template(event.data, chatTemplateOptions)
    if (generator.tokenizer(prompt, { add_special_tokens: false }).input_ids.dims.at(-1)! > 2048) {
      emit('error', 'แชตยาวเกินที่โมเดลบนเครื่องรองรับ ลองย่อข้อความหรือเปิดแชตใหม่')
      return
    }
    emit('progress', 'Qwen3 กำลังตอบบนอุปกรณ์นี้')
    const [output] = await generator(prompt, {
      add_special_tokens: false,
      max_new_tokens: 196,
      do_sample: true,
      temperature: 0.7,
      top_p: 0.8,
      top_k: 20,
      return_full_text: false,
    })
    const text = typeof output.generated_text === 'string'
      ? output.generated_text.replace(/^\s*<think>[\s\S]*?<\/think>/, '').trim()
      : ''
    if (!text) {
      emit('error', 'Qwen3 ตอบกลับเป็นข้อความว่าง ลองส่งคำถามอีกครั้ง')
      return
    }
    emit('answer', text)
  } catch (error) {
    console.error(`Local Qwen3 failed at ${stage}`, error)
    const messages = {
      download: 'ดาวน์โหลดไฟล์ Qwen3 ไม่สำเร็จ ตรวจสอบการเชื่อมต่อแล้วส่งอีกครั้ง',
      initialize: 'เปิดตัวประมวลผล Qwen3 ไม่สำเร็จ ลองปิดแท็บอื่นแล้วส่งอีกครั้ง',
      generate: 'Qwen3 ประมวลผลข้อความไม่สำเร็จ ลองส่งคำถามที่สั้นลง',
    }
    emit('failure', messages[stage])
  } finally {
    port.close()
  }
})
