import type { CSSProperties } from 'react'

type SymbolProps = { size?: number; className?: string; style?: CSSProperties }

function materialSymbol(asset: string) {
  const image = `url("/google-icons/${asset}.svg")`
  function MaterialSymbol({ size = 18, className, style }: SymbolProps) {
    return (
      <span
        aria-hidden="true"
        className={className ? `material-symbol ${className}` : 'material-symbol'}
        style={{ ...style, width: size, height: size, maskImage: image, WebkitMaskImage: image }}
      />
    )
  }
  return MaterialSymbol
}

export const ArrowLeft = materialSymbol('arrow_back')
export const Check = materialSymbol('check')
export const ChevronRight = materialSymbol('chevron_right')
export const Cloud = materialSymbol('cloud')
export const Copy = materialSymbol('content_copy')
export const CreditCard = materialSymbol('credit_card')
export const Database = materialSymbol('database')
export const Download = materialSymbol('download')
export const Eye = materialSymbol('visibility')
export const EyeOff = materialSymbol('visibility_off')
export const FileText = materialSymbol('description')
export const Gauge = materialSymbol('speed')
export const HelpCircle = materialSymbol('help')
export const Home = materialSymbol('home')
export const Info = materialSymbol('info')
export const Keyboard = materialSymbol('keyboard')
export const Layers = materialSymbol('layers')
export const Lightbulb = materialSymbol('lightbulb')
export const LogOut = materialSymbol('logout')
export const Mail = materialSymbol('mail')
export const Menu = materialSymbol('menu')
export const MessageSquare = materialSymbol('chat_bubble')
export const Monitor = materialSymbol('desktop_windows')
export const Moon = materialSymbol('dark_mode')
export const Palette = materialSymbol('palette')
export const Plug = materialSymbol('electrical_services')
export const Plus = materialSymbol('add')
export const RefreshCw = materialSymbol('refresh')
export const Search = materialSymbol('search')
export const Settings = materialSymbol('settings')
export const Sparkles = materialSymbol('auto_awesome')
export const Sun = materialSymbol('light_mode')
export const User = materialSymbol('person')
export const UserRound = materialSymbol('account_circle')
export const Wifi = materialSymbol('wifi')
export const X = materialSymbol('close')

const composerSymbols = {
  check: Check,
  chevron: materialSymbol('expand_more'),
  close: X,
  file: FileText,
  monitor: Monitor,
  plus: Plus,
  send: materialSymbol('arrow_upward'),
  trash: materialSymbol('delete'),
}

export function Icon({ name, size }: { name: keyof typeof composerSymbols; size?: number }) {
  const Symbol = composerSymbols[name]
  return <Symbol size={size} />
}
