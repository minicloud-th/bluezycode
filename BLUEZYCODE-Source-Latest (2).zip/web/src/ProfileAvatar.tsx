import { useState } from 'react'
import { UserRound } from './icons'

export function ProfileAvatar({ name, src, size }: { name: string; src?: string; size: number }) {
  const [failedSource, setFailedSource] = useState<string>()
  const initial = Array.from(name.trim())[0]?.toLocaleUpperCase()

  return (
    <span className="oc-avatar" style={{ width: size, height: size, fontSize: Math.round(size * 0.42) }} aria-hidden="true">
      {src && src !== failedSource
        ? <img src={src} alt="" decoding="async" referrerPolicy="no-referrer" onError={() => setFailedSource(src)} />
        : initial || <UserRound size={Math.round(size * 0.58)} />}
    </span>
  )
}
