import { ApiError, byteLength } from './api'
import type { AuthUser, Model, RequestOptions } from './api'
import { analyzeFilesReply, isValidProfileName, summarizeChat, titleFor, validRequest } from './server/chatLogic'
import { computeDashboardStats, defaultSettings, normalizeSettings, publicWorkspaceId, validateAndMergeSettings } from './server/settingsLogic'
import { archivedSummaries, findChatIndex, MAX_WORKSPACE_BYTES, publicChat, workspaceSummaries } from './server/store'
import type { SendRequest, Workspace } from './server/types'
import { generateReply, LOCAL_MODEL_NAME } from './localModel'

type StoredWorkspace = Workspace & { localId: string; revision: number; previousImported?: boolean }
type Scope = { key: string; account: AuthUser }

const legacyWorkspaceKey = 'guest'
const importedFlagKey = 'previous-workspace-imported'

const models: Model[] = [
  { id: 'workspace', name: 'Workspace' },
  { id: 'ai', name: LOCAL_MODEL_NAME },
]

let databasePromise: Promise<IDBDatabase> | undefined

function database() {
  databasePromise ??= new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open('bluezycode', 1)
    request.onupgradeneeded = () => request.result.createObjectStore('workspaces')
    request.onerror = () => reject(request.error)
    request.onsuccess = () => {
      const db = request.result
      db.onversionchange = () => {
        db.close()
        databasePromise = undefined
      }
      resolve(db)
    }
  }).catch(() => {
    databasePromise = undefined
    throw new ApiError('เปิดพื้นที่จัดเก็บของเบราว์เซอร์ไม่ได้ ตรวจสอบการอนุญาตพื้นที่จัดเก็บ', 500)
  })
  return databasePromise
}

async function load(scope: Scope): Promise<StoredWorkspace> {
  const db = await database()
  return new Promise((resolve, reject) => {
    // Creating the record in this transaction keeps its ID stable across tabs.
    const transaction = db.transaction('workspaces', 'readwrite')
    const store = transaction.objectStore('workspaces')
    const request = store.get(scope.key)
    let ws: StoredWorkspace
    request.onsuccess = () => {
      ws = request.result
      if (!ws) {
        ws = {
          localId: crypto.randomUUID(),
          revision: 0,
          name: isValidProfileName(scope.account.name) ? scope.account.name : '',
          chats: [],
          archivedChats: [],
          settings: normalizeSettings({ email: scope.account.email }),
        }
        store.add(ws, scope.key)
      }
    }
    transaction.oncomplete = () => resolve(ws)
    transaction.onabort = () => reject(new ApiError('อ่านพื้นที่จัดเก็บของเบราว์เซอร์ไม่ได้', 500))
  })
}

async function save(scope: Scope, ws: StoredWorkspace, finishLegacyImport = false) {
  if (byteLength(JSON.stringify(ws)) > MAX_WORKSPACE_BYTES) {
    throw new ApiError('พื้นที่จัดเก็บเต็ม ลบแชตเก่าแล้วลองอีกครั้ง', 507)
  }
  const db = await database()
  return new Promise<void>((resolve, reject) => {
    const transaction = db.transaction('workspaces', 'readwrite')
    const store = transaction.objectStore('workspaces')
    const request = store.get(scope.key)
    let conflict = false
    request.onsuccess = () => {
      const current: StoredWorkspace | undefined = request.result
      if (current?.localId !== ws.localId || current.revision !== ws.revision) {
        conflict = true
        transaction.abort()
        return
      }
      if (finishLegacyImport) {
        // An existing marker aborts the entire transaction if another tab already migrated.
        store.add(true, importedFlagKey)
        store.delete(legacyWorkspaceKey)
      }
      store.put({ ...ws, revision: ws.revision + 1 }, scope.key)
    }
    transaction.oncomplete = () => resolve()
    transaction.onabort = () => reject(conflict
      ? new ApiError('Workspace ถูกแก้ไขในอีกแท็บ กรุณาโหลดข้อมูลใหม่แล้วลองอีกครั้ง', 409)
      : new ApiError('บันทึกข้อมูลในเบราว์เซอร์ไม่สำเร็จ ตรวจสอบพื้นที่จัดเก็บ', 507))
  })
}

async function readLegacyWorkspace(): Promise<{ local: StoredWorkspace | undefined } | null> {
  const db = await database()
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('workspaces')
    const store = transaction.objectStore('workspaces')
    const imported = store.get(importedFlagKey)
    const local = store.get(legacyWorkspaceKey)
    transaction.oncomplete = () => resolve(imported.result ? null : { local: local.result })
    transaction.onabort = () => reject(transaction.error)
  })
}

async function importPreviousWorkspace(scope: Scope, ws: StoredWorkspace): Promise<StoredWorkspace> {
  if (ws.previousImported) return ws
  try {
    const legacy = await readLegacyWorkspace()
    if (!legacy) return ws
    const local = legacy.local
    let older: Workspace | undefined
    if (!local?.previousImported && location.hostname.endsWith('.chatgpt.site')) {
      const response = await fetch('/api/workspace/previous', {
        credentials: 'same-origin',
        signal: AbortSignal.timeout(3000),
      })
      if (!response.ok) return ws
      if (response.status !== 204) {
        if (!response.headers.get('Content-Type')?.startsWith('application/json')) return ws
        older = await response.json()
        if (typeof older?.name !== 'string' || !Array.isArray(older.chats)) return ws
      }
    }

    const active = [...ws.chats]
    const archived = [...(ws.archivedChats ?? [])]
    const known = new Set([...active, ...archived].map(chat => chat.id))
    for (const [source, destination] of [
      [local?.archivedChats ?? [], archived],
      [[...(local?.chats ?? []), ...(older?.chats ?? [])], active],
    ]) {
      for (const chat of source) {
        if (known.has(chat.id)) continue
        destination.push({
          ...chat,
          turns: (chat.turns ?? []).map(turn => ({ ...turn, files: turn.files ?? [] })),
          redo: chat.redo?.map(turn => ({ ...turn, files: turn.files ?? [] })),
        })
        known.add(chat.id)
      }
    }

    const migrated = {
      ...ws,
      name: ws.revision === 0 ? local?.name || older?.name || ws.name : ws.name,
      settings: ws.revision === 0 && local?.settings
        ? normalizeSettings({ ...local.settings, email: scope.account.email || local.settings.email })
        : ws.settings,
      chats: active.sort((a, b) => b.updated.localeCompare(a.updated)),
      archivedChats: archived,
      previousImported: true,
    }
    await save(scope, migrated, true)
    return migrated
  } catch {
    // A failed import leaves the original records available for the next attempt.
    return load(scope)
  }
}

function stats(ws: Workspace) {
  return computeDashboardStats(ws, MAX_WORKSPACE_BYTES)
}

function snapshot(ws: Workspace) {
  return {
    name: ws.name,
    settings: normalizeSettings(ws.settings),
    archivedChats: archivedSummaries(ws),
    stats: stats(ws),
  }
}

function settingsPatch(body: unknown) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new ApiError('รูปแบบข้อมูลการตั้งค่าไม่ถูกต้อง', 400)
  }
  return body as Record<string, unknown>
}

function setName(ws: Workspace, value: unknown) {
  if (typeof value !== 'string' || !isValidProfileName(value.trim())) {
    throw new ApiError('ชื่อโปรไฟล์ต้องยาวไม่เกิน 40 ตัวอักษร', 400)
  }
  ws.name = value.trim()
}

function manageChats(ws: Workspace, action: unknown) {
  const archived = ws.archivedChats ?? []
  switch (action) {
    case 'archive-all': {
      const alreadyArchived = new Set(archived.map(chat => chat.id))
      const toArchive = ws.chats.filter(chat => !alreadyArchived.has(chat.id))
      if (toArchive.length + archived.length > 120) {
        throw new ApiError('พื้นที่เก็บถาวรเต็ม กรุณาจัดการแชตที่เก็บไว้ก่อน', 409)
      }
      ws.archivedChats = [...toArchive, ...archived]
      ws.chats = []
      return
    }
    case 'restore-archived': {
      const activeIds = new Set(ws.chats.map(chat => chat.id))
      const toRestore = archived.filter(chat => !activeIds.has(chat.id)).slice(0, Math.max(0, 40 - ws.chats.length))
      const restoredIds = new Set(toRestore.map(chat => chat.id))
      ws.chats = [...toRestore, ...ws.chats]
      ws.archivedChats = archived.filter(chat => !restoredIds.has(chat.id))
      return
    }
    case 'reset-account':
      ws.name = ''
      ws.settings = defaultSettings()
      // Reset clears local chat data as well.
    case 'delete-all':
      ws.chats = []
      ws.archivedChats = []
      return
    default:
      throw new ApiError('ไม่พบคำสั่งจัดการแชตนี้', 400)
  }
}

async function addTurn(scope: Scope, ws: StoredWorkspace, input: SendRequest, options?: RequestOptions) {
  if (!input || typeof input.prompt !== 'string' || typeof input.chatId !== 'string') {
    throw new ApiError('รูปแบบข้อความไม่ถูกต้อง', 400)
  }
  input = { ...input, prompt: input.prompt.trim() }
  if (!validRequest(input)) {
    throw new ApiError('ใช้ข้อความไม่เกิน 12 KB และแนบไฟล์ข้อความได้สูงสุด 4 ไฟล์ ไฟล์ละ 64 KiB รวม 192 KiB', 400)
  }
  const chosen = models.find(model => model.id === input.model)
  if (!chosen) throw new ApiError('ไม่พบโมเดลนี้', 400)

  const index = findChatIndex(ws, input.chatId)
  if (input.chatId && index < 0) throw new ApiError('ไม่พบแชตนี้', 404)
  if (!input.chatId && ws.chats.length >= 40) {
    throw new ApiError('ถึงขีดจำกัด 40 แชต ลบแชตเก่าก่อนเปิดแชตใหม่', 409)
  }
  const chat = ws.chats[index] ?? { id: crypto.randomUUID(), title: titleFor(input), updated: '', turns: [] }
  if (chat.turns.length >= 40) {
    throw new ApiError('แชตนี้ครบ 40 ข้อความแล้ว เปิดแชตใหม่เพื่อคุยต่อ', 409)
  }

  const reply = input.model === 'ai'
    ? await generateReply(input, chat, options?.onProgress)
    : analyzeFilesReply(input.files)
  chat.turns.push({ prompt: input.prompt, reply, model: chosen.name, files: input.files })
  delete chat.redo
  chat.updated = new Date().toISOString()

  if (index >= 0) ws.chats.splice(index, 1)
  ws.chats.unshift(chat)
  await save(scope, ws)
  return { chat: publicChat(chat), chats: workspaceSummaries(ws), stats: stats(ws) }
}

export async function workspaceRequest(path: string, body: unknown, account: AuthUser | null, options?: RequestOptions) {
  if (!account) throw new ApiError('กรุณาลงชื่อเข้าใช้ก่อนเปิด Workspace', 401)
  const scope = { key: `firebase:${account.id}`, account }
  const ws = await load(scope)
  switch (path) {
    case '/workspace': {
      const current = await importPreviousWorkspace(scope, ws)
      return {
        ...snapshot(current),
        publicId: await publicWorkspaceId(current.localId),
        chats: workspaceSummaries(current),
        models,
        engineAvailable: true,
        user: account,
      }
    }
    case '/settings': {
      if (body === undefined) return { ...snapshot(ws), publicId: await publicWorkspaceId(ws.localId) }
      const patch = settingsPatch(body)
      const result = validateAndMergeSettings(normalizeSettings(ws.settings), patch)
      if (result.ok === false) throw new ApiError(result.error, 400)
      if ('name' in patch) setName(ws, patch.name)
      ws.settings = result.next
      await save(scope, ws)
      return { name: ws.name, settings: ws.settings, stats: stats(ws) }
    }
    case '/workspace/export':
      return { brand: 'BLUEZYCODE', exportedAt: new Date().toISOString(), name: ws.name,
        settings: normalizeSettings(ws.settings), chats: ws.chats, archivedChats: ws.archivedChats ?? [] }
    case '/workspace/chats-action':
      manageChats(ws, settingsPatch(body).action)
      await save(scope, ws)
      return { ...snapshot(ws), chats: workspaceSummaries(ws) }
    case '/profile':
      setName(ws, settingsPatch(body).name)
      await save(scope, ws)
      return { name: ws.name }
    case '/turns':
      return addTurn(scope, ws, body as SendRequest, options)
  }

  const match = /^\/chats\/([^/]+)(?:\/([^/]+))?$/.exec(path)
  if (!match) throw new ApiError('ไม่พบคำสั่งนี้', 404)
  const [, id, action] = match
  const index = findChatIndex(ws, id)
  if (index < 0) throw new ApiError('ไม่พบแชตนี้', 404)
  const chat = ws.chats[index]
  if (!action) return publicChat(chat)
  if (action === 'summary') return { summary: summarizeChat(chat) }
  if (action === 'undo') {
    const last = chat.turns.pop()
    if (last) (chat.redo ??= []).push(last)
  } else if (action === 'redo') {
    const restored = chat.redo?.pop()
    if (restored) chat.turns.push(restored)
  } else if (action !== 'delete') {
    throw new ApiError('ไม่พบคำสั่งนี้', 404)
  }
  ws.chats.splice(index, 1)
  if (action !== 'delete') {
    chat.updated = new Date().toISOString()
    ws.chats.unshift(chat)
  }
  await save(scope, ws)
  return { chat: action === 'delete' ? null : publicChat(chat), chats: workspaceSummaries(ws), stats: stats(ws) }
}
