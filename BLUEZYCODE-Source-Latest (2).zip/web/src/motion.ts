export const IOS_SPRING = {
  type: 'spring' as const,
  stiffness: 460,
  damping: 36,
  mass: 0.85,
}

export const IOS_SNAPPY_SPRING = {
  type: 'spring' as const,
  stiffness: 560,
  damping: 38,
  mass: 0.72,
}

export const IOS_SOFT_SPRING = {
  type: 'spring' as const,
  stiffness: 360,
  damping: 32,
  mass: 0.92,
}

export const IOS_SHEET_SPRING = {
  type: 'spring' as const,
  stiffness: 420,
  damping: 36,
  mass: 0.88,
}

export const IOS_EASE = [0.32, 0.72, 0, 1] as const
