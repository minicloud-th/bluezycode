import { useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { AnimatePresence, MotionConfig, motion } from 'motion/react'
import Markdown from 'react-markdown'
import { onAuthStateChanged, signOut } from 'firebase/auth'
import {
  ChevronRight,
  Download,
  HelpCircle,
  Icon,
  Layers,
  Menu,
  X,
} from './icons'
import { ApiError, api, byteLength, errorMessage, setWorkspaceAccount } from './api'
import type {
  AccentColor,
  Attachment,
  AuthUser,
  Chat,
  ChatChange,
  ChatSummary,
  ChatsActionResult,
  SettingsSaveResult,
  SettingsSnapshot,
  SettingsTab,
  Workspace,
  WorkspaceSettings,
} from './api'
import { AccountMenu } from './AccountMenu'
import { Composer, commands } from './Composer'
import type { Command } from './Composer'
import { accountFromFirebase, firebaseAuth } from './firebase'
import { LoginScreen } from './LoginScreen'
import { IOS_EASE, IOS_SHEET_SPRING, IOS_SNAPPY_SPRING, IOS_SOFT_SPRING, IOS_SPRING } from './motion'
import { Rail } from './Rail'
import type { RailSection } from './Rail'
import { RailPages } from './RailPages'
import { PLAN_LABELS, SETTINGS_TABS, SettingsModal } from './SettingsModal'

type Panel = 'cloud' | 'help' | 'summary' | 'delete' | 'chats' | 'shortcuts'

const SETTINGS_TAB_SET = new Set<string>(SETTINGS_TABS.map(item => item.id))

function tabFromHash(hash: string): SettingsTab | null {
  if (!hash.startsWith('#set:')) return null
  const candidate = hash.slice(5)
  return SETTINGS_TAB_SET.has(candidate) ? (candidate as SettingsTab) : 'general'
}

function contrastOnAccent(color: AccentColor): string {
  if (color === '#2f6df0' || color === '#a855f7' || color === '#ec4899') {
    return '#ffffff'
  }
  return '#0b1b3b'
}

function Logo() {
  const [playing, setPlaying] = useState(false)
  useEffect(() => {
    let mounted = true
    const sprite = new Image()
    sprite.src = '/bluezy-wordmark.png'
    void sprite.decode().then(() => { if (mounted) setPlaying(true) }, () => {})
    return () => { mounted = false }
  }, [])
  return <h1 className="wordmark" aria-label="BLUEZYCODE">
    <span className={'wm-box' + (playing ? ' playing' : '')} aria-hidden="true">
      <span className="wm-anim" /><span className="wm-shine" />
      <span className="wm-star star-one" /><span className="wm-star star-two" />
      <span className="wm-star star-three" /><span className="wm-star star-four" />
      <span className="wm-star star-five" />
    </span>
  </h1>
}

function Modal({ title, busy, onClose, children }: {
  title: string; busy: boolean; onClose(): void; children: ReactNode
}) {
  useEffect(() => {
    function handleKey(event: KeyboardEvent) {
      if (event.key === 'Escape' && !busy) {
        event.preventDefault()
        onClose()
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [busy, onClose])

  return <motion.div
    className="oc-overlay"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: 0.18, ease: IOS_EASE }}
    onMouseDown={event => {
      if (event.target === event.currentTarget && !busy) onClose()
    }}
  >
    <motion.div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="oc-modal oc-small oc-sheet"
      initial={{ opacity: 0, scale: 0.96, y: 10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.965, y: 8 }}
      transition={IOS_SHEET_SPRING}
    >
      <header className="oc-sheet-head">
        <h3 id="modal-title">{title}</h3>
        <motion.button
          type="button"
          className="oc-x"
          aria-label="ปิด"
          disabled={busy}
          whileTap={busy ? undefined : { scale: 0.88 }}
          transition={IOS_SNAPPY_SPRING}
          onClick={onClose}
        >
          <X size={16} />
        </motion.button>
      </header>
      <div className="oc-sheet-body">
        {children}
      </div>
    </motion.div>
  </motion.div>
}

function exportChat(chat: Chat) {
  const text = '# ' + chat.title + '\n\n' + chat.turns.map(turn => {
    const files = turn.files.length ? '\n\nไฟล์แนบ ' + turn.files.map(file => file.name).join(', ') : ''
    return '## คุณ\n\n' + turn.prompt + files + '\n\n## ' + turn.model + '\n\n' + turn.reply
  }).join('\n\n---\n\n')
  const link = document.createElement('a')
  const objectURL = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }))
  link.href = objectURL
  link.download = 'bluezycode-' + chat.id.slice(0, 8) + '.md'
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(objectURL), 1000)
}

function formatDate(date: string, language = 'th', timeZone?: string) {
  const locale = language === 'en' ? 'en-US' : language === 'ja' ? 'ja-JP' : 'th-TH'
  try {
    return new Intl.DateTimeFormat(locale, {
      day: 'numeric',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
      timeZone,
    }).format(new Date(date))
  } catch {
    return new Intl.DateTimeFormat(locale, {
      day: 'numeric',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
    }).format(new Date(date))
  }
}

export function App() {
  const [authChecking, setAuthChecking] = useState(true)
  const [authUser, setAuthUser] = useState<AuthUser | null>(null)
  const [workspace, setWorkspace] = useState<Workspace | null>(null)
  const [chat, setChat] = useState<Chat | null>(null)
  const [section, setSection] = useState<RailSection>('home')
  const [draft, setDraft] = useState('')
  const [files, setFiles] = useState<Attachment[]>([])
  const [model, setModel] = useState('ai')
  const [modelProgress, setModelProgress] = useState('')
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const [initializing, setInitializing] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const [panel, setPanel] = useState<Panel | null>(null)
  const [settingsTab, setSettingsTab] = useState<SettingsTab | null>(() =>
    typeof window !== 'undefined' ? tabFromHash(window.location.hash) : null,
  )
  const [summary, setSummary] = useState('')
  const [showAppearance, setShowAppearance] = useState(false)
  const log = useRef<HTMLElement>(null)
  const busyRef = useRef(false)
  const activeAccount = useRef<AuthUser | null>(null)
  const prevChatIdRef = useRef<string | null>(null)

  function openSettings(tab: SettingsTab, appearance = false) {
    setMenuOpen(false)
    setPanel(null)
    setError('')
    setNotice('')
    setSettingsTab(tab)
    setShowAppearance(appearance)
    if (typeof window !== 'undefined') {
      window.location.hash = `set:${tab}`
    }
  }

  function closeSettings() {
    setError('')
    setSettingsTab(null)
    setShowAppearance(false)
    if (typeof window !== 'undefined' && window.location.hash.startsWith('#set:')) {
      window.location.hash = 'home'
    }
  }

  function clearSessionState() {
    activeAccount.current = null
    setWorkspaceAccount(null)
    setAuthUser(null)
    setWorkspace(null)
    setInitializing(false)
    setChat(null)
    setDraft('')
    setFiles([])
    setSection('home')
    setMenuOpen(false)
    setPanel(null)
    closeSettings()
    setError('')
    setNotice('')
  }

  async function loadWorkspaceData(account: AuthUser) {
    setInitializing(true)
    setError('')
    try {
      const ws = await api<Workspace>('/workspace')
      if (activeAccount.current === account) setWorkspace(ws)
    } catch (failure) {
      if (activeAccount.current !== account) return
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      if (activeAccount.current === account) setInitializing(false)
    }
  }

  async function boot() {
    setAuthChecking(true)
    try {
      await firebaseAuth?.authStateReady()
      const user = firebaseAuth?.currentUser
      if (user) {
        await handleAuthenticated(accountFromFirebase(user))
      } else {
        clearSessionState()
      }
    } catch {
      clearSessionState()
    } finally {
      setAuthChecking(false)
    }
  }

  async function handleAuthenticated(account: AuthUser) {
    if (!firebaseAuth || firebaseAuth.currentUser?.uid !== account.id) return
    if (activeAccount.current && activeAccount.current.id !== account.id) clearSessionState()
    activeAccount.current = account
    setWorkspaceAccount(account)
    setAuthUser(account)
    await loadWorkspaceData(account)
  }

  async function signOutAccount() {
    if (busyRef.current || !firebaseAuth) return
    busyRef.current = true
    setBusy(true)
    try {
      await signOut(firebaseAuth)
      clearSessionState()
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  useEffect(() => {
    void boot()
    if (!firebaseAuth) return
    return onAuthStateChanged(firebaseAuth, user => {
      const current = activeAccount.current
      if (current && user?.uid !== current.id) {
        if (user) void handleAuthenticated(accountFromFirebase(user))
        else clearSessionState()
      }
    })
  }, [])

  useEffect(() => {
    function handleHash() {
      setSettingsTab(tabFromHash(window.location.hash))
    }
    window.addEventListener('hashchange', handleHash)
    return () => window.removeEventListener('hashchange', handleHash)
  }, [])

  useEffect(() => {
    const mode = workspace?.settings?.theme ?? 'dark'
    const accent = workspace?.settings?.accentColor ?? '#4a8dff'
    const media = typeof window !== 'undefined' ? window.matchMedia('(prefers-color-scheme: light)') : null

    const applyTheme = () => {
      const effectiveDark = mode === 'dark' || (mode === 'system' && !(media?.matches ?? false))
      const root = document.documentElement
      root.classList.toggle('dark', effectiveDark)
      root.dataset.theme = effectiveDark ? 'dark' : 'light'
      root.style.setProperty('--accent', accent)
      root.style.setProperty('--on', contrastOnAccent(accent))
      const metaTheme = document.querySelector('meta[name="theme-color"]')
      if (metaTheme) {
        metaTheme.setAttribute('content', effectiveDark ? '#131314' : '#ffffff')
      }
    }

    applyTheme()
    if (mode === 'system' && media) {
      media.addEventListener('change', applyTheme)
      return () => media.removeEventListener('change', applyTheme)
    }
  }, [workspace?.settings?.theme, workspace?.settings?.accentColor])

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if ((event.ctrlKey || event.metaKey) && event.key === '/') {
        event.preventDefault()
        setMenuOpen(false)
        setSettingsTab(null)
        setPanel('shortcuts')
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  useEffect(() => {
    const id = chat?.id ?? null
    const isNewChatSwitch = id !== prevChatIdRef.current
    prevChatIdRef.current = id

    if (log.current && id) {
      requestAnimationFrame(() => {
        if (!log.current) return
        log.current.scrollTo({
          top: log.current.scrollHeight,
          behavior: isNewChatSwitch ? 'auto' : 'smooth',
        })
      })
    }
  }, [chat?.id, chat?.turns.length, busy, chat?.canRedo])

  async function run(task: () => Promise<void>, restoreFocus = false) {
    if (busyRef.current || !workspace) return
    busyRef.current = true
    setBusy(true)
    setError('')
    setNotice('')
    try {
      await task()
    } catch (failure) {
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      busyRef.current = false
      setBusy(false)
      if (restoreFocus) requestAnimationFrame(() => document.getElementById('prompt')?.focus())
    }
  }

  function change({ chat: nextChat, chats, stats }: ChatChange) {
    setWorkspace(current => current && { ...current, chats, ...(stats ? { stats } : {}) })
    setChat(nextChat)
  }

  async function saveSettingsPatch(
    patch: Partial<WorkspaceSettings> & { name?: string },
  ): Promise<boolean> {
    if (busyRef.current || !workspace || !authUser || activeAccount.current !== authUser) return false
    busyRef.current = true
    setBusy(true)
    setError('')
    try {
      const result = await api<SettingsSaveResult>('/settings', patch)
      if (activeAccount.current !== authUser) return false
      setWorkspace(current =>
        current && {
          ...current,
          name: result.name,
          settings: result.settings,
          stats: result.stats,
        },
      )
      return true
    } catch (failure) {
      if (activeAccount.current !== authUser) return false
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
      return false
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  async function refreshSettingsState(): Promise<void> {
    if (busyRef.current || !workspace) return
    busyRef.current = true
    setBusy(true)
    setError('')
    try {
      const snapshot = await api<SettingsSnapshot>('/settings')
      setWorkspace(current =>
        current && {
          ...current,
          publicId: snapshot.publicId,
          name: snapshot.name,
          archivedChats: snapshot.archivedChats,
          settings: snapshot.settings,
          stats: snapshot.stats,
        },
      )
    } catch (failure) {
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  async function runChatsBulkAction(
    bulkAction: 'archive-all' | 'restore-archived' | 'delete-all' | 'reset-account',
  ): Promise<boolean> {
    if (busyRef.current || !workspace) return false
    busyRef.current = true
    setBusy(true)
    setError('')
    try {
      const result = await api<ChatsActionResult>('/workspace/chats-action', { action: bulkAction })
      setWorkspace(current =>
        current && {
          ...current,
          name: result.name,
          chats: result.chats,
          archivedChats: result.archivedChats,
          settings: result.settings,
          stats: result.stats,
        },
      )
      if (bulkAction === 'archive-all' || bulkAction === 'delete-all' || bulkAction === 'reset-account') {
        setChat(null)
      }
      return true
    } catch (failure) {
      if (failure instanceof ApiError && failure.status === 401) {
        clearSessionState()
      } else {
        setError(errorMessage(failure))
      }
      return false
    } finally {
      busyRef.current = false
      setBusy(false)
    }
  }

  function exportAllWorkspaceChats() {
    if (busyRef.current) return
    void run(async () => {
      const payload = await api<unknown>('/workspace/export')
      const link = document.createElement('a')
      const objectURL = URL.createObjectURL(
        new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' }),
      )
      link.href = objectURL
      link.download = 'bluezycode-workspace-export.json'
      document.body.appendChild(link)
      link.click()
      link.remove()
      setTimeout(() => URL.revokeObjectURL(objectURL), 1000)
      setNotice('ดาวน์โหลดไฟล์สำรอง Workspace แล้ว')
    })
  }

  function newChat() {
    if (busyRef.current) return
    setMenuOpen(false)
    setPanel(null)
    closeSettings()
    setSection('home')
    setChat(null)
    setDraft('')
    setFiles([])
    setError('')
    setNotice('')
    requestAnimationFrame(() => document.getElementById('prompt')?.focus())
  }

  function openChat(item: ChatSummary) {
    void run(async () => {
      setChat(await api<Chat>('/chats/' + item.id))
      setSection('home')
      setPanel(null)
      setMenuOpen(false)
    })
  }

  function send(overridePrompt?: string) {
    const promptText = overridePrompt ?? draft
    if (byteLength(promptText.trim()) > 12000) {
      setError('ข้อความยาวเกิน 12 KB ลองย่อให้สั้นลง')
      return
    }
    void run(async () => {
      const targetChatId = overridePrompt ? '' : (chat?.id ?? '')
      try {
        change(await api<ChatChange>('/turns', {
          chatId: targetChatId,
          prompt: promptText,
          model,
          files: overridePrompt ? [] : files,
        }, { onProgress: setModelProgress }))
      } finally {
        setModelProgress('')
      }
      setSection('home')
      setDraft('')
      if (!overridePrompt) setFiles([])
    }, true)
  }

  function action(name: 'undo' | 'redo' | 'delete') {
    if (!chat) return
    void run(async () => {
      change(await api<ChatChange>('/chats/' + chat.id + '/' + name, {}))
      if (name === 'delete') {
        setPanel(null)
        setNotice('ลบแชตแล้ว')
      }
    })
  }

  function command(name: Command) {
    setDraft('')
    setError('')
    setNotice('')
    if (name === '/new') {
      newChat()
      return
    }
    if (name === '/help') {
      setMenuOpen(false)
      setPanel('help')
      return
    }
    if (!chat) {
      setNotice('ส่งข้อความเพื่อเริ่มแชตก่อน')
      return
    }
    switch (name) {
      case '/undo':
        if (chat.turns.length) action('undo')
        else setNotice('ไม่มีข้อความให้ย้อน')
        break
      case '/redo':
        if (chat.canRedo) action('redo')
        else setNotice('ไม่มีข้อความให้คืน')
        break
      case '/share':
        if (chat.turns.length) {
          exportChat(chat)
          setNotice('ดาวน์โหลดไฟล์แชตแล้ว')
        } else setNotice('ไม่มีข้อความให้ดาวน์โหลด')
        break
      case '/compact':
        void run(async () => {
          const result = await api<{ summary: string }>('/chats/' + chat.id + '/summary', {})
          setSummary(result.summary)
          setMenuOpen(false)
          setPanel('summary')
        })
        break
    }
  }

  const titles: Record<Panel, string> = {
    cloud: 'การเชื่อมต่อ',
    help: 'คำสั่ง',
    summary: 'สรุปแชต',
    delete: 'ลบแชตนี้?',
    chats: 'แชตทั้งหมด',
    shortcuts: 'คีย์ลัดแป้นพิมพ์',
  }
  const aiModelName = workspace?.models.find(item => item.id === 'ai')?.name
  const currentPlanLabel = PLAN_LABELS[workspace?.settings?.plan ?? 'free']

  return (
    <MotionConfig reducedMotion="user">
      <AnimatePresence mode="wait" initial={false}>
        {authChecking ? (
          <motion.div
            key="auth-checking"
            className="oc-login-shell"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16, ease: IOS_EASE }}
          >
            <div className="oc-login-center">
              <div className="flex flex-col items-center gap-3 text-sm text-[var(--muted)]" role="status">
                <span className="bluezy-mark bluezy-mark-loading" aria-hidden="true" />
                <span>กำลังเปิด BLUEZYCODE...</span>
              </div>
            </div>
          </motion.div>
        ) : !authUser ? (
          <LoginScreen
            key="login-screen"
            onAuthenticated={result => void handleAuthenticated(result)}
          />
        ) : (
      <motion.div
        key="workspace-shell"
        className="app-shell"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2, ease: IOS_EASE }}
      >
        <Rail
          section={section}
          chatCount={workspace?.chats.length ?? 0}
          busy={busy}
          ready={Boolean(workspace)}
          onSelectSection={next => {
            setMenuOpen(false)
            setSection(next)
          }}
          accountMenu={
            <AccountMenu
              name={workspace?.name || authUser.name}
              photoURL={workspace?.settings.avatar || authUser.photoURL}
              plan={currentPlanLabel}
              disabled={!workspace || busy}
              open={menuOpen}
              onOpenChange={setMenuOpen}
              onSettings={openSettings}
              onHelp={() => setPanel('help')}
              onShortcuts={() => setPanel('shortcuts')}
              onStatus={() => setPanel('cloud')}
              onExport={exportAllWorkspaceChats}
              onAccount={() => void signOutAccount()}
            />
          }
        />

        <main className={'stage' + (section === 'home' && chat ? ' conversation' : '')}>
          {section !== 'home' ? (
            <>
              <div className="oc-top">
                <motion.button
                  type="button"
                  className="oc-pill"
                  whileTap={{ scale: 0.95 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => setPanel('chats')}
                >
                  <Menu size={16} />
                  <span>แชตทั้งหมด</span>
                </motion.button>
                <motion.button
                  type="button"
                  className="oc-pill"
                  disabled={!workspace}
                  whileTap={workspace ? { scale: 0.95 } : undefined}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => openSettings('plan')}
                >
                  <Layers size={15} />
                  <span>{currentPlanLabel}</span>
                </motion.button>
              </div>
              {workspace ? (
                <RailPages
                  section={section}
                  workspace={workspace}
                  activeChatId={chat?.id ?? null}
                  busy={busy}
                  onNewChat={newChat}
                  onOpenChat={openChat}
                  onStartPrompt={promptText => send(promptText)}
                  onRefresh={refreshSettingsState}
                  onOpenSettings={openSettings}
                  onOpenHelpModal={() => setPanel('help')}
                />
              ) : (
                <div className="grid h-full w-full place-items-center text-sm text-[var(--muted)]" role="status">
                  {error || 'กำลังโหลดข้อมูล BLUEZYCODE...'}
                </div>
              )}
            </>
          ) : !chat ? (
            <>
              <div className="oc-top">
                <motion.button
                  type="button"
                  className="oc-pill"
                  whileTap={{ scale: 0.95 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => setPanel('chats')}
                >
                  <Menu size={16} />
                  <span>แชตทั้งหมด</span>
                </motion.button>
                <motion.button
                  type="button"
                  className="oc-pill"
                  disabled={!workspace}
                  whileTap={workspace ? { scale: 0.95 } : undefined}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => openSettings('plan')}
                >
                  <Layers size={15} />
                  <span>{currentPlanLabel}</span>
                </motion.button>
              </div>
              <div className="home-canvas">
                <motion.div
                  key="welcome"
                  className="welcome"
                  initial={{ opacity: 0, y: 10, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={IOS_SOFT_SPRING}
                >
                  <Logo />
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={IOS_SPRING}
                  className="compose-area"
                >
                  <Composer busy={busy} ready={workspace !== null} draft={draft} files={files} model={model}
                    models={workspace?.models ?? []} onDraft={setDraft} onFiles={setFiles} onModel={setModel}
                    onSend={() => send()} onCommand={command} onError={setError} />
                  <div className="context">
                    <span className="context-brand"><span className="bluezy-mark bluezy-mark-context" aria-hidden="true" /> BLUEZYCODE</span>
                    <span aria-hidden="true">/</span>
                    <span><Icon name="monitor" size={15} />{model === 'workspace' ? 'Workspace' : 'AI บนเครื่อง'}</span>
                    <AnimatePresence initial={false}>
                      {(initializing || busy || notice) && <motion.span
                        key={initializing ? 'init' : busy ? 'busy' : notice}
                        className="operation-status"
                        role="status"
                        initial={{ opacity: 0, y: 3 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -3 }}
                        transition={{ duration: 0.14, ease: IOS_EASE }}
                      >
                        {initializing ? 'กำลังเปิด Workspace' : busy ? modelProgress || 'กำลังดำเนินการ' : notice}
                      </motion.span>}
                    </AnimatePresence>
                  </div>
                  <AnimatePresence>
                    {error && !panel && !settingsTab && <motion.div
                      className="error"
                      role="alert"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -4 }}
                      transition={IOS_SNAPPY_SPRING}
                    >
                      {error}
                      {!workspace && <button className="text-button" onClick={() => void boot()}>ลองเชื่อมต่อใหม่</button>}
                    </motion.div>}
                  </AnimatePresence>
                </motion.div>
              </div>
            </>
          ) : (
            <>
              <motion.header
                key={'header-' + chat.id}
                className="chat-header"
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={IOS_SPRING}
              >
                <div className="flex min-w-0 items-center gap-3">
                  <motion.button
                    type="button"
                    className="oc-pill shrink-0"
                    whileTap={{ scale: 0.95 }}
                    transition={IOS_SNAPPY_SPRING}
                    onClick={() => setPanel('chats')}
                  >
                    <Menu size={16} />
                    <span>แชต</span>
                  </motion.button>
                  <div className="min-w-0">
                    <span>BLUEZYCODE</span>
                    <h1 title={chat.title}>{chat.title}</h1>
                  </div>
                </div>
                <motion.button
                  className="icon-button"
                  aria-label="ลบแชต"
                  title="ลบแชต"
                  disabled={busy}
                  whileTap={busy ? undefined : { scale: 0.88 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => { setError(''); setPanel('delete') }}
                >
                  <Icon name="trash" />
                </motion.button>
              </motion.header>
              <section className="chat-scroll" aria-label="บทสนทนา" ref={log}>
                <div className="chat-log" role="log">
                  <AnimatePresence key={'log-' + chat.id} initial={false}>
                    {chat.turns.map((turn, index) => <motion.article
                      className="turn"
                      key={chat.id + '-' + index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={IOS_SOFT_SPRING}
                    >
                      <motion.div
                        className="message-user"
                        initial={{ opacity: 0, scale: 0.96, y: 6 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        transition={IOS_SNAPPY_SPRING}
                        style={{ transformOrigin: 'bottom right' }}
                      >
                        {turn.prompt && <div>{turn.prompt}</div>}
                        {turn.files.length > 0 && <ul className="message-files">
                          {turn.files.map((file, number) => <li key={number}><Icon name="file" size={13} />{file.name}</li>)}
                        </ul>}
                      </motion.div>
                      <motion.div
                        className="message-assistant"
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ ...IOS_SOFT_SPRING, delay: 0.03 }}
                      >
                        <div className="message-by"><span className="bluezy-mark bluezy-mark-reply" aria-hidden="true" />{turn.model}</div>
                        {turn.model === 'Workspace'
                          ? <div className="plain-reply">{turn.reply}</div>
                          : <Markdown skipHtml disallowedElements={['img', 'a']} unwrapDisallowed>{turn.reply}</Markdown>}
                      </motion.div>
                    </motion.article>)}
                  </AnimatePresence>
                  {!chat.turns.length && <p className="empty-chat">ใช้ /redo เพื่อคืนข้อความ หรือส่งข้อความใหม่เพื่อคุยต่อ</p>}
                </div>
              </section>

              <div className="compose-area">
                <Composer busy={busy} ready={workspace !== null} draft={draft} files={files} model={model}
                  models={workspace?.models ?? []} onDraft={setDraft} onFiles={setFiles} onModel={setModel}
                  onSend={() => send()} onCommand={command} onError={setError} />
                <div className="context">
                  <span className="context-brand"><span className="bluezy-mark bluezy-mark-context" aria-hidden="true" /> BLUEZYCODE</span>
                  <span aria-hidden="true">/</span>
                  <span><Icon name="monitor" size={15} />{model === 'workspace' ? 'Workspace' : 'AI บนเครื่อง'}</span>
                  <AnimatePresence initial={false}>
                    {(initializing || busy || notice) && <motion.span
                      key={initializing ? 'init' : busy ? 'busy' : notice}
                      className="operation-status"
                      role="status"
                      initial={{ opacity: 0, y: 3 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -3 }}
                      transition={{ duration: 0.14, ease: IOS_EASE }}
                    >
                      {initializing ? 'กำลังเปิด Workspace' : busy ? modelProgress || 'กำลังดำเนินการ' : notice}
                    </motion.span>}
                  </AnimatePresence>
                </div>
                <AnimatePresence>
                  {error && !panel && !settingsTab && <motion.div
                    className="error"
                    role="alert"
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={IOS_SNAPPY_SPRING}
                  >
                    {error}
                    {!workspace && <button className="text-button" onClick={() => void boot()}>ลองเชื่อมต่อใหม่</button>}
                  </motion.div>}
                </AnimatePresence>
              </div>
            </>
          )}
        </main>

        <AnimatePresence>
          {settingsTab && workspace && (
            <SettingsModal
              tab={settingsTab}
              showAppearance={showAppearance}
              workspace={workspace}
              authUser={authUser}
              busy={busy}
              error={error}
              onSelectTab={openSettings}
              onSaveSettings={saveSettingsPatch}
              onRefresh={refreshSettingsState}
              onBulkAction={runChatsBulkAction}
              onExportAll={exportAllWorkspaceChats}
              onOpenShortcuts={() => {
                closeSettings()
                setPanel('shortcuts')
              }}
              onLogout={() => void signOutAccount()}
              onClose={closeSettings}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {panel && (
            <Modal key={panel} title={titles[panel]} busy={busy} onClose={() => { setError(''); setPanel(null) }}>
              {panel === 'chats' && (
                <div>
                  <button
                    type="button"
                    className="oc-primary"
                    disabled={busy}
                    onClick={newChat}
                  >
                    แชตใหม่
                  </button>
                  {(workspace?.chats ?? []).length === 0 ? (
                    <p className="oc-none" style={{ textAlign: 'center' }}>ยังไม่มีแชตที่บันทึกไว้</p>
                  ) : (
                    (workspace?.chats ?? []).map(item => (
                      <button
                        key={item.id}
                        type="button"
                        className="oc-card oc-row"
                        disabled={busy}
                        onClick={() => openChat(item)}
                      >
                        <span>
                          <b>{item.title}</b>
                          <small>
                            {formatDate(item.updated, workspace?.settings?.language, workspace?.settings?.timezone)}
                          </small>
                        </span>
                        <ChevronRight size={16} className="oc-go" />
                      </button>
                    ))
                  )}
                </div>
              )}

              {panel === 'shortcuts' && (
                <div>
                  <div className="oc-card oc-row"><b>เปิดหน้าต่างคีย์ลัด</b><span className="oc-sp">Ctrl+/</span></div>
                  <div className="oc-card oc-row"><b>ส่งข้อความในแชต</b><span className="oc-sp">Enter</span></div>
                  <div className="oc-card oc-row"><b>ขึ้นบรรทัดใหม่</b><span className="oc-sp">Shift+Enter</span></div>
                  <div className="oc-card oc-row"><b>ปิดหน้าต่างที่เปิดอยู่</b><span className="oc-sp">Esc</span></div>
                </div>
              )}

              {panel === 'cloud' && (
                <div>
                  <div className="oc-card oc-row"><b>พื้นที่จัดเก็บในเบราว์เซอร์</b><span className="oc-sp">{workspace ? 'พร้อมใช้งาน' : 'ยังไม่พร้อม'}</span></div>
                  <div className="oc-card oc-row"><b>เอนจิน Local UTF-8</b><span className="oc-sp">{workspace?.engineAvailable ? 'พร้อมวิเคราะห์ไฟล์' : 'ยังไม่พร้อม'}</span></div>
                  <div className="oc-card oc-row"><b>โมเดลบนเครื่อง</b><span className="oc-sp">{aiModelName ?? 'Local Workspace'}</span></div>
                </div>
              )}

              {panel === 'help' && (
                <div>
                  {commands.map(item => (
                    <div key={item.name} className="oc-card oc-row">
                      <span>
                        <b style={{ fontFamily: 'ui-monospace, monospace', color: 'var(--accent)' }}>{item.name}</b>
                        <small>{item.description}</small>
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {panel === 'summary' && <p className="plain-reply">{summary}</p>}

              {panel === 'delete' && (
                <div className="delete-form">
                  <p>ข้อความและไฟล์ของแชตนี้จะถูกลบจากประวัติ</p>
                  <button className="oc-primary" style={{ background: '#dc2626', color: '#fff' }} onClick={() => action('delete')} disabled={busy}>
                    ลบแชต
                  </button>
                </div>
              )}

              {error && <p role="alert" className="error">{error}</p>}
            </Modal>
          )}
        </AnimatePresence>
      </motion.div>
        )}
      </AnimatePresence>
    </MotionConfig>
  )
}
