import { getApp, getApps, initializeApp } from 'firebase/app'
import type { FirebaseApp } from 'firebase/app'
import { GoogleAuthProvider, getAuth } from 'firebase/auth'
import type { Auth, User } from 'firebase/auth'
import type { AuthUser } from './api'

// Public Firebase web app identifiers from the existing BLUEZYCODE project.
const firebaseConfig = {
  apiKey: 'AIzaSyBZSNckpfxPY-EuNPa7J066EMi1PY2n6lw',
  authDomain: 'bluezycode.firebaseapp.com',
  projectId: 'bluezycode',
  storageBucket: 'bluezycode.firebasestorage.app',
  messagingSenderId: '717646145369',
  appId: '1:717646145369:web:5a6c561eab8f6d90778e48',
}

let app: FirebaseApp | null = null
let authInstance: Auth | null = null

try {
  app = getApps().length ? getApp() : initializeApp(firebaseConfig)
  authInstance = getAuth(app)
  authInstance.useDeviceLanguage()
} catch {
  // Leave the sign-in screen available to explain Firebase initialization errors.
}

export const firebaseAuth = authInstance

function googlePhotoURL(photoURL: string | null | undefined): string | undefined {
  if (!photoURL) return
  try {
    const url = new URL(photoURL)
    if (url.protocol === 'https:' && /^lh[3-6]\.googleusercontent\.com$/.test(url.hostname) &&
      !url.port && !url.username && !url.password) return url.href
  } catch {
    return undefined
  }
}

export function accountFromFirebase(user: User, provider?: AuthUser['provider']): AuthUser {
  const googleProfile = user.providerData.find(item => item.providerId === 'google.com')
  const photoURL = googlePhotoURL(googleProfile?.photoURL ?? (googleProfile || provider === 'google' ? user.photoURL : undefined))
  return {
    id: user.uid,
    email: user.email ?? '',
    name: user.displayName ?? '',
    provider: provider ?? (user.providerData[0]?.providerId === 'google.com' ? 'google' : 'email'),
    photoURL,
  }
}
export const googleProvider = new GoogleAuthProvider()
googleProvider.setCustomParameters({ prompt: 'select_account' })

export function firebaseErrorMessage(error: unknown): string {
  const code =
    typeof error === 'object' && error !== null && 'code' in error
      ? String((error as { code?: unknown }).code)
      : ''

  switch (code) {
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return 'ปิดหน้าต่างเข้าสู่ระบบ Google ก่อนดำเนินการเสร็จสิ้น'
    case 'auth/popup-blocked':
      return 'เบราว์เซอร์บล็อกหน้าต่างป๊อปอัป กรุณาอนุญาตป๊อปอัปแล้วลองอีกครั้ง'
    case 'auth/unauthorized-domain':
      return `โดเมน ${typeof window !== 'undefined' ? window.location.hostname : ''} ยังไม่ได้รับอนุญาตใน Firebase Authentication → Settings → Authorized domains`
    case 'auth/operation-not-allowed':
      return 'ผู้ให้บริการนี้ยังไม่ถูกเปิดใช้งานใน Firebase Console → Authentication → Sign-in method'
    case 'auth/invalid-email':
      return 'รูปแบบอีเมลไม่ถูกต้อง'
    case 'auth/invalid-credential':
    case 'auth/user-not-found':
    case 'auth/wrong-password':
      return 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'
    case 'auth/email-already-in-use':
      return 'อีเมลนี้ลงทะเบียนไว้แล้ว ลองเข้าสู่ระบบแทน'
    case 'auth/weak-password':
      return 'รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษรและคาดเดายาก'
    case 'auth/too-many-requests':
      return 'มีคำขอมากเกินไป กรุณารอสักครู่แล้วลองใหม่อีกครั้ง'
    case 'auth/network-request-failed':
      return 'เชื่อมต่อเครือข่าย Firebase ไม่ได้ ลองตรวจสอบการเชื่อมต่อแล้วลองใหม่'
    default:
      return error instanceof Error ? error.message : 'เข้าสู่ระบบด้วย Firebase ไม่สำเร็จ ลองอีกครั้ง'
  }
}
