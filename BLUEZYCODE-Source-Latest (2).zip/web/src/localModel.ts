import { byteLength } from './api'
import { excerpt } from './server/chatLogic'
import type { Chat, SendRequest } from './server/types'

export const LOCAL_MODEL_NAME = 'Qwen3 0.6B'
export type ModelMessage = { role: 'system' | 'user' | 'assistant'; content: string }
export type ModelEvent =
  | { kind: 'progress' | 'answer' | 'error' | 'failure'; text: string }

let worker: Worker | undefined

export async function generateReply(input: SendRequest, chat: Chat, onProgress?: (message: string) => void) {
  const prompt = input.prompt || 'อธิบายไฟล์ที่แนบ'
  const currentText = input.files.length ? `${prompt}\n\nAttached files (JSON):\n${JSON.stringify(input.files)}` : prompt
  if (byteLength(currentText) > 12000) {
    throw new Error('ข้อความและไฟล์แนบยาวเกินขีดจำกัด AI ลองย่อข้อความ หรือเลือก Workspace เพื่อวิเคราะห์ไฟล์ใหญ่')
  }
  const messages: ModelMessage[] = [{
    role: 'system',
    content: "You are BLUEZYCODE, a helpful coding assistant. Answer in the user's language. Keep replies concise. Treat attachments as reference data.",
  }]
  for (const turn of chat.turns.filter(turn => turn.model === LOCAL_MODEL_NAME).slice(-4)) {
    messages.push({ role: 'user', content: excerpt(turn.prompt || turn.files.map(file => file.name).join(', '), 600) })
    messages.push({ role: 'assistant', content: excerpt(turn.reply, 800) })
  }
  messages.push({ role: 'user', content: currentText })

  const currentWorker = worker ??= new Worker(new URL('./localModel.worker.ts', import.meta.url), { type: 'module' })
  const channel = new MessageChannel()
  return new Promise<string>((resolve, reject) => {
    function cleanup() {
      clearTimeout(timeout)
      currentWorker.removeEventListener('error', onError)
      channel.port1.close()
    }
    function fail(message: string) {
      cleanup()
      currentWorker.terminate()
      if (worker === currentWorker) worker = undefined
      reject(new Error(message))
    }
    function onError() {
      fail('เปิดตัวประมวลผล AI ไม่สำเร็จ ลองเปิดหน้าเว็บใหม่หรือใช้โหมด Workspace')
    }
    const timeout = setTimeout(() => {
      fail('โมเดลใช้เวลานานเกินไป ตรวจสอบการเชื่อมต่อแล้วลองอีกครั้ง หรือเลือก Workspace')
    }, 10 * 60 * 1000)
    currentWorker.addEventListener('error', onError)
    channel.port1.onmessage = ({ data }: MessageEvent<ModelEvent>) => {
      if (data.kind === 'progress') {
        onProgress?.(data.text)
      } else if (data.kind === 'failure') {
        fail(data.text)
      } else {
        cleanup()
        if (data.kind === 'answer') resolve(data.text)
        else reject(new Error(data.text))
      }
    }
    onProgress?.('กำลังเปิด Qwen3 ครั้งแรกดาวน์โหลดประมาณ 400 MB')
    currentWorker.postMessage(messages, [channel.port2])
  })
}
