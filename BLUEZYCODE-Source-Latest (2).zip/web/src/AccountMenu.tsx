import {
  ChevronRight,
  HelpCircle,
  Download,
  Keyboard,
  LogOut,
  Palette,
  Settings,
  Sparkles,
  UserRound,
  Wifi,
} from './icons'
import { DropdownMenu } from 'radix-ui'
import type { SettingsTab } from './api'
import { ProfileAvatar } from './ProfileAvatar'

type AccountMenuProps = {
  name: string
  photoURL?: string
  plan: string
  disabled: boolean
  open: boolean
  onOpenChange(open: boolean): void
  onSettings(tab: SettingsTab, showAppearance?: boolean): void
  onHelp(): void
  onShortcuts(): void
  onStatus(): void
  onExport(): void
  onAccount(): void
}

export function AccountMenu({
  name, photoURL, plan, disabled, open, onOpenChange, onSettings,
  onHelp, onShortcuts, onStatus, onExport, onAccount,
}: AccountMenuProps) {
  return (
    <DropdownMenu.Root open={open} onOpenChange={onOpenChange} modal={false}>
      <DropdownMenu.Trigger
        id="rail-account-trigger"
        className="oc-rb oc-account-trigger"
        aria-label="โปรไฟล์และการตั้งค่า"
        title="โปรไฟล์และการตั้งค่า"
        disabled={disabled}
      >
        <ProfileAvatar name={name} src={photoURL} size={31} />
      </DropdownMenu.Trigger>
      <DropdownMenu.Portal>
        <DropdownMenu.Content
          className="oc-account-menu"
          aria-label="โปรไฟล์และการตั้งค่า"
          side="right"
          sideOffset={10}
          align="end"
          collisionPadding={10}
          loop
        >
          <DropdownMenu.Label className="oc-account-heading">
            <ProfileAvatar name={name} src={photoURL} size={36} />
            <span className="oc-account-identity">
              <strong>{name.trim() || 'ผู้ใช้ BLUEZYCODE'}</strong>
              <small>{plan}</small>
            </span>
          </DropdownMenu.Label>
          <DropdownMenu.Separator className="oc-account-divider" />
          <DropdownMenu.Item className="oc-account-item" onSelect={() => onSettings('plan')}>
            <Sparkles size={17} /> แพ็กเกจ
          </DropdownMenu.Item>
          <DropdownMenu.Item className="oc-account-item" onSelect={() => onSettings('general', true)}>
            <Palette size={17} /> ปรับแต่งธีม
          </DropdownMenu.Item>
          <DropdownMenu.Item className="oc-account-item" onSelect={() => onSettings('account')}>
            <UserRound size={17} /> โปรไฟล์
          </DropdownMenu.Item>
          <DropdownMenu.Item className="oc-account-item" onSelect={() => onSettings('general')}>
            <Settings size={17} /> การตั้งค่า
          </DropdownMenu.Item>
          <DropdownMenu.Separator className="oc-account-divider" />
          <DropdownMenu.Sub>
            <DropdownMenu.SubTrigger className="oc-account-item">
              <HelpCircle size={17} /> วิธีใช้
              <ChevronRight size={15} className="oc-account-item-trailing" />
            </DropdownMenu.SubTrigger>
            <DropdownMenu.Portal>
              <DropdownMenu.SubContent className="oc-account-menu oc-account-submenu" sideOffset={8} collisionPadding={10} loop>
                <DropdownMenu.Item className="oc-account-item" onSelect={onHelp}>
                  <HelpCircle size={17} /> คำสั่งและคู่มือ
                </DropdownMenu.Item>
                <DropdownMenu.Item className="oc-account-item" onSelect={onShortcuts}>
                  <Keyboard size={17} /> คีย์ลัดแป้นพิมพ์
                  <kbd className="oc-account-item-trailing">Ctrl+/</kbd>
                </DropdownMenu.Item>
                <DropdownMenu.Item className="oc-account-item" onSelect={onStatus}>
                  <Wifi size={17} /> สถานะการเชื่อมต่อ
                </DropdownMenu.Item>
                <DropdownMenu.Item className="oc-account-item" onSelect={onExport}>
                  <Download size={17} /> ส่งออกแชตเป็น JSON
                </DropdownMenu.Item>
              </DropdownMenu.SubContent>
            </DropdownMenu.Portal>
          </DropdownMenu.Sub>
          <DropdownMenu.Item
            className="oc-account-item oc-account-signout"
            onSelect={onAccount}
          >
            <LogOut size={17} /> ออกจากระบบ
          </DropdownMenu.Item>
        </DropdownMenu.Content>
      </DropdownMenu.Portal>
    </DropdownMenu.Root>
  )
}
