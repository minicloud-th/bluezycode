import { byteLength } from '../api.ts';
import type { Analysis, Note } from './types.ts';

export const MAX_ENGINE_BYTES = 64 * 1024;

function splitLines(text: string): string[] {
  if (text.length === 0) {
    return [];
  }
  const withoutTrailingNewline = text.endsWith('\n')
    ? text.slice(0, text.endsWith('\r\n') ? -2 : -1)
    : text;
  return withoutTrailingNewline.split(/\r?\n/);
}

export function analyzeText(text: string): Analysis {
  const bytes = byteLength(text);
  if (bytes > MAX_ENGINE_BYTES) {
    throw new Error('input is larger than 64 KiB');
  }
  if (text.includes('\0')) {
    throw new Error('input must be a text file');
  }

  let lines = 0;
  let non_blank = 0;
  let longest = 0;
  const notes: Note[] = [];

  const split = splitLines(text);
  for (let index = 0; index < split.length; index++) {
    const line = split[index];
    lines = index + 1;
    const charCount = [...line].length;
    if (charCount > longest) {
      longest = charCount;
    }

    const trimmed = line.trim();
    if (trimmed.length === 0) {
      continue;
    }
    non_blank += 1;

    if (notes.length < 8) {
      const words = trimmed.split(/[^\p{L}\p{N}_]+/u);
      if (words.some((word) => word === 'TODO' || word === 'FIXME')) {
        notes.push({
          line: index + 1,
          text: [...trimmed].slice(0, 180).join(''),
        });
      }
    }
  }

  return {
    bytes,
    lines,
    non_blank,
    longest,
    notes,
  };
}
