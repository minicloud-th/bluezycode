import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeDashboardStats,
  defaultSettings,
  normalizeSettings,
  publicWorkspaceId,
  validateAndMergeSettings,
} from './settingsLogic';
import type { Workspace } from './types';

test('defaultSettings returns clean BLUEZYCODE defaults', () => {
  const settings = defaultSettings();
  assert.equal(settings.theme, 'dark');
  assert.equal(settings.accentColor, '#4a8dff');
  assert.equal(settings.language, 'th');
  assert.equal(settings.timezone, 'Asia/Bangkok');
  assert.equal(settings.plan, 'free');
  assert.equal(settings.billingCycle, 'monthly');
  assert.equal(settings.improveModel, false);
  assert.deepEqual(settings.connectors, {
    telegram: false,
    discord: false,
    line: false,
    github: false,
  });
});

test('normalizeSettings falls back cleanly for invalid values', () => {
  const normalized = normalizeSettings({
    theme: 'neon' as 'dark',
    accentColor: '#deadbe' as '#4a8dff',
    language: 'fr' as 'th',
    timezone: 'Mars/Phobos',
    email: 'invalid-email',
    plan: 'enterprise' as 'pro',
    connectors: { telegram: true, discord: 'yes' as unknown as boolean } as never,
  });
  assert.equal(normalized.theme, 'dark');
  assert.equal(normalized.accentColor, '#4a8dff');
  assert.equal(normalized.language, 'th');
  assert.equal(normalized.timezone, 'Asia/Bangkok');
  assert.equal(normalized.email, '');
  assert.equal(normalized.plan, 'free');
  assert.equal(normalized.connectors.telegram, true);
  assert.equal(normalized.connectors.discord, false);
});

test('validateAndMergeSettings updates valid fields and rejects bad email or connector', () => {
  const base = defaultSettings();
  const ok = validateAndMergeSettings(base, {
    theme: 'system',
    accentColor: '#a855f7',
    plan: 'pro',
    billingCycle: 'annually',
    email: 'dev@bluezycode.th',
    connectors: { telegram: true, github: true },
  });
  assert.equal(ok.ok, true);
  if (ok.ok) {
    assert.equal(ok.next.theme, 'system');
    assert.equal(ok.next.accentColor, '#a855f7');
    assert.equal(ok.next.plan, 'pro');
    assert.equal(ok.next.billingCycle, 'annually');
    assert.equal(ok.next.email, 'dev@bluezycode.th');
    assert.equal(ok.next.connectors.telegram, true);
    assert.equal(ok.next.connectors.github, true);
    assert.equal(ok.next.connectors.discord, false);
  }

  const badAccent = validateAndMergeSettings(base, { accentColor: '#000000' });
  assert.equal(badAccent.ok, false);

  const badEmail = validateAndMergeSettings(base, { email: 'not-an-email' });
  assert.equal(badEmail.ok, false);

  const badConnector = validateAndMergeSettings(base, {
    connectors: { slack: true },
  });
  assert.equal(badConnector.ok, false);
});

test('publicWorkspaceId hashes the local ID deterministically', async () => {
  const secret = 'a'.repeat(48);
  const pub1 = await publicWorkspaceId(secret);
  const pub2 = await publicWorkspaceId(secret);
  assert.equal(pub1, pub2);
  assert.ok(pub1.startsWith('bz_'));
  assert.ok(!pub1.includes('aaaaaaa'));
});

test('computeDashboardStats computes exact real metrics from workspace chats', () => {
  const now = new Date('2026-11-22T08:00:00.000Z');
  const ws: Workspace = {
    name: 'Dev',
    settings: defaultSettings(),
    chats: [
      {
        id: '1',
        title: 'Today chat',
        updated: '2026-11-22T07:30:00.000Z',
        turns: [
          {
            prompt: 'Hello world',
            reply: 'Reply content here',
            model: 'Workspace',
            files: [{ name: 'index.ts', content: 'console.log(1);' }],
          },
        ],
      },
    ],
    archivedChats: [
      {
        id: '2',
        title: 'Old archived chat',
        updated: '2026-11-20T07:30:00.000Z',
        turns: [
          {
            prompt: 'Old prompt',
            reply: 'Old reply',
            model: 'Workspace',
            files: [],
          },
        ],
      },
    ],
  };

  const stats = computeDashboardStats(ws, 8 * 1024 * 1024, now);
  assert.equal(stats.totalChats, 1);
  assert.equal(stats.archivedChats, 1);
  assert.equal(stats.totalTurns, 2);
  assert.equal(stats.todayTurns, 1);
  assert.equal(stats.totalFiles, 1);
  assert.ok(stats.estimatedTokens > 0);
  assert.ok(stats.storageBytes > 100);
});
