import type { Chat, ChatSummary, Turn, Workspace } from './types.ts';

export const MAX_WORKSPACE_BYTES = 8 * 1024 * 1024;

export function findChatIndex(ws: Workspace, id: string): number {
  return ws.chats.findIndex((chat) => chat.id === id);
}

export function workspaceSummaries(ws: Workspace): ChatSummary[] {
  return ws.chats.map((chat) => ({
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
  }));
}

export function archivedSummaries(ws: Workspace): ChatSummary[] {
  return (ws.archivedChats ?? []).map((chat) => ({
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
  }));
}

export function publicChat(chat: Chat): {
  id: string;
  title: string;
  updated: string;
  turns: Turn[];
  canRedo: boolean;
} {
  return {
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
    turns: chat.turns.map((turn) => ({
      prompt: turn.prompt,
      reply: turn.reply,
      model: turn.model,
      files: turn.files.map((file) => ({ name: file.name })),
    })),
    canRedo: (chat.redo?.length ?? 0) > 0,
  };
}
