export type Model = { id: string; name: string }
export type Attachment = { name: string; content: string }
export type ChatSummary = { id: string; title: string; updated: string }
export type Turn = { prompt: string; reply: string; model: string; files: Pick<Attachment, 'name'>[] }
export type Chat = ChatSummary & { turns: Turn[]; canRedo: boolean }

export type ThemePreference = 'dark' | 'light' | 'system'
export type AccentColor =
  | '#4a8dff'
  | '#2f6df0'
  | '#1fa3e8'
  | '#a855f7'
  | '#ec4899'
  | '#f59e0b'
  | '#84cc16'
  | '#8b8b92'
export type LanguagePreference = 'th' | 'en' | 'ja'
export type PlanId = 'free' | 'lite' | 'pro' | 'max'
export type BillingCycle = 'monthly' | 'quarterly' | 'annually'

export type ConnectorSettings = {
  telegram: boolean
  discord: boolean
  line: boolean
  github: boolean
}

export type WorkspaceSettings = {
  avatar?: string
  theme: ThemePreference
  accentColor: AccentColor
  language: LanguagePreference
  timezone: string
  email: string
  plan: PlanId
  billingCycle: BillingCycle
  improveModel: boolean
  connectors: ConnectorSettings
}

export type DashboardStats = {
  totalChats: number
  archivedChats: number
  chatLimit: number
  totalTurns: number
  todayTurns: number
  totalFiles: number
  estimatedTokens: number
  storageBytes: number
  maxStorageBytes: number
}

export type SettingsTab =
  | 'general'
  | 'account'
  | 'plan'
  | 'dashboard'
  | 'connectors'
  | 'privacy'
  | 'about'

export type AuthProviderId = 'google' | 'email'

export type AuthUser = {
  id: string
  email: string
  name: string
  provider: AuthProviderId
  photoURL?: string
}

export type Workspace = {
  publicId: string
  name: string
  chats: ChatSummary[]
  archivedChats: ChatSummary[]
  models: Model[]
  engineAvailable: boolean
  settings: WorkspaceSettings
  stats: DashboardStats
  user?: AuthUser
}

export type SettingsSnapshot = {
  publicId: string
  name: string
  archivedChats: ChatSummary[]
  settings: WorkspaceSettings
  stats: DashboardStats
}

export type SettingsSaveResult = {
  name: string
  settings: WorkspaceSettings
  stats: DashboardStats
}

export type ChatsActionResult = {
  name: string
  chats: ChatSummary[]
  archivedChats: ChatSummary[]
  settings: WorkspaceSettings
  stats: DashboardStats
}

export type ChatChange = {
  chat: Chat | null
  chats: ChatSummary[]
  stats?: DashboardStats
}

export class ApiError extends Error {
  constructor(message: string, readonly status: number) {
    super(message)
    this.name = 'ApiError'
  }
}

export type RequestOptions = { onProgress?: (message: string) => void }

let workspaceAccount: AuthUser | null = null
export function setWorkspaceAccount(account: AuthUser | null) {
  workspaceAccount = account
}

export async function api<T>(path: string, body?: unknown, options?: RequestOptions): Promise<T> {
  const account = workspaceAccount
  const { workspaceRequest } = await import('./localWorkspace')
  return workspaceRequest(path, body, account, options) as Promise<T>
}

const encoder = new TextEncoder()
export function byteLength(text: string) {
  return encoder.encode(text).length
}

export function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'เกิดข้อผิดพลาด ลองอีกครั้ง'
}
