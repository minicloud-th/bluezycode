import { useState } from 'react'
import type { FormEvent } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth'
import { ArrowLeft, Eye, EyeOff, Mail } from './icons'
import { errorMessage } from './api'
import type { AuthUser } from './api'
import { accountFromFirebase, firebaseAuth, firebaseErrorMessage, googleProvider } from './firebase'
import { IOS_EASE, IOS_SNAPPY_SPRING, IOS_SOFT_SPRING } from './motion'

type EmailMode = 'login' | 'register'

export function LoginScreen({
  onAuthenticated,
}: {
  onAuthenticated(result: AuthUser): void
}) {
  const [view, setView] = useState<'providers' | 'email'>('providers')
  const [emailMode, setEmailMode] = useState<EmailMode>('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [busyProvider, setBusyProvider] = useState<'google' | 'email' | null>(null)
  const [error, setError] = useState('')

  async function signInWithGoogle() {
    if (busyProvider) return
    setError('')
    if (!firebaseAuth) {
      setError('เชื่อมต่อ Firebase Authentication ไม่ได้ในขณะนี้')
      return
    }

    setBusyProvider('google')
    try {
      const credential = await signInWithPopup(firebaseAuth, googleProvider)
      onAuthenticated(accountFromFirebase(credential.user, 'google'))
    } catch (failure) {
      if (typeof failure === 'object' && failure !== null && 'code' in failure) {
        setError(firebaseErrorMessage(failure))
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      setBusyProvider(null)
    }
  }

  async function handleEmailSubmit(event: FormEvent) {
    event.preventDefault()
    if (busyProvider) return
    setError('')

    const trimmedEmail = email.trim()
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('กรุณากรอกอีเมลให้ถูกต้อง')
      return
    }
    if (emailMode === 'register' && password.length < 8) {
      setError('รหัสผ่านต้องมีความยาวอย่างน้อย 8 ตัวอักษร')
      return
    }
    if (!firebaseAuth) {
      setError('เชื่อมต่อ Firebase Authentication ไม่ได้ในขณะนี้')
      return
    }

    setBusyProvider('email')
    try {
      const trimmedName = name.trim()
      if (emailMode === 'register') {
        const credential = await createUserWithEmailAndPassword(firebaseAuth, trimmedEmail, password)
        if (trimmedName) {
          await updateProfile(credential.user, { displayName: trimmedName }).catch(() => {})
        }
        onAuthenticated({ ...accountFromFirebase(credential.user, 'email'), name: trimmedName || credential.user.displayName || '' })
      } else {
        const credential = await signInWithEmailAndPassword(firebaseAuth, trimmedEmail, password)
        onAuthenticated(accountFromFirebase(credential.user, 'email'))
      }
    } catch (failure) {
      if (typeof failure === 'object' && failure !== null && 'code' in failure) {
        setError(firebaseErrorMessage(failure))
      } else {
        setError(errorMessage(failure))
      }
    } finally {
      setBusyProvider(null)
    }
  }

  return (
    <motion.div
      className="oc-login-shell"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2, ease: IOS_EASE }}
    >
      <div className="oc-login-glow" aria-hidden="true" />

      <header className="oc-login-brand">
        <span className="bluezy-mark bluezy-mark-login" aria-hidden="true" />
        <span>BLUEZYCODE</span>
      </header>

      <main className="oc-login-center">
        <motion.section
          className="oc-login-card"
          aria-labelledby="login-heading"
          initial={{ opacity: 0, y: 14, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={IOS_SOFT_SPRING}
        >
          <div className="oc-login-head">
            <h1 id="login-heading">Welcome to BLUEZYCODE</h1>
          </div>

          <AnimatePresence mode="wait" initial={false}>
            {view === 'providers' ? (
              <motion.div
                key="providers-view"
                className="oc-auth-stack"
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.16, ease: IOS_EASE }}
              >
                <motion.button
                  type="button"
                  className="oc-auth-btn oc-auth-google"
                  disabled={busyProvider !== null}
                  whileTap={busyProvider ? undefined : { scale: 0.985 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => void signInWithGoogle()}
                >
                  <img src="/google-icons/google-g.svg" width="18" height="18" alt="" />
                  <span>{busyProvider === 'google' ? 'กำลังเชื่อมต่อ Google...' : 'ลงชื่อเข้าใช้ด้วย Google'}</span>
                </motion.button>

                <motion.button
                  type="button"
                  className="oc-auth-btn"
                  disabled={busyProvider !== null}
                  whileTap={busyProvider ? undefined : { scale: 0.985 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => {
                    setError('')
                    setView('email')
                  }}
                >
                  <Mail size={18} />
                  <span>ลงชื่อเข้าใช้ด้วยอีเมล</span>
                </motion.button>
              </motion.div>
            ) : (
              <motion.form
                key="email-view"
                className="oc-email-form"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18, ease: IOS_EASE }}
                onSubmit={handleEmailSubmit}
                noValidate
              >
                <div className="oc-email-topbar">
                  <motion.button
                    type="button"
                    className="oc-back-pill"
                    disabled={busyProvider !== null}
                    whileTap={busyProvider ? undefined : { scale: 0.95 }}
                    transition={IOS_SNAPPY_SPRING}
                    onClick={() => {
                      setError('')
                      setView('providers')
                    }}
                  >
                    <ArrowLeft size={14} />
                    <span>กลับ</span>
                  </motion.button>

                  <div className="oc-pill-seg" role="tablist" aria-label="ประเภทบัญชีอีเมล">
                    {(
                      [
                        ['login', 'เข้าสู่ระบบ'],
                        ['register', 'สมัครสมาชิก'],
                      ] as const
                    ).map(([modeId, label]) => {
                      const active = emailMode === modeId
                      return (
                        <button
                          key={modeId}
                          type="button"
                          role="tab"
                          aria-selected={active}
                          className={active ? 'on' : ''}
                          disabled={busyProvider !== null}
                          onClick={() => {
                            setError('')
                            setEmailMode(modeId)
                          }}
                        >
                          {active && (
                            <motion.span
                              layoutId="auth-mode-pill"
                              className="oc-seg-bg"
                              transition={IOS_SNAPPY_SPRING}
                              aria-hidden="true"
                            />
                          )}
                          <span className="relative z-1">{label}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>

                <AnimatePresence initial={false}>
                  {emailMode === 'register' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.16, ease: IOS_EASE }}
                      style={{ overflow: 'hidden' }}
                    >
                      <label htmlFor="login-name" className="sr-only">
                        ชื่อที่แสดง
                      </label>
                      <input
                        id="login-name"
                        type="text"
                        className="oc-field"
                        placeholder="ชื่อที่แสดง (ไม่บังคับ)"
                        maxLength={40}
                        autoComplete="name"
                        disabled={busyProvider !== null}
                        value={name}
                        onChange={event => setName(event.target.value)}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>

                <div>
                  <label htmlFor="login-email" className="sr-only">
                    อีเมล
                  </label>
                  <input
                    id="login-email"
                    type="email"
                    className="oc-field"
                    placeholder="you@bluezycode.dev"
                    maxLength={120}
                    autoComplete="email"
                    autoFocus
                    disabled={busyProvider !== null}
                    value={email}
                    onChange={event => setEmail(event.target.value)}
                  />
                </div>

                <div className="oc-pw-wrap">
                  <label htmlFor="login-password" className="sr-only">
                    รหัสผ่าน
                  </label>
                  <input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    className="oc-field"
                    style={{ paddingRight: 44 }}
                    placeholder={
                      emailMode === 'register' ? 'รหัสผ่านอย่างน้อย 8 ตัวอักษร' : 'รหัสผ่าน'
                    }
                    maxLength={128}
                    autoComplete={emailMode === 'register' ? 'new-password' : 'current-password'}
                    disabled={busyProvider !== null}
                    value={password}
                    onChange={event => setPassword(event.target.value)}
                  />
                  <button
                    type="button"
                    className="oc-pw-eye"
                    aria-label={showPassword ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน'}
                    disabled={busyProvider !== null}
                    onClick={() => setShowPassword(prev => !prev)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>

                <motion.button
                  type="submit"
                  className="oc-primary"
                  style={{ marginTop: 2 }}
                  disabled={busyProvider !== null}
                  whileTap={busyProvider ? undefined : { scale: 0.985 }}
                  transition={IOS_SNAPPY_SPRING}
                >
                  {busyProvider === 'email'
                    ? 'กำลังดำเนินการ...'
                    : emailMode === 'register'
                      ? 'สร้างบัญชี BLUEZYCODE'
                      : 'เข้าสู่ระบบ'}
                </motion.button>
              </motion.form>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {error && (
              <motion.p
                className="error oc-login-error"
                role="alert"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={IOS_SNAPPY_SPRING}
              >
                {error}
              </motion.p>
            )}
          </AnimatePresence>

          <p className="oc-login-legal">
            เมื่อดำเนินการต่อ คุณยอมรับ{' '}
            <a href="/terms" target="_blank" rel="noopener noreferrer">ข้อกำหนดการใช้งาน</a>
            {' '}และรับทราบ{' '}
            <a href="/privacy" target="_blank" rel="noopener noreferrer">นโยบายความเป็นส่วนตัว</a>
            {' '}ของ BLUEZYCODE
          </p>
        </motion.section>
      </main>
    </motion.div>
  )
}
