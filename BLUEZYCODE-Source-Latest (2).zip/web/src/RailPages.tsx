import { useState } from 'react'
import { motion } from 'motion/react'
import { ChevronRight, Plus, RefreshCw } from './icons'
import type { ChatSummary, SettingsTab, Workspace } from './api'
import { IOS_SNAPPY_SPRING, IOS_SOFT_SPRING } from './motion'
import type { RailSection } from './Rail'

const STARTER_IDEAS: { title: string; subtitle: string; prompt: string }[] = [
  {
    title: 'สรุปโครงสร้างไฟล์และตรวจ TODO/FIXME',
    subtitle: 'วิเคราะห์ไฟล์ข้อความ UTF-8 ด้วย Workspace Engine',
    prompt: 'ช่วยสรุปโครงสร้างไฟล์และจุดสำคัญที่ควรปรับปรุงให้หน่อย',
  },
  {
    title: 'รีวิวความปลอดภัยและการตรวจสอบอินพุต',
    subtitle: 'เช็กการป้องกัน XSS, Path Traversal และสิทธิ์เข้าถึง API',
    prompt: 'ช่วยตรวจสอบความเสี่ยงด้านความปลอดภัยของโค้ดชุดนี้ทีละจุด',
  },
  {
    title: 'ปรับปรุงประสิทธิภาพและโครงสร้างคอมโพเนนต์',
    subtitle: 'แนะนำวิธีลด Re-render และแยกโมดูลให้ดูแลง่าย',
    prompt: 'ช่วยแนะนำวิธี Refactor โค้ดให้กระชับและทำงานเร็วขึ้น',
  },
  {
    title: 'สร้างเคสทดสอบด้วย node:test',
    subtitle: 'เขียน Unit Test ครอบคลุม Boundary และ Error cases',
    prompt: 'ช่วยออกแบบและเขียน Unit Test สำหรับฟังก์ชันหลักในไฟล์นี้',
  },
]

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
}

function formatDate(date: string, language = 'th', timeZone?: string) {
  const locale = language === 'en' ? 'en-US' : language === 'ja' ? 'ja-JP' : 'th-TH'
  try {
    return new Intl.DateTimeFormat(locale, {
      day: 'numeric',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
      timeZone,
    }).format(new Date(date))
  } catch {
    return new Intl.DateTimeFormat(locale, {
      day: 'numeric',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
    }).format(new Date(date))
  }
}

export function RailPages({
  section,
  workspace,
  activeChatId,
  busy,
  onNewChat,
  onOpenChat,
  onStartPrompt,
  onRefresh,
  onOpenSettings,
  onOpenHelpModal,
}: {
  section: Exclude<RailSection, 'home'>
  workspace: Workspace
  activeChatId: string | null
  busy: boolean
  onNewChat(): void
  onOpenChat(item: ChatSummary): void
  onStartPrompt(prompt: string): void
  onRefresh(): Promise<void>
  onOpenSettings(tab: SettingsTab): void
  onOpenHelpModal(): void
}) {
  const [searchQuery, setSearchQuery] = useState('')
  const [refreshing, setRefreshing] = useState(false)

  const aiModelName = workspace.models.find(item => item.id === 'ai')?.name
  const { stats, settings, chats } = workspace

  const filteredChats = chats.filter(item =>
    item.title.toLocaleLowerCase().includes(searchQuery.trim().toLocaleLowerCase()),
  )

  const chatUsagePct = Math.min(100, Math.round((stats.totalChats / stats.chatLimit) * 100))
  const storagePct = Math.min(
    100,
    Math.max(stats.storageBytes > 0 ? 1 : 0, Math.round((stats.storageBytes / stats.maxStorageBytes) * 100)),
  )

  async function handleRefresh() {
    setRefreshing(true)
    try {
      await onRefresh()
    } finally {
      setRefreshing(false)
    }
  }

  return (
    <div className="oc-page">
      <motion.div
        key={section}
        className="oc-pcol"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={IOS_SOFT_SPRING}
      >
        {section === 'chats' && (
          <>
            <div className="oc-ph" style={{ marginBottom: 16 }}>
              <h2>แชตทั้งหมด</h2>
              <button
                type="button"
                className="oc-sm on"
                disabled={busy}
                onClick={onNewChat}
              >
                <Plus size={14} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 4 }} />
                แชตใหม่
              </button>
            </div>
            {chats.length === 0 ? (
              <p className="oc-none">ยังไม่มีแชตที่บันทึกไว้ กดแชตใหม่เพื่อเริ่มวิเคราะห์โค้ด</p>
            ) : (
              chats.map(item => (
                <motion.button
                  key={item.id}
                  type="button"
                  className="oc-card oc-row"
                  disabled={busy}
                  aria-current={activeChatId === item.id ? 'page' : undefined}
                  whileTap={busy ? undefined : { scale: 0.99 }}
                  transition={IOS_SNAPPY_SPRING}
                  onClick={() => onOpenChat(item)}
                >
                  <span>
                    <b>{item.title}</b>
                    <small>{formatDate(item.updated, settings.language, settings.timezone)}</small>
                  </span>
                  <ChevronRight size={16} className="oc-go" />
                </motion.button>
              ))
            )}
          </>
        )}

        {section === 'search' && (
          <>
            <h2>ค้นหาแชต</h2>
            <input
              className="oc-field"
              type="search"
              placeholder="พิมพ์คำค้นหาชื่อแชตใน Workspace..."
              aria-label="ค้นหาแชต"
              value={searchQuery}
              onChange={event => setSearchQuery(event.target.value)}
            />
            {filteredChats.length === 0 ? (
              <p className="oc-none">
                {searchQuery.trim() ? 'ไม่พบแชตที่ตรงกับคำค้นหา' : 'ยังไม่มีแชตใน Workspace'}
              </p>
            ) : (
              filteredChats.map(item => (
                <button
                  key={item.id}
                  type="button"
                  className="oc-card oc-row"
                  disabled={busy}
                  onClick={() => onOpenChat(item)}
                >
                  <span>
                    <b>{item.title}</b>
                    <small>{formatDate(item.updated, settings.language, settings.timezone)}</small>
                  </span>
                  <ChevronRight size={16} className="oc-go" />
                </button>
              ))
            )}
          </>
        )}

        {section === 'ideas' && (
          <>
            <h2>คำสั่งและเทมเพลตด่วน</h2>
            <p className="oc-none" style={{ marginTop: 0, marginBottom: 14 }}>
              เลือกหัวข้อเพื่อส่งเข้าห้องแชตหลักได้ทันที หรือใช้คำสั่ง /help เพื่อดูคำสั่งทั้งหมด
            </p>
            {STARTER_IDEAS.map(idea => (
              <motion.button
                key={idea.title}
                type="button"
                className="oc-card oc-row"
                disabled={busy}
                whileTap={busy ? undefined : { scale: 0.985 }}
                transition={IOS_SNAPPY_SPRING}
                onClick={() => onStartPrompt(idea.prompt)}
              >
                <span>
                  <b>{idea.title}</b>
                  <small>{idea.subtitle}</small>
                </span>
                <ChevronRight size={16} className="oc-go" />
              </motion.button>
            ))}
            <motion.button
              type="button"
              className="oc-card oc-row"
              whileTap={{ scale: 0.985 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={onOpenHelpModal}
            >
              <span>
                <b>ดูคำสั่ง Slash ทั้งหมด</b>
                <small>/new, /models, /undo, /redo, /share, /compact, /help</small>
              </span>
              <ChevronRight size={16} className="oc-go" />
            </motion.button>
          </>
        )}

        {section === 'cloud' && (
          <>
            <h2>สถานะ Workspace</h2>
            <div className="oc-card">
              <div className="oc-row">
                <span>
                  <b>พื้นที่จัดเก็บในเบราว์เซอร์</b>
                  <small>จัดเก็บประวัติแชตและการตั้งค่าบนอุปกรณ์นี้</small>
                </span>
                <span className="oc-sp">พร้อมใช้งาน</span>
              </div>
            </div>
            <div className="oc-card">
              <div className="oc-row">
                <span>
                  <b>เอนจินวิเคราะห์ไฟล์ Local UTF-8</b>
                  <small>นับบรรทัด ขนาดไบต์ และค้นหา TODO/FIXME</small>
                </span>
                <span className="oc-sp">{workspace.engineAvailable ? 'พร้อมใช้งาน' : 'ยังไม่พร้อม'}</span>
              </div>
            </div>
            <div className="oc-card">
              <div className="oc-row">
                <span>
                  <b>โมเดลประมวลผล</b>
                  <small>Qwen3 ประมวลผลในเบราว์เซอร์หลังดาวน์โหลดโมเดล</small>
                </span>
                <span className="oc-sp">{aiModelName ?? 'Local Workspace'}</span>
              </div>
            </div>
            <motion.button
              type="button"
              className="oc-card oc-row"
              whileTap={{ scale: 0.985 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={() => onOpenSettings('connectors')}
            >
              <span>
                <b>จัดการการเชื่อมต่อภายนอก</b>
                <small>Telegram, Discord, LINE, GitHub Sync</small>
              </span>
              <ChevronRight size={16} className="oc-go" />
            </motion.button>
          </>
        )}

        {section === 'dashboard' && (
          <>
            <div className="oc-ph" style={{ marginBottom: 16 }}>
              <h2>แดชบอร์ดสถิติ Workspace</h2>
              <button
                type="button"
                className="oc-rb"
                aria-label="รีเฟรชข้อมูลสถิติ"
                disabled={busy || refreshing}
                onClick={() => void handleRefresh()}
              >
                <RefreshCw size={18} className={refreshing ? 'animate-spin' : ''} />
              </button>
            </div>
            <div className="oc-stats" style={{ borderRadius: 18, border: '1px solid var(--line)', background: 'var(--card)' }}>
              <div>
                <b className="tabular-nums">{stats.todayTurns.toLocaleString()}</b>
                <span>ข้อความวันนี้</span>
              </div>
              <div>
                <b className="tabular-nums">{stats.totalFiles.toLocaleString()}</b>
                <span>ไฟล์ที่วิเคราะห์</span>
              </div>
              <div>
                <b className="tabular-nums">{stats.estimatedTokens.toLocaleString()}</b>
                <span>โทเคนโดยประมาณ</span>
              </div>
            </div>
            <div className="oc-card">
              <div className="oc-row">
                <span>
                  <b>แชตที่ใช้งานอยู่</b>
                  <small>จำกัดสูงสุด {stats.chatLimit} แชตต่อ Workspace</small>
                </span>
                <span className="oc-sp tabular-nums">
                  {stats.totalChats} / {stats.chatLimit} ({chatUsagePct}%)
                </span>
              </div>
              <div className="oc-bar">
                <i style={{ width: `${chatUsagePct}%` }} />
              </div>
              <div className="oc-row">
                <span>
                  <b>พื้นที่จัดเก็บ JSON Workspace</b>
                  <small>ขนาดรวมแชตที่ใช้งานและที่เก็บถาวร</small>
                </span>
                <span className="oc-sp tabular-nums">
                  {formatBytes(stats.storageBytes)} / {formatBytes(stats.maxStorageBytes)} ({storagePct}%)
                </span>
              </div>
              <div className="oc-bar" style={{ marginBottom: 2 }}>
                <i style={{ width: `${storagePct}%` }} />
              </div>
            </div>
          </>
        )}

      </motion.div>
    </div>
  )
}
