const MAX_SOURCE_BYTES = 10 * 1024 * 1024
const MAX_SAVED_LENGTH = 120 * 1024
const INPUT_TYPES = ['image/jpeg', 'image/png', 'image/webp']
const JPEG_DATA_URL = /^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]*={0,2}$/

export function isStoredProfileImage(value: unknown): value is string {
  return typeof value === 'string' && value.length <= MAX_SAVED_LENGTH && JPEG_DATA_URL.test(value)
}

export async function prepareProfileImage(file: File): Promise<string> {
  if (!INPUT_TYPES.includes(file.type)) throw new Error('เลือกรูป JPG, PNG หรือ WebP')
  if (file.size === 0 || file.size > MAX_SOURCE_BYTES) throw new Error('เลือกรูปขนาดไม่เกิน 10 MB')

  const url = URL.createObjectURL(file)
  try {
    const image = new Image()
    image.src = url
    await image.decode()
    const { naturalWidth: width, naturalHeight: height } = image
    const side = Math.min(width, height)
    if (!side) throw new Error('Empty image')

    const canvas = document.createElement('canvas')
    canvas.width = canvas.height = 256
    const context = canvas.getContext('2d')
    if (!context) throw new Error('Canvas unavailable')
    context.fillStyle = '#fff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    context.drawImage(image, (width - side) / 2, (height - side) / 2, side, side, 0, 0, canvas.width, canvas.height)
    const result = canvas.toDataURL('image/jpeg', 0.86)
    if (!isStoredProfileImage(result)) throw new Error('Invalid image output')
    return result
  } catch {
    throw new Error('เปิดไฟล์รูปนี้ไม่ได้ ลองเลือกรูปอื่น')
  } finally {
    URL.revokeObjectURL(url)
  }
}
