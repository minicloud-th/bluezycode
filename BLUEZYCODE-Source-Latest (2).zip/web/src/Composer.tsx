import { useEffect, useRef, useState } from 'react'
import type { FormEvent, KeyboardEvent } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { byteLength, errorMessage } from './api'
import type { Attachment, Model } from './api'
import { Icon } from './icons'
import { IOS_SNAPPY_SPRING, IOS_SPRING } from './motion'

export const commands = [
  { name: '/new', description: 'เปิดแชตใหม่' },
  { name: '/models', description: 'เลือกโมเดล' },
  { name: '/undo', description: 'ย้อนข้อความล่าสุด' },
  { name: '/redo', description: 'คืนข้อความที่ย้อน' },
  { name: '/share', description: 'ดาวน์โหลดแชตเป็น Markdown' },
  { name: '/compact', description: 'ดูสรุปแชต' },
  { name: '/help', description: 'ดูคำสั่งทั้งหมด' },
] as const
export type Command = typeof commands[number]['name']

type Props = {
  busy: boolean
  ready: boolean
  draft: string
  files: Attachment[]
  model: string
  models: Model[]
  onDraft(value: string): void
  onFiles(files: Attachment[]): void
  onModel(id: string): void
  onSend(): void
  onCommand(command: Command): void
  onError(message: string): void
}

export function Composer(props: Props) {
  const { busy, ready, draft, files, model, models, onDraft, onFiles, onModel, onSend, onCommand, onError } = props
  const input = useRef<HTMLTextAreaElement>(null)
  const picker = useRef<HTMLInputElement>(null)
  const popup = useRef<HTMLDivElement>(null)
  const modelButton = useRef<HTMLButtonElement>(null)
  const firstModel = useRef<HTMLButtonElement>(null)
  const [cursor, setCursor] = useState(0)
  const [active, setActive] = useState(0)
  const [focused, setFocused] = useState(false)
  const [dismissed, setDismissed] = useState(false)
  const [showModels, setShowModels] = useState(false)
  const [reading, setReading] = useState(false)
  const blocked = busy || reading || !ready

  useEffect(() => {
    if (!showModels) return
    firstModel.current?.focus()
    function closeOutside(event: PointerEvent) {
      const target = event.target as Node
      if (!popup.current?.contains(target) && !modelButton.current?.contains(target)) {
        setShowModels(false)
      }
    }
    document.addEventListener('pointerdown', closeOutside)
    return () => document.removeEventListener('pointerdown', closeOutside)
  }, [showModels])

  const token = draft.slice(0, cursor).match(/(?:^|\s)(\/\S*|@\S*)$/)?.[1]
  const isCommand = token?.startsWith('/') && token.length === cursor
  const fileOptions = [
    ...files.map(({ name }) => ({ name: '@' + name, description: 'ไฟล์แนบ' })),
    { name: '@', description: 'แนบไฟล์จากเครื่อง', picker: true },
  ]
  const options = focused && !dismissed && !showModels && token && !blocked
    ? (isCommand ? commands : token.startsWith('@') ? fileOptions : []).filter(
        option => option.name.toLowerCase().startsWith(token.toLowerCase()),
      )
    : []
  const selectedIndex = Math.min(active, options.length - 1)
  const canSend = !blocked && Boolean(draft.trim() || files.length)

  function applyOption(index: number) {
    const choice = options[index]
    if (!choice || !token) return
    const before = draft.slice(0, cursor - token.length)
    const after = draft.slice(cursor)
    if ('picker' in choice) {
      onDraft(before + after)
      picker.current?.click()
    } else if (choice.name === '/models') {
      onDraft(after.trimStart())
      setShowModels(true)
    } else {
      const value = before + choice.name + ' ' + after
      const position = before.length + choice.name.length + 1
      onDraft(value)
      setCursor(position)
      requestAnimationFrame(() => input.current?.setSelectionRange(position, position))
    }
    setDismissed(true)
  }

  function submit(event?: FormEvent) {
    event?.preventDefault()
    if (blocked) return
    setDismissed(true)
    setShowModels(false)
    const command = commands.find(item => item.name === draft.trim())
    if (command?.name === '/models') {
      onDraft('')
      setShowModels(true)
      return
    }
    if (command) {
      onCommand(command.name)
      return
    }
    onSend()
  }

  function handleKeys(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.nativeEvent.isComposing) return
    if (options.length) {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault()
        setActive((selectedIndex + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length)
        return
      }
      if ((event.key === 'Tab' || event.key === 'Enter') && !event.shiftKey) {
        event.preventDefault()
        applyOption(selectedIndex)
        return
      }
      if (event.key === 'Escape') {
        event.preventDefault()
        setDismissed(true)
        return
      }
    }
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      submit()
    }
  }

  async function addFiles(list: FileList | null) {
    const chosen = Array.from(list ?? [])
    if (!chosen.length || blocked) return
    setReading(true)
    try {
      if (files.length + chosen.length > 4 || chosen.some(file => file.size > 64 * 1024)) {
        throw new Error('แนบได้สูงสุด 4 ไฟล์ ไฟล์ละ 64 KiB')
      }
      const textDecoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true })
      const additions = await Promise.all(chosen.map(async file => {
        let content: string
        try {
          content = textDecoder.decode(await file.arrayBuffer())
        } catch {
          throw new Error(file.name + ' ต้องเป็นไฟล์ข้อความ UTF-8')
        }
        if (content.includes('\x00')) throw new Error(file.name + ' ต้องเป็นไฟล์ข้อความ UTF-8')
        return { name: file.name, content }
      }))
      const combined = [...files, ...additions]
      if (combined.reduce((total, file) => total + byteLength(file.content), 0) > 192 * 1024) {
        throw new Error('ขนาดไฟล์รวมต้องไม่เกิน 192 KiB')
      }
      onFiles(combined)
      onError('')
    } catch (error) {
      onError(errorMessage(error))
    } finally {
      setReading(false)
      if (picker.current) picker.current.value = ''
      input.current?.focus()
    }
  }

  const attachmentCounts = new Map<string, number>()
  const keyedFiles = files.map((file, index) => {
    const count = (attachmentCounts.get(file.name) ?? 0) + 1
    attachmentCounts.set(file.name, count)
    return { file, index, key: `${file.name}#${count}` }
  })

  return <form className="composer" onSubmit={submit}>
    <AnimatePresence>
      {options.length > 0 && <motion.div
        key="suggestions"
        id="suggestions"
        className="picker suggestions"
        role="listbox"
        aria-label="คำแนะนำ"
        initial={{ opacity: 0, y: 8, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 6, scale: 0.97 }}
        transition={IOS_SNAPPY_SPRING}
        style={{ transformOrigin: 'bottom center' }}
      >
        {options.map((option, index) => <div key={option.name} role="option"
          id={'suggestion-' + index} aria-selected={index === selectedIndex}
          onPointerDown={event => event.preventDefault()} onClick={() => applyOption(index)}
          className={'picker-option' + (index === selectedIndex ? ' selected' : '')}>
          <span className="option-name">{option.name}</span><span>{option.description}</span>
        </div>)}
      </motion.div>}
    </AnimatePresence>

    <AnimatePresence initial={false}>
      {keyedFiles.length > 0 && <motion.ul
        className="attachments"
        initial={{ opacity: 0, height: 0, marginBottom: 0 }}
        animate={{ opacity: 1, height: 'auto', marginBottom: 8 }}
        exit={{ opacity: 0, height: 0, marginBottom: 0 }}
        transition={IOS_SPRING}
      >
        {keyedFiles.map(({ file, index, key }) => <motion.li
          key={key}
          initial={{ opacity: 0, scale: 0.88 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.85 }}
          transition={IOS_SNAPPY_SPRING}
        >
          <Icon name="file" size={14} /><span>{file.name}</span>
          <button type="button" aria-label={'เอา ' + file.name + ' ออก'} disabled={blocked}
            onClick={() => onFiles(files.filter((_, item) => item !== index))}><Icon name="close" size={13} /></button>
        </motion.li>)}
      </motion.ul>}
    </AnimatePresence>

    <label className="sr-only" htmlFor="prompt">ข้อความ</label>
    <textarea id="prompt" ref={input} value={draft} rows={1} maxLength={12000}
      disabled={busy || !ready} aria-autocomplete="list"
      aria-controls={options.length ? 'suggestions' : undefined}
      aria-activedescendant={options.length ? 'suggestion-' + selectedIndex : undefined}
      placeholder="พิมพ์ข้อความ ใช้ / สำหรับคำสั่ง และ @ สำหรับไฟล์"
      onChange={event => {
        onDraft(event.target.value)
        setCursor(event.target.selectionStart)
        setActive(0)
        setDismissed(false)
      }}
      onSelect={event => setCursor(event.currentTarget.selectionStart)}
      onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onKeyDown={handleKeys} />

    <div className="tools">
      <input ref={picker} type="file" multiple hidden onChange={event => void addFiles(event.target.files)} />
      <motion.button
        className="icon-button"
        type="button"
        aria-label="แนบไฟล์"
        title="แนบไฟล์"
        disabled={blocked}
        whileTap={blocked ? undefined : { scale: 0.88 }}
        transition={IOS_SNAPPY_SPRING}
        onClick={() => picker.current?.click()}
      >
        <Icon name="plus" size={16} />
      </motion.button>
      <div className="model-wrapper">
        <motion.button
          type="button"
          className="model-button"
          aria-expanded={showModels}
          aria-controls="models"
          ref={modelButton}
          disabled={blocked}
          whileTap={blocked ? undefined : { scale: 0.95 }}
          transition={IOS_SNAPPY_SPRING}
          onClick={() => setShowModels(!showModels)}
        >
          {models.find(item => item.id === model)?.name ?? 'โมเดล'}
          <motion.span
            aria-hidden="true"
            animate={{ rotate: showModels ? 180 : 0 }}
            transition={IOS_SNAPPY_SPRING}
            style={{ display: 'inline-flex' }}
          >
            <Icon name="chevron" size={13} />
          </motion.span>
        </motion.button>
        <AnimatePresence>
          {showModels && <motion.div
            key="models"
            id="models"
            className="picker model-picker"
            ref={popup}
            role="group"
            aria-label="เลือกโมเดล"
            initial={{ opacity: 0, y: 8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 6, scale: 0.96 }}
            transition={IOS_SNAPPY_SPRING}
            style={{ transformOrigin: 'bottom left' }}
            onKeyDown={event => {
              if (event.key === 'Escape') {
                setShowModels(false)
                modelButton.current?.focus()
              }
            }}
          >
            {models.map((item, index) => <motion.button
              type="button"
              key={item.id}
              ref={index === 0 ? firstModel : undefined}
              className="picker-option"
              aria-pressed={item.id === model}
              whileTap={{ scale: 0.97 }}
              transition={IOS_SNAPPY_SPRING}
              onClick={() => {
                onModel(item.id)
                setShowModels(false)
                input.current?.focus()
              }}
            >
              <span>{item.name}</span>{item.id === model && <Icon name="check" size={15} />}
            </motion.button>)}
            <p>Qwen3 ประมวลผลบนเครื่อง ดาวน์โหลดโมเดลประมาณ 400 MB ครั้งแรก</p>
          </motion.div>}
        </AnimatePresence>
      </div>
      <motion.button
        className="send-button"
        title="ส่ง"
        aria-label="ส่ง"
        disabled={!canSend}
        animate={{ scale: canSend ? 1 : 0.94 }}
        whileTap={canSend ? { scale: 0.88 } : undefined}
        transition={IOS_SNAPPY_SPRING}
      >
        <Icon name="send" size={16} />
      </motion.button>
    </div>
  </form>
}
