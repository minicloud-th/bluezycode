import dotenv from 'dotenv';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import {
  analyzeFilesReply,
  isValidProfileName,
  summarizeChat,
  titleFor,
  validRequest,
} from './src/server/chatLogic.ts';
import {
  completeWithProvider,
  ProviderContextError,
  providerFromEnv,
} from './src/server/provider.ts';
import {
  extractWorkspaceID,
  findChatIndex,
  newID,
  publicChat,
  Storage,
  WorkspaceFullError,
  workspaceSummaries,
} from './src/server/store.ts';
import type { Chat, Model, SendRequest, Workspace } from './src/server/types.ts';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = process.env.BLUEZY_DATA_DIR || 'data';
const SECURE_COOKIE = process.env.BLUEZY_SECURE_COOKIE === '1';
const IS_PROD = process.env.NODE_ENV === 'production';

const provider = providerFromEnv();
const store = new Storage(DATA_DIR);

function availableModels(): Model[] {
  const models: Model[] = [{ id: 'workspace', name: 'Workspace' }];
  if (provider) {
    models.push({ id: 'ai', name: provider.model });
  }
  return models;
}

function problem(res: express.Response, status: number, message: string): void {
  res.status(status).json({ error: message });
}

function handleStorageError(res: express.Response, error: unknown): void {
  if (error instanceof WorkspaceFullError) {
    problem(res, 507, error.message);
    return;
  }
  console.error('workspace failure:', error);
  problem(res, 500, 'อ่านหรือบันทึกข้อมูลไม่สำเร็จ ลองอีกครั้ง');
}

function isHttpsRequest(req: express.Request): boolean {
  const forwarded = req.headers['x-forwarded-proto'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim() === 'https';
  }
  return req.secure;
}

async function openWorkspace(
  req: express.Request,
  res: express.Response,
  action: (id: string, ws: Workspace) => Promise<void>,
): Promise<void> {
  const id = extractWorkspaceID(req.headers.cookie);
  if (!id) {
    problem(res, 401, 'โหลดหน้าใหม่เพื่อเปิดพื้นที่ทำงาน');
    return;
  }
  await store.withLock(id, async () => {
    let ws: Workspace;
    try {
      ws = await store.load(id);
    } catch (error) {
      handleStorageError(res, error);
      return;
    }
    await action(id, ws);
  });
}

function hasOnlyKeys(obj: unknown, allowed: Set<string>): obj is Record<string, unknown> {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
    return false;
  }
  return Object.keys(obj).every((key) => allowed.has(key));
}

async function createServer(): Promise<void> {
  await store.init();

  const app = express();
  app.set('trust proxy', 1);

  // Security headers
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'same-origin');
    next();
  });

  // Origin & content-type guard for /api/
  app.use('/api', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      const origin = req.headers.origin;
      const host = (req.headers['x-forwarded-host'] as string | undefined) || req.headers.host || '';
      if (origin) {
        try {
          const parsed = new URL(origin);
          if (
            (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') ||
            parsed.host.toLowerCase() !== host.split(',')[0].trim().toLowerCase()
          ) {
            problem(res, 403, 'อนุญาตคำขอจากหน้า BLUEZYCODE เท่านั้น');
            return;
          }
        } catch {
          problem(res, 403, 'อนุญาตคำขอจากหน้า BLUEZYCODE เท่านั้น');
          return;
        }
      }
      if (req.headers['sec-fetch-site'] === 'cross-site') {
        problem(res, 403, 'อนุญาตคำขอจากหน้า BLUEZYCODE เท่านั้น');
        return;
      }
      const contentType = req.headers['content-type'] ?? '';
      if (!contentType.toLowerCase().includes('application/json')) {
        problem(res, 415, 'รองรับข้อมูล JSON เท่านั้น');
        return;
      }
    }
    next();
  });

  app.use('/api', express.json({ limit: 1280 * 1024, strict: true }));

  app.use('/api', (err: unknown, _req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (err && typeof err === 'object' && 'type' in err && (err as { type?: string }).type === 'entity.too.large') {
      problem(res, 413, 'ข้อมูลมีขนาดใหญ่เกินไป');
      return;
    }
    if (err instanceof SyntaxError) {
      problem(res, 400, 'รูปแบบข้อมูลไม่ถูกต้อง');
      return;
    }
    next(err);
  });

  app.get('/api/workspace', async (req, res) => {
    let id = extractWorkspaceID(req.headers.cookie);
    if (!id) {
      id = newID();
      const secure = SECURE_COOKIE || isHttpsRequest(req);
      res.cookie('bluezy_workspace', id, {
        path: '/',
        maxAge: 31536000 * 1000,
        httpOnly: true,
        sameSite: secure ? 'none' : 'lax',
        secure,
      });
    }

    await store.withLock(id, async () => {
      try {
        const ws = await store.load(id);
        res.json({
          name: ws.name,
          chats: workspaceSummaries(ws),
          models: availableModels(),
          engineAvailable: true,
        });
      } catch (error) {
        handleStorageError(res, error);
      }
    });
  });

  app.get('/api/chats/:id', async (req, res) => {
    await openWorkspace(req, res, async (_id, ws) => {
      const index = findChatIndex(ws, req.params.id);
      if (index < 0) {
        problem(res, 404, 'ไม่พบแชตนี้');
        return;
      }
      res.json(publicChat(ws.chats[index]));
    });
  });

  app.post('/api/profile', async (req, res) => {
    if (!hasOnlyKeys(req.body, new Set(['name'])) || typeof req.body.name !== 'string') {
      problem(res, 400, 'รูปแบบข้อมูลไม่ถูกต้อง');
      return;
    }
    const name = req.body.name.trim();
    if (!isValidProfileName(name)) {
      problem(res, 400, 'ชื่อโปรไฟล์ต้องยาวไม่เกิน 40 ตัวอักษร');
      return;
    }
    await openWorkspace(req, res, async (id, ws) => {
      ws.name = name;
      try {
        await store.save(id, ws);
        res.json({ name });
      } catch (error) {
        handleStorageError(res, error);
      }
    });
  });

  app.post('/api/turns', async (req, res) => {
    if (
      !hasOnlyKeys(req.body, new Set(['chatId', 'prompt', 'model', 'files'])) ||
      typeof req.body.chatId !== 'string' ||
      typeof req.body.prompt !== 'string' ||
      typeof req.body.model !== 'string' ||
      !Array.isArray(req.body.files)
    ) {
      problem(res, 400, 'รูปแบบข้อมูลไม่ถูกต้อง');
      return;
    }

    const input: SendRequest = {
      chatId: req.body.chatId,
      prompt: req.body.prompt.trim(),
      model: req.body.model,
      files: req.body.files,
    };

    if (!validRequest(input)) {
      problem(res, 400, 'ใช้ข้อความไม่เกิน 12 KB และแนบไฟล์ข้อความได้สูงสุด 4 ไฟล์ ไฟล์ละ 64 KiB รวม 192 KiB');
      return;
    }

    const models = availableModels();
    const chosenModel = models.find((m) => m.id === input.model);
    if (!chosenModel) {
      problem(res, 400, 'โมเดลนี้ยังไม่ได้ตั้งค่า');
      return;
    }

    await openWorkspace(req, res, async (id, ws) => {
      const index = findChatIndex(ws, input.chatId);
      let chat: Chat;

      if (input.chatId !== '') {
        if (index < 0) {
          problem(res, 404, 'ไม่พบแชตนี้');
          return;
        }
        chat = ws.chats[index];
        if (chat.turns.length >= 40) {
          problem(res, 409, 'แชตนี้ครบ 40 ข้อความแล้ว เปิดแชตใหม่เพื่อคุยต่อ');
          return;
        }
      } else {
        if (ws.chats.length >= 40) {
          problem(res, 409, 'ถึงขีดจำกัด 40 แชต ลบแชตเก่าก่อนเปิดแชตใหม่');
          return;
        }
        chat = {
          id: newID(),
          title: titleFor(input),
          updated: new Date().toISOString(),
          turns: [],
        };
      }

      let reply: string;
      try {
        if (input.model === 'ai' && provider) {
          reply = await completeWithProvider(provider, input, chat);
        } else {
          reply = analyzeFilesReply(input.files);
        }
      } catch (error) {
        if (error instanceof ProviderContextError) {
          problem(res, 413, 'ไฟล์แนบกับข้อความยาวเกินขีดจำกัดโหมด AI ลองเอาไฟล์บางส่วนออกหรือย่อข้อความ');
          return;
        }
        console.error(`reply failed (${input.model}):`, error);
        const message =
          input.model === 'ai'
            ? 'เรียกโมเดล AI ไม่สำเร็จ ตรวจสอบการตั้งค่าแล้วส่งอีกครั้ง'
            : 'เอนจินวิเคราะห์ไฟล์ยังไม่พร้อม ตรวจสอบการตั้งค่าแล้วส่งอีกครั้ง';
        problem(res, 502, message);
        return;
      }

      chat.turns.push({
        prompt: input.prompt,
        reply,
        model: chosenModel.name,
        files: input.files,
      });
      delete chat.redo;
      chat.updated = new Date().toISOString();

      if (index >= 0) {
        ws.chats.splice(index, 1);
      }
      ws.chats.unshift(chat);

      try {
        await store.save(id, ws);
        res.json({
          chat: publicChat(chat),
          chats: workspaceSummaries(ws),
        });
      } catch (error) {
        handleStorageError(res, error);
      }
    });
  });

  app.post('/api/chats/:id/:action', async (req, res) => {
    if (!hasOnlyKeys(req.body ?? {}, new Set())) {
      problem(res, 400, 'รูปแบบข้อมูลไม่ถูกต้อง');
      return;
    }

    await openWorkspace(req, res, async (id, ws) => {
      const index = findChatIndex(ws, req.params.id);
      if (index < 0) {
        problem(res, 404, 'ไม่พบแชตนี้');
        return;
      }

      const chat = ws.chats[index];
      const action = req.params.action;

      if (action === 'summary') {
        res.json({ summary: summarizeChat(chat) });
        return;
      }

      let removed = false;
      if (action === 'undo') {
        if (chat.turns.length > 0) {
          const lastTurn = chat.turns.pop()!;
          chat.redo = chat.redo ?? [];
          chat.redo.push(lastTurn);
        }
      } else if (action === 'redo') {
        if (chat.redo && chat.redo.length > 0) {
          const restored = chat.redo.pop()!;
          chat.turns.push(restored);
        }
      } else if (action === 'delete') {
        ws.chats.splice(index, 1);
        removed = true;
      } else {
        problem(res, 404, 'ไม่พบคำสั่งนี้');
        return;
      }

      let view: ReturnType<typeof publicChat> | null = null;
      if (!removed) {
        chat.updated = new Date().toISOString();
        view = publicChat(chat);
        ws.chats.splice(index, 1);
        ws.chats.unshift(chat);
      }

      try {
        await store.save(id, ws);
        res.json({
          chat: view,
          chats: workspaceSummaries(ws),
        });
      } catch (error) {
        handleStorageError(res, error);
      }
    });
  });

  app.use('/api', (_req, res) => {
    problem(res, 404, 'ไม่พบ API');
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build not found');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BLUEZYCODE listening on http://0.0.0.0:${PORT}`);
  });
}

void createServer();
