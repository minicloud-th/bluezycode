import { useEffect, useRef, useState } from 'react'
import type { FormEvent, KeyboardEvent } from 'react'
import { byteLength, errorMessage } from './api'
import type { Attachment, Model } from './api'
import { Icon } from './icons'

export const commands = [
  { name: '/new', description: 'เปิดแชตใหม่' },
  { name: '/models', description: 'เลือกโมเดล' },
  { name: '/undo', description: 'ย้อนข้อความล่าสุด' },
  { name: '/redo', description: 'คืนข้อความที่ย้อน' },
  { name: '/share', description: 'ดาวน์โหลดแชตเป็น Markdown' },
  { name: '/compact', description: 'ดูสรุปแชต' },
  { name: '/help', description: 'ดูคำสั่งทั้งหมด' },
] as const
export type Command = typeof commands[number]['name']

type Props = {
  busy: boolean
  ready: boolean
  draft: string
  files: Attachment[]
  model: string
  models: Model[]
  onDraft(value: string): void
  onFiles(files: Attachment[]): void
  onModel(id: string): void
  onSend(): void
  onCommand(command: Command): void
  onError(message: string): void
}

export function Composer(props: Props) {
  const { busy, ready, draft, files, model, models, onDraft, onFiles, onModel, onSend, onCommand, onError } = props
  const input = useRef<HTMLTextAreaElement>(null)
  const picker = useRef<HTMLInputElement>(null)
  const popup = useRef<HTMLDivElement>(null)
  const modelButton = useRef<HTMLButtonElement>(null)
  const firstModel = useRef<HTMLButtonElement>(null)
  const [cursor, setCursor] = useState(0)
  const [active, setActive] = useState(0)
  const [focused, setFocused] = useState(false)
  const [dismissed, setDismissed] = useState(false)
  const [showModels, setShowModels] = useState(false)
  const [reading, setReading] = useState(false)
  const blocked = busy || reading || !ready

  useEffect(() => {
    if (!showModels) return
    firstModel.current?.focus()
    function closeOutside(event: PointerEvent) {
      const target = event.target as Node
      if (!popup.current?.contains(target) && !modelButton.current?.contains(target)) {
        setShowModels(false)
      }
    }
    document.addEventListener('pointerdown', closeOutside)
    return () => document.removeEventListener('pointerdown', closeOutside)
  }, [showModels])

  const token = draft.slice(0, cursor).match(/(?:^|\s)(\/\S*|@\S*)$/)?.[1]
  const isCommand = token?.startsWith('/') && token.length === cursor
  const fileOptions = [
    ...files.map(({ name }) => ({ name: '@' + name, description: 'ไฟล์แนบ' })),
    { name: '@', description: 'แนบไฟล์จากเครื่อง', picker: true },
  ]
  const options = focused && !dismissed && !showModels && token && !blocked
    ? (isCommand ? commands : token.startsWith('@') ? fileOptions : []).filter(
        option => option.name.toLowerCase().startsWith(token.toLowerCase()),
      )
    : []
  const selectedIndex = Math.min(active, options.length - 1)

  function applyOption(index: number) {
    const choice = options[index]
    if (!choice || !token) return
    const before = draft.slice(0, cursor - token.length)
    const after = draft.slice(cursor)
    if ('picker' in choice) {
      onDraft(before + after)
      picker.current?.click()
    } else if (choice.name === '/models') {
      onDraft(after.trimStart())
      setShowModels(true)
    } else {
      const value = before + choice.name + ' ' + after
      const position = before.length + choice.name.length + 1
      onDraft(value)
      setCursor(position)
      requestAnimationFrame(() => input.current?.setSelectionRange(position, position))
    }
    setDismissed(true)
  }

  function submit(event?: FormEvent) {
    event?.preventDefault()
    if (blocked) return
    setDismissed(true)
    setShowModels(false)
    const command = commands.find(item => item.name === draft.trim())
    if (command?.name === '/models') {
      onDraft('')
      setShowModels(true)
      return
    }
    if (command) {
      onCommand(command.name)
      return
    }
    onSend()
  }

  function handleKeys(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.nativeEvent.isComposing) return
    if (options.length) {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault()
        setActive((selectedIndex + (event.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length)
        return
      }
      if ((event.key === 'Tab' || event.key === 'Enter') && !event.shiftKey) {
        event.preventDefault()
        applyOption(selectedIndex)
        return
      }
      if (event.key === 'Escape') {
        event.preventDefault()
        setDismissed(true)
        return
      }
    }
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      submit()
    }
  }

  async function addFiles(list: FileList | null) {
    const chosen = Array.from(list ?? [])
    if (!chosen.length || blocked) return
    setReading(true)
    try {
      if (files.length + chosen.length > 4 || chosen.some(file => file.size > 64 * 1024)) {
        throw new Error('แนบได้สูงสุด 4 ไฟล์ ไฟล์ละ 64 KiB')
      }
      const textDecoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true })
      const additions = await Promise.all(chosen.map(async file => {
        let content: string
        try {
          content = textDecoder.decode(await file.arrayBuffer())
        } catch {
          throw new Error(file.name + ' ต้องเป็นไฟล์ข้อความ UTF-8')
        }
        if (content.includes('\x00')) throw new Error(file.name + ' ต้องเป็นไฟล์ข้อความ UTF-8')
        return { name: file.name, content }
      }))
      const combined = [...files, ...additions]
      if (combined.reduce((total, file) => total + byteLength(file.content), 0) > 192 * 1024) {
        throw new Error('ขนาดไฟล์รวมต้องไม่เกิน 192 KiB')
      }
      onFiles(combined)
      onError('')
    } catch (error) {
      onError(errorMessage(error))
    } finally {
      setReading(false)
      if (picker.current) picker.current.value = ''
      input.current?.focus()
    }
  }

  return <form className="composer" onSubmit={submit}>
    {options.length > 0 && <div id="suggestions" className="picker suggestions" role="listbox" aria-label="คำแนะนำ">
      {options.map((option, index) => <div key={option.name} role="option"
        id={'suggestion-' + index} aria-selected={index === selectedIndex}
        onPointerDown={event => event.preventDefault()} onClick={() => applyOption(index)}
        className={'picker-option' + (index === selectedIndex ? ' selected' : '')}>
        <span className="option-name">{option.name}</span><span>{option.description}</span>
      </div>)}
    </div>}

    {files.length > 0 && <ul className="attachments">
      {files.map((file, index) => <li key={file.name + index}>
        <Icon name="file" size={14} /><span>{file.name}</span>
        <button type="button" aria-label={'เอา ' + file.name + ' ออก'} disabled={blocked}
          onClick={() => onFiles(files.filter((_, item) => item !== index))}><Icon name="close" size={13} /></button>
      </li>)}
    </ul>}

    <label className="sr-only" htmlFor="prompt">ข้อความ</label>
    <textarea id="prompt" ref={input} value={draft} rows={1} maxLength={12000}
      disabled={busy || !ready} aria-autocomplete="list"
      aria-controls={options.length ? 'suggestions' : undefined}
      aria-activedescendant={options.length ? 'suggestion-' + selectedIndex : undefined}
      placeholder="พิมพ์ข้อความ ใช้ / สำหรับคำสั่ง และ @ สำหรับไฟล์"
      onChange={event => {
        onDraft(event.target.value)
        setCursor(event.target.selectionStart)
        setActive(0)
        setDismissed(false)
      }}
      onSelect={event => setCursor(event.currentTarget.selectionStart)}
      onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} onKeyDown={handleKeys} />

    <div className="tools">
      <input ref={picker} type="file" multiple hidden onChange={event => void addFiles(event.target.files)} />
      <button className="icon-button" type="button" aria-label="แนบไฟล์" title="แนบไฟล์" disabled={blocked}
        onClick={() => picker.current?.click()}><Icon name="plus" size={16} /></button>
      <div className="model-wrapper">
        <button type="button" className="model-button" aria-expanded={showModels} aria-controls="models"
          ref={modelButton} disabled={blocked} onClick={() => setShowModels(!showModels)}>
          {models.find(item => item.id === model)?.name ?? 'Workspace'}<Icon name="chevron" size={13} />
        </button>
        {showModels && <div id="models" className="picker model-picker" ref={popup} role="group"
          aria-label="เลือกโมเดล" onKeyDown={event => {
            if (event.key === 'Escape') {
              setShowModels(false)
              modelButton.current?.focus()
            }
          }}>
          {models.map((item, index) => <button type="button" key={item.id} ref={index === 0 ? firstModel : undefined}
            className="picker-option" aria-pressed={item.id === model}
            onClick={() => {
              onModel(item.id)
              setShowModels(false)
              input.current?.focus()
            }}>
            <span>{item.name}</span>{item.id === model && <Icon name="check" size={15} />}
          </button>)}
          {models.length === 1 && <p>เชื่อมต่อผู้ให้บริการ AI ได้ในการตั้งค่าเซิร์ฟเวอร์</p>}
        </div>}
      </div>
      <button className="send-button" title="ส่ง" aria-label="ส่ง"
        disabled={blocked || (!draft.trim() && !files.length)}><Icon name="send" size={16} /></button>
    </div>
  </form>
}
