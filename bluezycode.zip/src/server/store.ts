import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import type { Chat, ChatSummary, Turn, Workspace } from './types.ts';

export const MAX_WORKSPACE_BYTES = 8 * 1024 * 1024;

export class WorkspaceFullError extends Error {
  constructor() {
    super('พื้นที่จัดเก็บเต็ม ลบแชตเก่าแล้วลองอีกครั้ง');
    this.name = 'WorkspaceFullError';
  }
}

export function newID(): string {
  return crypto.randomBytes(24).toString('hex');
}

export function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!cookieHeader) return cookies;
  for (const part of cookieHeader.split(';')) {
    const eq = part.indexOf('=');
    if (eq <= 0) continue;
    const key = part.slice(0, eq).trim();
    const val = part.slice(eq + 1).trim();
    cookies[key] = decodeURIComponent(val);
  }
  return cookies;
}

export function extractWorkspaceID(cookieHeader: string | undefined): string {
  const value = parseCookies(cookieHeader).bluezy_workspace ?? '';
  if (value.length !== 48 || !/^[0-9a-fA-F]{48}$/.test(value)) {
    return '';
  }
  return value.toLowerCase();
}

export function findChatIndex(ws: Workspace, id: string): number {
  return ws.chats.findIndex((chat) => chat.id === id);
}

export function workspaceSummaries(ws: Workspace): ChatSummary[] {
  return ws.chats.map((chat) => ({
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
  }));
}

export function publicChat(chat: Chat): {
  id: string;
  title: string;
  updated: string;
  turns: Turn[];
  canRedo: boolean;
} {
  return {
    id: chat.id,
    title: chat.title,
    updated: chat.updated,
    turns: chat.turns.map((turn) => ({
      prompt: turn.prompt,
      reply: turn.reply,
      model: turn.model,
      files: turn.files.map((file) => ({ name: file.name })),
    })),
    canRedo: (chat.redo?.length ?? 0) > 0,
  };
}

export class Storage {
  private dir: string;
  private locks = new Map<string, Promise<void>>();

  constructor(dir: string) {
    this.dir = dir;
  }

  async init(): Promise<void> {
    await fs.mkdir(this.dir, { recursive: true, mode: 0o700 });
  }

  async withLock<T>(id: string, fn: () => Promise<T>): Promise<T> {
    const previous = this.locks.get(id) ?? Promise.resolve();
    let release!: () => void;
    const current = new Promise<void>((resolve) => {
      release = resolve;
    });
    const tail = previous.then(() => current, () => current);
    this.locks.set(id, tail);
    await previous.catch(() => {});
    try {
      return await fn();
    } finally {
      release();
      if (this.locks.get(id) === tail) {
        this.locks.delete(id);
      }
    }
  }

  async load(id: string): Promise<Workspace> {
    const filePath = path.join(this.dir, `${id}.json`);
    try {
      const raw = await fs.readFile(filePath, 'utf8');
      const parsed = JSON.parse(raw) as Partial<Workspace>;
      return {
        name: typeof parsed.name === 'string' ? parsed.name : '',
        chats: Array.isArray(parsed.chats) ? parsed.chats : [],
      };
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        return { name: '', chats: [] };
      }
      throw error;
    }
  }

  async save(id: string, workspace: Workspace): Promise<void> {
    const payload = JSON.stringify(workspace);
    if (Buffer.byteLength(payload, 'utf8') > MAX_WORKSPACE_BYTES) {
      throw new WorkspaceFullError();
    }
    await this.init();
    const tmpPath = path.join(this.dir, `.workspace-${id}-${crypto.randomBytes(6).toString('hex')}.tmp`);
    const targetPath = path.join(this.dir, `${id}.json`);
    try {
      await fs.writeFile(tmpPath, payload, 'utf8');
      await fs.rename(tmpPath, targetPath);
    } catch (error) {
      await fs.rm(tmpPath, { force: true }).catch(() => {});
      throw error;
    }
  }
}
