export type FileAttachment = {
  name: string;
  content?: string;
};

export type ValidFileAttachment = {
  name: string;
  content: string;
};

export type Turn = {
  prompt: string;
  reply: string;
  model: string;
  files: FileAttachment[];
};

export type Chat = {
  id: string;
  title: string;
  updated: string;
  turns: Turn[];
  redo?: Turn[];
};

export type ChatSummary = {
  id: string;
  title: string;
  updated: string;
};

export type Workspace = {
  name: string;
  chats: Chat[];
};

export type Model = {
  id: string;
  name: string;
};

export type SendRequest = {
  chatId: string;
  prompt: string;
  model: string;
  files: ValidFileAttachment[];
};

export type Note = {
  line: number;
  text: string;
};

export type Analysis = {
  bytes: number;
  lines: number;
  non_blank: number;
  longest: number;
  notes: Note[];
};
