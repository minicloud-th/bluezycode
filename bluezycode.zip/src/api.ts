export type Model = { id: string; name: string }
export type Attachment = { name: string; content: string }
export type ChatSummary = { id: string; title: string; updated: string }
export type Turn = { prompt: string; reply: string; model: string; files: Pick<Attachment, 'name'>[] }
export type Chat = ChatSummary & { turns: Turn[]; canRedo: boolean }
export type Workspace = { name: string; chats: ChatSummary[]; models: Model[]; engineAvailable: boolean }
export type ChatChange = { chat: Chat | null; chats: ChatSummary[] }

export async function api<T>(path: string, body?: unknown): Promise<T> {
  const headers = body === undefined ? undefined : { 'Content-Type': 'application/json' }
  try {
    const response = await fetch('/api' + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    const data = await response.json()
    if (!response.ok) throw new Error(data.error || 'คำขอไม่สำเร็จ ลองอีกครั้ง')
    return data
  } catch (error) {
    if (error instanceof TypeError || error instanceof SyntaxError) {
      throw new Error('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ลองอีกครั้ง')
    }
    throw error
  }
}

const encoder = new TextEncoder()
export function byteLength(text: string) {
  return encoder.encode(text).length
}

export function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'เกิดข้อผิดพลาด ลองอีกครั้ง'
}
