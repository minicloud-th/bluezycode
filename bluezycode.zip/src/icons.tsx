import type { ReactNode } from 'react'

const paths = {
  home: <><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.2V20h14V9.2"/></>,
  history: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2.5"/></>,
  panel: <><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/></>,
  cloud: <path d="M7 19h11a4 4 0 0 0 .4-8 6 6 0 0 0-11.6-2A5 5 0 0 0 7 19Z"/>,
  plus: <path d="M12 5v14M5 12h14"/>,
  send: <path d="M12 19V5m-6 6 6-6 6 6"/>,
  chevron: <path d="m6 9 6 6 6-6"/>,
  file: <><path d="M14 3H5v18h14V8z"/><path d="M14 3v5h5M8 13h8m-8 4h5"/></>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  monitor: <><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M12 17v4m-4 0h8"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 10v7m4-7v7"/></>,
  search: <><circle cx="10.5" cy="10.5" r="5.5"/><path d="m15 15 4 4"/></>,
} satisfies Record<string, ReactNode>

export function Icon({ name, size = 18 }: { name: keyof typeof paths; size?: number }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
    {paths[name]}
  </svg>
}
