import { useEffect, useRef, useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import Markdown from 'react-markdown'
import { HugeiconsIcon } from '@hugeicons/react'
import { Clock01Icon, CloudIcon, Home01Icon } from '@hugeicons/core-free-icons'
import {
  GlassSidebar,
  GlassSidebarFooter,
  GlassSidebarGroup,
  GlassSidebarHeader,
  GlassSidebarItem,
  GlassSidebarToggle,
} from '@/components/ui/glass-sidebar'
import { api, byteLength, errorMessage } from './api'
import type { Attachment, Chat, ChatChange, ChatSummary, Workspace } from './api'
import { Composer, commands } from './Composer'
import type { Command } from './Composer'
import { Icon } from './icons'

type Panel = 'cloud' | 'profile' | 'help' | 'summary' | 'delete'

function Logo() {
  const [playing, setPlaying] = useState(false)
  useEffect(() => {
    let mounted = true
    const sprite = new Image()
    sprite.src = '/bluezy-wordmark.png'
    void sprite.decode().then(() => { if (mounted) setPlaying(true) }, () => {})
    return () => { mounted = false }
  }, [])
  return <h1 className="wordmark" aria-label="BLUEZYCODE">
    <span className={'wm-box' + (playing ? ' playing' : '')} aria-hidden="true">
      <span className="wm-anim" /><span className="wm-shine" />
      <span className="wm-star star-one" /><span className="wm-star star-two" />
      <span className="wm-star star-three" /><span className="wm-star star-four" />
      <span className="wm-star star-five" />
    </span>
  </h1>
}

function Modal({ title, busy, onClose, children }: {
  title: string; busy: boolean; onClose(): void; children: ReactNode
}) {
  const dialog = useRef<HTMLDialogElement>(null)
  useEffect(() => { dialog.current?.showModal() }, [])
  return <dialog ref={dialog} className="modal" aria-labelledby="modal-title"
    onCancel={event => { event.preventDefault(); if (!busy) onClose() }}>
    <header>
      <h2 id="modal-title">{title}</h2>
      <button className="icon-button" aria-label="ปิด" disabled={busy} onClick={onClose}><Icon name="close" /></button>
    </header>
    {children}
  </dialog>
}

function exportChat(chat: Chat) {
  const text = '# ' + chat.title + '\n\n' + chat.turns.map(turn => {
    const files = turn.files.length ? '\n\nไฟล์แนบ ' + turn.files.map(file => file.name).join(', ') : ''
    return '## คุณ\n\n' + turn.prompt + files + '\n\n## ' + turn.model + '\n\n' + turn.reply
  }).join('\n\n---\n\n')
  const link = document.createElement('a')
  const objectURL = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }))
  link.href = objectURL
  link.download = 'bluezycode-' + chat.id.slice(0, 8) + '.md'
  document.body.appendChild(link)
  link.click()
  link.remove()
  setTimeout(() => URL.revokeObjectURL(objectURL), 1000)
}

function formatDate(date: string) {
  return new Intl.DateTimeFormat('th-TH', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }).format(new Date(date))
}

export function App() {
  const [workspace, setWorkspace] = useState<Workspace | null>(null)
  const [chat, setChat] = useState<Chat | null>(null)
  const [draft, setDraft] = useState('')
  const [files, setFiles] = useState<Attachment[]>([])
  const [model, setModel] = useState('workspace')
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [busy, setBusy] = useState(false)
  const [initializing, setInitializing] = useState(true)
  const [collapsed, setCollapsed] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth <= 768 : false,
  )
  const [showHistory, setShowHistory] = useState(false)
  const [query, setQuery] = useState('')
  const [panel, setPanel] = useState<Panel | null>(null)
  const [summary, setSummary] = useState('')
  const [profileName, setProfileName] = useState('')
  const log = useRef<HTMLElement>(null)
  const busyRef = useRef(false)

  async function boot() {
    setInitializing(true)
    setError('')
    try {
      setWorkspace(await api<Workspace>('/workspace'))
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      setInitializing(false)
    }
  }

  useEffect(() => { void boot() }, [])
  useEffect(() => {
    if (log.current) log.current.scrollTop = log.current.scrollHeight
  }, [chat?.id, chat?.turns.length, busy, chat?.canRedo])

  async function run(task: () => Promise<void>, restoreFocus = false) {
    if (busyRef.current || !workspace) return
    busyRef.current = true
    setBusy(true)
    setError('')
    setNotice('')
    try {
      await task()
    } catch (failure) {
      setError(errorMessage(failure))
    } finally {
      busyRef.current = false
      setBusy(false)
      if (restoreFocus) requestAnimationFrame(() => document.getElementById('prompt')?.focus())
    }
  }

  function change({ chat: nextChat, chats }: ChatChange) {
    setWorkspace(current => current && { ...current, chats })
    setChat(nextChat)
  }

  function newChat() {
    if (busyRef.current) return
    setChat(null)
    setDraft('')
    setFiles([])
    setError('')
    setNotice('')
    setShowHistory(false)
    requestAnimationFrame(() => document.getElementById('prompt')?.focus())
  }

  function openChat(item: ChatSummary) {
    void run(async () => {
      setChat(await api<Chat>('/chats/' + item.id))
      setShowHistory(false)
    })
  }

  function send() {
    if (byteLength(draft.trim()) > 12000) {
      setError('ข้อความยาวเกิน 12 KB ลองย่อให้สั้นลง')
      return
    }
    void run(async () => {
      change(await api<ChatChange>('/turns', { chatId: chat?.id ?? '', prompt: draft, model, files }))
      setDraft('')
      setFiles([])
    }, true)
  }

  function action(name: 'undo' | 'redo' | 'delete') {
    if (!chat) return
    void run(async () => {
      change(await api<ChatChange>('/chats/' + chat.id + '/' + name, {}))
      if (name === 'delete') {
        setPanel(null)
        setNotice('ลบแชตแล้ว')
      }
    })
  }

  function command(name: Command) {
    setDraft('')
    setError('')
    setNotice('')
    if (name === '/new') {
      newChat()
      return
    }
    if (name === '/help') {
      setPanel('help')
      return
    }
    if (!chat) {
      setNotice('ส่งข้อความเพื่อเริ่มแชตก่อน')
      return
    }
    switch (name) {
      case '/undo':
        if (chat.turns.length) action('undo')
        else setNotice('ไม่มีข้อความให้ย้อน')
        break
      case '/redo':
        if (chat.canRedo) action('redo')
        else setNotice('ไม่มีข้อความให้คืน')
        break
      case '/share':
        if (chat.turns.length) {
          exportChat(chat)
          setNotice('ดาวน์โหลดไฟล์แชตแล้ว')
        } else setNotice('ไม่มีข้อความให้ดาวน์โหลด')
        break
      case '/compact':
        void run(async () => {
          const result = await api<{ summary: string }>('/chats/' + chat.id + '/summary', {})
          setSummary(result.summary)
          setPanel('summary')
        })
        break
    }
  }

  function saveProfile(event: FormEvent) {
    event.preventDefault()
    void run(async () => {
      const result = await api<{ name: string }>('/profile', { name: profileName })
      setWorkspace(current => current && { ...current, name: result.name })
      setPanel(null)
    })
  }

  const titles = { cloud: 'การเชื่อมต่อ', profile: 'โปรไฟล์', help: 'คำสั่ง', summary: 'สรุปแชต', delete: 'ลบแชตนี้?' }
  const displayName = workspace?.name || 'ผู้ใช้'
  const history = workspace?.chats.filter(item => item.title.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase())) ?? []

  return <div className="app-shell">
    <div className="relative z-20 h-full shrink-0 p-2.5 pr-0">
      <GlassSidebar
        aria-label="เมนูหลัก"
        collapsed={collapsed}
        onCollapsedChange={next => {
          setCollapsed(next)
          if (next && typeof window !== 'undefined' && window.innerWidth <= 620) {
            setShowHistory(false)
          }
        }}
      >
        <GlassSidebarHeader>
          <GlassSidebarToggle
            aria-label={collapsed ? 'เปิดเมนู' : 'ซ่อนเมนู'}
            title={collapsed ? 'เปิดเมนู' : 'ซ่อนเมนู'}
          />
          {!collapsed && (
            <div className="flex min-w-0 items-center gap-2">
              <img
                className="size-6 shrink-0 [image-rendering:pixelated]"
                src="/bluezy-icon.png"
                width="24"
                height="24"
                alt=""
                draggable={false}
              />
              <span className="truncate text-sm font-semibold tracking-wide">BLUEZYCODE</span>
            </div>
          )}
        </GlassSidebarHeader>

        <GlassSidebarGroup label="Workspace">
          <GlassSidebarItem
            aria-label="แชตใหม่"
            icon={<HugeiconsIcon icon={Home01Icon} />}
            active={!chat && !showHistory && !panel}
            onClick={newChat}
            disabled={!workspace || busy}
          >
            แชตใหม่
          </GlassSidebarItem>
          <GlassSidebarItem
            aria-label="ประวัติ"
            icon={<HugeiconsIcon icon={Clock01Icon} />}
            active={showHistory && !panel}
            badge={workspace?.chats.length ? workspace.chats.length : undefined}
            aria-controls="history-panel"
            aria-expanded={showHistory}
            onClick={() => {
              if (typeof window !== 'undefined' && window.innerWidth <= 620) {
                setCollapsed(true)
              }
              setShowHistory(!showHistory)
            }}
            disabled={!workspace || busy}
          >
            ประวัติ
          </GlassSidebarItem>
          <GlassSidebarItem
            aria-label="การเชื่อมต่อ"
            icon={<HugeiconsIcon icon={CloudIcon} />}
            active={panel === 'cloud'}
            onClick={() => {
              setError('')
              setPanel('cloud')
            }}
            disabled={busy}
          >
            การเชื่อมต่อ
          </GlassSidebarItem>
        </GlassSidebarGroup>

        <GlassSidebarFooter>
          <GlassSidebarItem
            aria-label="โปรไฟล์"
            active={panel === 'profile'}
            disabled={!workspace || busy}
            icon={
              <span className="grid size-[22px] shrink-0 place-items-center rounded-full border border-[#6d9bfa] bg-[#3261bb] text-[11px] font-semibold text-white">
                {Array.from(displayName)[0].toLocaleUpperCase()}
              </span>
            }
            onClick={() => {
              setError('')
              setProfileName(workspace?.name ?? '')
              setPanel('profile')
            }}
          >
            {displayName}
          </GlassSidebarItem>
        </GlassSidebarFooter>
      </GlassSidebar>
    </div>

    {showHistory && <aside className="history-panel" id="history-panel" aria-label="ประวัติแชต">
      <header><h2>ประวัติแชต</h2><button className="icon-button" aria-label="ปิดประวัติ" onClick={() => setShowHistory(false)}><Icon name="close" /></button></header>
      <button className="primary-button history-new" onClick={newChat} disabled={busy}><Icon name="plus" size={16} />แชตใหม่</button>
      <label className="history-search"><Icon name="search" size={17} /><span className="sr-only">ค้นหาแชต</span>
        <input type="search" placeholder="ค้นหาแชต" value={query} onChange={event => setQuery(event.target.value)} />
      </label>
      {history.length === 0 && <p className="history-empty">{query ? 'ไม่พบแชตที่ตรงกัน' : 'ยังไม่มีแชตที่บันทึกไว้'}</p>}
      <div className="history-list">{history.map(item => <button key={item.id} disabled={busy}
        aria-current={chat?.id === item.id ? 'page' : undefined} onClick={() => openChat(item)}>
        <span>{item.title}</span><time dateTime={item.updated}>{formatDate(item.updated)}</time>
      </button>)}</div>
    </aside>}

    <main className={'stage' + (chat ? ' conversation' : '')}>
      {!chat && <div className="welcome"><Logo /></div>}
      {chat && <>
        <header className="chat-header">
          <div><span>BLUEZYCODE</span><h1 title={chat.title}>{chat.title}</h1></div>
          <button className="icon-button" aria-label="ลบแชต" title="ลบแชต" disabled={busy} onClick={() => {
            setError(''); setPanel('delete')
          }}><Icon name="trash" /></button>
        </header>
        <section className="chat-scroll" aria-label="บทสนทนา" ref={log}>
          <div className="chat-log" role="log">
            {chat.turns.map((turn, index) => <article className="turn" key={index}>
              <div className="message-user">
                {turn.prompt && <div>{turn.prompt}</div>}
                {turn.files.length > 0 && <ul className="message-files">
                  {turn.files.map((file, number) => <li key={number}><Icon name="file" size={13} />{file.name}</li>)}
                </ul>}
              </div>
              <div className="message-assistant">
                <div className="message-by"><img src="/bluezy-icon.png" alt="" width="17" height="17" />{turn.model}</div>
                {turn.model === 'Workspace'
                  ? <div className="plain-reply">{turn.reply}</div>
                  : <Markdown skipHtml disallowedElements={['img', 'a']} unwrapDisallowed>{turn.reply}</Markdown>}
              </div>
            </article>)}
            {!chat.turns.length && <p className="empty-chat">ใช้ /redo เพื่อคืนข้อความ หรือส่งข้อความใหม่เพื่อคุยต่อ</p>}
          </div>
        </section>
      </>}
      <div className="compose-area">
        <Composer busy={busy} ready={workspace !== null} draft={draft} files={files} model={model}
          models={workspace?.models ?? []} onDraft={setDraft} onFiles={setFiles} onModel={setModel}
          onSend={send} onCommand={command} onError={setError} />
        <div className="context">
          <span className="context-brand"><img src="/bluezy-icon.png" alt="" width="15" height="15" /> BLUEZYCODE</span>
          <span aria-hidden="true">/</span>
          <span><Icon name={model === 'workspace' ? 'monitor' : 'cloud'} size={15} />{model === 'workspace' ? 'Local' : 'AI'}</span>
          {(initializing || busy || notice) && <span className="operation-status" role="status">
            {initializing ? 'กำลังเชื่อมต่อ' : busy ? 'กำลังดำเนินการ' : notice}
          </span>}
        </div>
        {error && !panel && <div className="error" role="alert">{error}
          {!workspace && <button className="text-button" onClick={() => void boot()}>ลองเชื่อมต่อใหม่</button>}
        </div>}
      </div>
    </main>

    {panel && <Modal key={panel} title={titles[panel]} busy={busy} onClose={() => { setError(''); setPanel(null) }}>
      {panel === 'cloud' && <dl className="connection-list">
        <div><dt>เซิร์ฟเวอร์ Go</dt><dd>{workspace ? 'เชื่อมต่อแล้ว' : 'ยังไม่เชื่อมต่อ'}</dd></div>
        <div><dt>เอนจิน Rust</dt><dd>{workspace?.engineAvailable ? 'พร้อมวิเคราะห์ไฟล์' : 'ยังไม่พร้อม'}</dd></div>
        <div><dt>ผู้ให้บริการ AI</dt><dd>{workspace?.models.find(item => item.id === 'ai')?.name ?? 'ยังไม่ได้ตั้งค่า'}</dd></div>
      </dl>}
      {panel === 'profile' && <form className="modal-form" onSubmit={saveProfile}>
        <label htmlFor="profile-name">ชื่อที่แสดง</label>
        <input id="profile-name" value={profileName} maxLength={40} placeholder="ผู้ใช้" autoFocus
          onChange={event => setProfileName(event.target.value)} disabled={busy} />
        <button className="primary-button" disabled={busy}>บันทึกชื่อ</button>
      </form>}
      {panel === 'help' && <dl className="command-list">{commands.map(item => <div key={item.name}>
        <dt><code>{item.name}</code></dt><dd>{item.description}</dd>
      </div>)}</dl>}
      {panel === 'summary' && <p className="plain-reply">{summary}</p>}
      {panel === 'delete' && <div className="delete-form">
        <p>ข้อความและไฟล์ของแชตนี้จะถูกลบจากประวัติ</p>
        <button className="danger-button" onClick={() => action('delete')} disabled={busy}>ลบแชต</button>
      </div>}
      {error && <p role="alert" className="error">{error}</p>}
    </Modal>}
  </div>
}
